# ESUPEX À L'ÉCOUTE
### Observatoire de la satisfaction estudiantine

*Ton avis compte. Ensemble, améliorons notre école.*

Plateforme web de consultation **anonyme** des étudiants de l'ESUPEX et tableau de bord de pilotage pour la direction.

| Partie | Adresse | Accès |
|---|---|---|
| Questionnaire étudiant | `/` | Public, sans compte |
| Tableau de bord | `/admin` | Administrateurs autorisés |

## Fonctionnalités
- Questionnaire en 7 rubriques (profil, satisfaction générale, pédagogie, administration, infrastructures, difficultés, suggestions), étapes avec barre de progression, retour en arrière, validation, récapitulatif et confirmation, conçu pour le smartphone.
- Anonymat par construction : aucune donnée d'identité, date au jour près, aucune IP transmise à la base, aucun cookie ni traceur côté étudiant, seuil de confidentialité sur l'affichage.
- Tableau de bord : participation et taux, satisfaction (moyennes, % satisfaits et insatisfaits), scores par rubrique, comparaisons par filière, niveau et année, évolution entre campagnes, 5 priorités d'intervention, points forts, difficultés, améliorations demandées.
- Analyse des commentaires par thèmes, vérifiable à partir des textes originaux, avec synthèse IA facultative et références sources contrôlées.
- Gestion des campagnes (brouillon, ouverte, clôturée), questionnaire modifiable sans toucher au code, référentiels (filières, niveaux, années), effectifs de référence.
- Exports Excel (4 feuilles), CSV et rapport PDF « Baromètre ».

## Architecture
Next.js 14 (App Router, TypeScript) · Tailwind CSS · Supabase/PostgreSQL avec politiques RLS · Recharts · ExcelJS · jsPDF · hébergement Vercel. L'application **n'utilise aucune clé secrète Supabase** (`service_role`) : tous les droits sont contrôlés par la base.

## Documentation
- `docs/GUIDE_DEPLOIEMENT.md` : mise en ligne pas à pas (Supabase, puis GitHub, puis Vercel), vérifications avant lancement, limites de l'anonymat.
- `docs/GUIDE_UTILISATION_ADMINISTRATION.md` : guide de la direction.
- `supabase/schema.sql` : schéma complet de la base (tables, fonctions, RLS, données initiales).

## Arborescence
```
supabase/schema.sql            Base de données + sécurité RLS
supabase/ajouter-admin.sql     Autoriser un administrateur
src/lib/questionnaire.ts       Questionnaire par défaut + validation
src/lib/stats.ts               Calculs statistiques (testés)
src/lib/themes.ts              Analyse des commentaires par thèmes
src/app/                       Pages (accueil, questionnaire, merci, admin/…) et API
src/components/                Composants d'interface
tests/                         Tests unitaires (Vitest) et de bout en bout
```
