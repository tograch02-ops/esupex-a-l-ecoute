\set ON_ERROR_STOP 0
insert into auth.users values ('11111111-1111-1111-1111-111111111111','admin@esupex.bf'),('22222222-2222-2222-2222-222222222222','autre@x.bf');
insert into public.admins(user_id,email) values ('11111111-1111-1111-1111-111111111111','admin@esupex.bf');
insert into public.campagnes(id,titre,statut,questionnaire) values
 ('aaaaaaaa-0000-0000-0000-000000000001','Campagne test','ouverte','{"sections":[]}'),
 ('aaaaaaaa-0000-0000-0000-000000000002','Brouillon','brouillon','{"sections":[]}');

\echo '--- ANON: soumission valide (attendu: OK)'
set role anon;
select public.submit_response('aaaaaaaa-0000-0000-0000-000000000001','Génie civil','Licence 2','2025-2026','{"sat_globale":4}');
\echo '--- ANON: campagne brouillon (attendu: CAMPAGNE_FERMEE)'
select public.submit_response('aaaaaaaa-0000-0000-0000-000000000002','Génie civil','Licence 2','2025-2026','{}');
\echo '--- ANON: filière inventée (attendu: FILIERE_INVALIDE)'
select public.submit_response('aaaaaaaa-0000-0000-0000-000000000001','Médecine','Licence 2','2025-2026','{}');
\echo '--- ANON: lecture des réponses (attendu: 0 ligne)'
select count(*) as reponses_visibles_anon from public.reponses;
\echo '--- ANON: insertion directe (attendu: permission denied)'
insert into public.reponses(campagne_id,filiere,niveau,annee_academique,reponses) values ('aaaaaaaa-0000-0000-0000-000000000001','x','y','z','{}');
\echo '--- ANON: campagnes visibles (attendu: 1, seulement l ouverte)'
select count(*) as campagnes_visibles_anon from public.campagnes;
\echo '--- ANON: modifier une campagne (attendu: 0 ligne modifiée)'
update public.campagnes set statut='cloturee';
\echo '--- ANON: lire paramètres / effectifs / admins (attendu: 0 / 0 / denied)'
select count(*) from public.parametres; select count(*) from public.effectifs; select count(*) from public.admins;
reset role;

\echo '--- AUTHENTIFIÉ NON ADMIN: lecture réponses (attendu: 0)'
set role authenticated; set request.jwt.claim.sub = '22222222-2222-2222-2222-222222222222';
select count(*) as reponses_visibles_non_admin from public.reponses;
\echo '--- AUTHENTIFIÉ NON ADMIN: s auto-promouvoir admin (attendu: denied/RLS)'
insert into public.admins(user_id) values ('22222222-2222-2222-2222-222222222222');
\echo '--- AUTHENTIFIÉ NON ADMIN: ajouter une filière (attendu: RLS violation)'
insert into public.filieres(libelle) values ('Pirate');
reset role;

\echo '--- ADMIN: lecture réponses (attendu: 1)'
set role authenticated; set request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';
select count(*) as reponses_visibles_admin, max(date_soumission) = current_date as date_jour from public.reponses;
\echo '--- ADMIN: modifier une réponse (attendu: permission denied)'
update public.reponses set filiere='x';
\echo '--- ADMIN: ajouter filière + changer seuil (attendu: OK)'
insert into public.filieres(libelle,ordre) values ('Génie énergétique',7);
update public.parametres set seuil_confidentialite = 7 returning seuil_confidentialite;
\echo '--- ADMIN: ouvrir une 2e campagne (attendu: violation index unique)'
update public.campagnes set statut='ouverte' where id='aaaaaaaa-0000-0000-0000-000000000002';
reset role;
\echo '--- Colonnes de la table reponses (aucune identité attendue)'
select string_agg(column_name, ', ' order by ordinal_position) from information_schema.columns where table_name='reponses';
