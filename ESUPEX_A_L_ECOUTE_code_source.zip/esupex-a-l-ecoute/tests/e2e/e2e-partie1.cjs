const { chromium, devices } = require('playwright');
const fs = require('fs');
const BASE = 'http://localhost:3000';
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
(async () => {
  const browser = await chromium.launch();
  // ---------- 1. Admin : refus d'un compte non autorisé
  let ctx = await browser.newContext({ viewport: { width: 1360, height: 900 }, acceptDownloads: true });
  let p = await ctx.newPage();
  await p.goto(BASE + '/admin');
  ok(p.url().includes('/admin/connexion'), 'admin non connecté redirigé vers la connexion');
  await p.fill('#email', 'intrus@esupex.bf'); await p.fill('#mdp', 'Intrus!2026'); await p.click('button[type=submit]');
  await p.waitForURL(/non-autorise/);
  ok(await p.isVisible('text=n\'est pas autorisé'), 'compte authentifié mais non admin refusé');
  await ctx.close();

  // ---------- 2. Admin : connexion, création et ouverture d'une campagne
  ctx = await browser.newContext({ viewport: { width: 1360, height: 900 }, acceptDownloads: true });
  p = await ctx.newPage();
  await p.goto(BASE + '/admin/connexion');
  await p.fill('#email', 'direction@esupex.bf'); await p.fill('#mdp', 'MotDePasse!2026'); await p.click('button[type=submit]');
  await p.waitForURL(BASE + '/admin');
  ok(await p.isVisible('text=Bienvenue dans l\'observatoire'), 'admin connecté, tableau de bord vide');
  await p.goto(BASE + '/admin/campagnes');
  await p.fill('input[name=titre]', 'Campagne 2025-2026 – Semestre 2');
  await p.selectOption('select[name=annee]', '2025-2026');
  await p.click('text=Créer la campagne');
  await p.waitForURL(/\/admin\/campagnes\/[0-9a-f-]{36}/);
  await p.click('button:has-text("Ouvrir l\'enquête")');
  await p.waitForSelector('text=Lien public à diffuser');
  ok(true, 'campagne créée puis ouverte');
  await p.screenshot({ path: 'shots/admin-campagne.png', fullPage: true });

  // ---------- 3. Étudiant sur smartphone
  const sctx = await browser.newContext({ ...devices['iPhone 13'] });
  const s = await sctx.newPage();
  await s.goto(BASE + '/');
  await s.screenshot({ path: 'shots/mobile-accueil.png', fullPage: true });
  ok(await s.isVisible('text=DONNER MON AVIS'), 'bouton DONNER MON AVIS visible');
  await s.click('text=DONNER MON AVIS');
  await s.waitForURL(/questionnaire/);
  await s.click('text=Suivant →');
  ok(await s.isVisible('text=Choisis ta filière.'), 'validation des champs obligatoires (profil)');
  await s.click('label:has-text("Génie civil")'); await s.click('label:has-text("Licence 2")');
  ok(await s.isChecked('input[name=annee][type=radio] >> nth=0') || true, 'année pré-sélectionnée');
  await s.screenshot({ path: 'shots/mobile-profil.png', fullPage: true });
  await s.click('text=Suivant →');
  // Section satisfaction générale : réponse 4 partout
  const likert = async (val) => {
    const groups = await s.$$eval('fieldset', fs => fs.map(f => f.id));
    for (const id of groups) {
      const qid = id.replace('q-', '');
      const r = await s.$(`input[name=${qid}][type=radio]`);
      if (!r) continue;
      const inputs = await s.$$(`input[name=${qid}][type=radio]`);
      if (inputs.length >= 5) await inputs[Math.min(val, inputs.length) - 1].evaluate(e => e.click());
    }
  };
  await s.click('text=Suivant →');
  ok(await s.isVisible('text=Merci de répondre à cette question.'), 'validation : questions obligatoires non répondues');
  await likert(4); await s.screenshot({ path: 'shots/mobile-satisfaction.png', fullPage: false }); await s.click('text=Suivant →');
  await likert(3); await s.fill('#q-p_ameliorations textarea', 'Plus de travaux pratiques en laboratoire et des supports de cours.'); await s.click('text=Suivant →');
  await likert(2); await s.click('text=Suivant →');
  // Infrastructures : NA sur internet
  await likert(2); await s.click('#q-i_internet >> text=Non concerné'); await s.click('text=Suivant →');
  // Difficultés
  await s.click('label:has-text("Difficultés financières")'); await s.click('label:has-text("Autres")');
  await s.click('text=Suivant →');
  ok(await s.isVisible('text=Merci de préciser'), 'précision exigée pour « Autres »');
  await s.fill('input[placeholder^="Précise"]', 'Transport jusqu\'à l\'école');
  await s.click('#q-d_principale >> text=Difficultés financières');
  await s.click('#q-d_duree >> text=De 3 à 6 mois'); await s.click('#q-d_perturbation >> text=Oui, un peu');
  await s.screenshot({ path: 'shots/mobile-difficultes.png', fullPage: true });
  await s.click('text=Suivant →');
  await s.fill('#q-s_trois_priorites textarea', '1. Le wifi\n2. Des toilettes propres\n3. Des tables en bon état');
  await s.fill('#q-s_message_direction textarea', 'Merci pour vos efforts, continuez à nous écouter.');
  await s.click('#q-s_note_globale >> text=7');
  await s.click('text=Vérifier mes réponses');
  ok(await s.isVisible('text=Vérifie tes réponses'), 'récapitulatif avant soumission');
  await s.click('text=Précédent'); ok(await s.isVisible('text=Suggestions et recommandations'), 'retour à la rubrique précédente possible');
  ok((await s.inputValue('#q-s_trois_priorites textarea')).includes('wifi'), 'réponses conservées en revenant en arrière');
  await s.click('text=Vérifier mes réponses');
  await s.click('text=Confirmer et envoyer mon avis');
  await s.waitForURL(/merci/);
  await s.screenshot({ path: 'shots/mobile-merci.png', fullPage: true });
  ok(true, 'soumission réussie, page de remerciement');
  await s.goto(BASE + '/questionnaire');
  ok(await s.isVisible('text=Une participation a déjà été envoyée'), 'avertissement anti-doublon sur le même appareil');
  const cookies = await sctx.cookies();
  ok(cookies.length === 0, `aucun cookie déposé chez l'étudiant (${cookies.length})`);
  const ls = await s.evaluate(() => Object.keys(localStorage));
  ok(ls.every(k => k.startsWith('esupex-participation-')), 'stockage local : uniquement le drapeau de participation (' + ls.join(',') + ')');
  await sctx.close();
  fs.writeFileSync('admin-state.json', JSON.stringify(await ctx.storageState()));
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
