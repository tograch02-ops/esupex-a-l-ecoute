// Mini-passerelle imitant l'API Supabase (REST via PostgREST + Auth minimal) pour les tests de bout en bout.
import http from 'node:http';
import crypto from 'node:crypto';
const SECRET = 'un-secret-de-test-tres-long-pour-hs256-0123456789';
const b64 = (o) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');
export const sign = (p) => { const h = b64({ alg: 'HS256', typ: 'JWT' }), b = b64(p); return `${h}.${b}.${crypto.createHmac('sha256', SECRET).update(`${h}.${b}`).digest('base64url')}`; };
const verify = (t) => { const [h, b, s] = (t || '').split('.'); if (!s || crypto.createHmac('sha256', SECRET).update(`${h}.${b}`).digest('base64url') !== s) return null; return JSON.parse(Buffer.from(b, 'base64url')); };
const USERS = { 'direction@esupex.bf': { id: '11111111-1111-1111-1111-111111111111', pw: 'MotDePasse!2026' }, 'intrus@esupex.bf': { id: '22222222-2222-2222-2222-222222222222', pw: 'Intrus!2026' } };
const userObj = (email, id) => ({ id, aud: 'authenticated', role: 'authenticated', email, app_metadata: {}, user_metadata: {}, created_at: '2026-01-01T00:00:00Z' });
const log = [];
http.createServer(async (req, res) => {
  const chunks = []; for await (const c of req) chunks.push(c); const body = Buffer.concat(chunks);
  const u = new URL(req.url, 'http://x');
  log.push(`${req.method} ${u.pathname} ip=${req.socket.remoteAddress} xff=${req.headers['x-forwarded-for'] ?? '-'}`);
  const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*' };
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  if (u.pathname === '/__log') { res.writeHead(200, cors); return res.end(log.join('\n')); }
  if (u.pathname.startsWith('/auth/v1/token')) {
    const { email, password } = JSON.parse(body.toString() || '{}'); const usr = USERS[email];
    if (!usr || usr.pw !== password) { res.writeHead(400, { ...cors, 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: 'invalid_grant', error_description: 'Invalid login credentials', code: 'invalid_credentials' })); }
    const exp = Math.floor(Date.now() / 1000) + 3600;
    const tok = sign({ sub: usr.id, role: 'authenticated', email, aud: 'authenticated', exp });
    res.writeHead(200, { ...cors, 'content-type': 'application/json' });
    return res.end(JSON.stringify({ access_token: tok, token_type: 'bearer', expires_in: 3600, expires_at: exp, refresh_token: 'rt-' + usr.id, user: userObj(email, usr.id) }));
  }
  if (u.pathname === '/auth/v1/user') {
    const p = verify((req.headers.authorization || '').replace('Bearer ', ''));
    if (!p || !p.sub) { res.writeHead(401, { ...cors, 'content-type': 'application/json' }); return res.end('{"msg":"invalid"}'); }
    res.writeHead(200, { ...cors, 'content-type': 'application/json' }); return res.end(JSON.stringify(userObj(p.email, p.sub)));
  }
  if (u.pathname === '/auth/v1/logout') { res.writeHead(204, cors); return res.end(); }
  if (u.pathname.startsWith('/rest/v1/')) {
    const headers = { ...req.headers }; delete headers.host; delete headers['content-length'];
    const r = await fetch(`http://localhost:3001${u.pathname.slice(8)}${u.search}`, { method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : body });
    const out = Buffer.from(await r.arrayBuffer()); const h = { ...cors };
    r.headers.forEach((v, k) => { if (!['content-encoding', 'transfer-encoding', 'content-length'].includes(k)) h[k] = v; });
    res.writeHead(r.status, h); return res.end(out);
  }
  res.writeHead(404); res.end();
}).listen(54321, () => console.log('passerelle prête'));
