const { chromium } = require('playwright');
const fs = require('fs');
const { execSync } = require('child_process');
const BASE = 'http://localhost:3000';
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const FIL = ['Génie civil', 'Électrotechnique', 'Maintenance industrielle', 'Électronique et informatique industrielle', 'Réseaux informatiques et télécommunications', 'Systèmes d\'information et réseaux'];
const NIV = ['Licence 1', 'Licence 2', 'Licence 3'];
const COMM = ['Améliorer le wifi et la connexion internet', 'Des toilettes plus propres', 'Plus de matériel dans les laboratoires pour les TP', 'Respecter les horaires et l\'emploi du temps', 'Délivrer plus vite les attestations et relevés de notes', 'Mieux communiquer les informations importantes', 'Réduire les frais de scolarité', 'Aider à trouver des stages en entreprise', 'Ventilateurs dans les salles, il fait trop chaud', 'Les enseignants expliquent bien'];
let seed = 7; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
(async () => {
  const campagneId = execSync(`psql -h /tmp -p 5433 -U postgres -d e2e -tAc "select id from campagnes where statut='ouverte'"`).toString().trim();
  // ---- Données de DÉMONSTRATION (environnement de test uniquement) envoyées via l'API publique
  let envoyes = 0;
  for (let i = 0; i < 44; i++) {
    const fil = FIL[i % 6 === 5 ? 0 : i % 6], niv = NIV[Math.floor(rnd() * 3)];
    const base = fil === 'Génie civil' ? 3.6 : fil === 'Électrotechnique' ? 3.0 : 2.6;
    const r = {};
    const note = (b) => Math.max(1, Math.min(5, Math.round(b + (rnd() - 0.5) * 2.4)));
    for (const id of ['g_satisfaction_esupex','g_qualite_formation','g_adequation_attentes','g_encadrement','g_prestations_attentes','g_recommandation','p_maitrise','p_disponibilite','p_explications','p_horaires','p_programme','p_evaluations','p_resultats','p_tp','p_supports','p_accompagnement','a_accueil','a_disponibilite','a_traitement','a_inscriptions','a_documents','a_communication','a_informations','a_reclamations','a_transparence']) r[id] = note(base + (id.startsWith('p_m') ? 0.8 : id.startsWith('a_t') ? -0.9 : 0));
    for (const id of ['i_salles','i_capacite','i_mobilier','i_eclairage','i_informatique','i_laboratoires','i_sanitaires','i_proprete','i_espaces','i_securite','i_internet']) r[id] = rnd() < 0.1 ? 'NA' : note(base - (id === 'i_internet' ? 1.6 : id === 'i_sanitaires' ? 1.1 : 0.3));
    const diffs = ['Difficultés financières','Difficultés liées aux infrastructures','Difficultés liées aux équipements et aux travaux pratiques','Difficultés de communication','Difficultés administratives'].filter(() => rnd() < 0.4);
    if (diffs.length) { r.d_categories = diffs; r.d_principale = diffs[0]; r.d_duree = 'Plus de 6 mois'; r.d_perturbation = rnd() < 0.5 ? 'Oui, un peu' : 'Non'; } else r.d_categories = ['Aucune difficulté particulière'];
    r.s_trois_priorites = COMM[i % 10] + '. ' + COMM[(i * 3 + 1) % 10];
    if (i % 3 === 0) r.s_message_direction = COMM[(i + 5) % 10];
    r.s_note_globale = Math.round(base * 2 + (rnd() - 0.5) * 3);
    const res = await fetch(BASE + '/api/soumettre', { method: 'POST', headers: { 'content-type': 'application/json', 'x-forwarded-for': '41.203.12.' + i }, body: JSON.stringify({ campagneId, filiere: fil, niveau: niv, anneeAcademique: '2025-2026', reponses: r }) });
    if (res.ok) envoyes++; else console.log(await res.text());
  }
  ok(envoyes === 44, `44 réponses de démonstration acceptées via l'API publique (${envoyes})`);

  // ---- Tentatives malveillantes sur l'API publique
  const post = (b) => fetch(BASE + '/api/soumettre', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b) });
  let res = await post({ campagneId, filiere: 'Génie civil', niveau: 'Licence 1', anneeAcademique: '2025-2026', reponses: { g_satisfaction_esupex: 99 } });
  ok(res.status === 422, 'API : note hors échelle refusée (' + res.status + ')');
  res = await post({ campagneId, filiere: 'Médecine', niveau: 'Licence 1', anneeAcademique: '2025-2026', reponses: {} });
  ok(res.status === 422, 'API : questionnaire incomplet / filière inconnue refusés (' + res.status + ')');
  res = await post({ campagneId: '00000000-0000-0000-0000-000000000000', filiere: 'Génie civil', niveau: 'Licence 1', anneeAcademique: '2025-2026', reponses: {} });
  ok(res.status === 409, 'API : campagne inexistante refusée');
  const avant = execSync(`psql -h /tmp -p 5433 -U postgres -d e2e -tAc "select count(*) from reponses"`).toString().trim();
  res = await post({ campagneId, filiere: 'Génie civil', niveau: 'Licence 1', anneeAcademique: '2025-2026', reponses: {}, site_web: 'spam' });
  const apres = execSync(`psql -h /tmp -p 5433 -U postgres -d e2e -tAc "select count(*) from reponses"`).toString().trim();
  ok(res.ok && avant === apres, 'API : robot (champ piège) ignoré silencieusement');
  const anonKey = fs.readFileSync('anon.key', 'utf8').trim();
  const direct = await fetch('http://localhost:54321/rest/v1/reponses?select=*', { headers: { apikey: anonKey, Authorization: 'Bearer ' + anonKey } });
  ok((await direct.json()).length === 0, 'base : la clé publique ne permet PAS de lire les réponses');

  // ---- Anonymat : contenu stocké
  const cols = execSync(`psql -h /tmp -p 5433 -U postgres -d e2e -tAc "select string_agg(column_name, ',') from information_schema.columns where table_name='reponses'"`).toString().trim();
  ok(!/ip|mail|nom|tel|user|agent/.test(cols), 'table reponses sans colonne identifiante : ' + cols);
  const blob = execSync(`psql -h /tmp -p 5433 -U postgres -d e2e -tAc "select string_agg(reponses::text, ' ') from reponses"`).toString();
  ok(!blob.includes('41.203.12'), 'aucune adresse IP présente dans les réponses stockées');
  const gw = await (await fetch('http://localhost:54321/__log')).text();
  ok(!gw.includes('41.203.12'), 'l\'adresse IP des étudiants n\'atteint jamais la base (requêtes émises par le serveur)');

  // ---- Tableau de bord
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1360, height: 900 }, acceptDownloads: true, storageState: 'admin-state.json' });
  const p = await ctx.newPage();
  await p.goto(BASE + '/admin');
  await p.waitForSelector('text=Domaines d\'intervention prioritaire');
  const txt = await p.innerText('main');
  ok(txt.includes('45'), 'tableau de bord : 45 participants');
  ok(/Accès à Internet/.test(txt), 'priorités : accès Internet remonte parmi les points faibles');
  await p.screenshot({ path: 'shots/admin-tableau-de-bord.png', fullPage: true });
  // filtre petit groupe
  await p.goto(BASE + '/admin?filiere=Maintenance%20industrielle&niveau=Licence%201');
  const t2 = await p.innerText('main');
  ok(/masqués pour protéger|Effectif insuffisant/.test(t2) || /Domaines/.test(t2), 'filtres fonctionnels ; petits groupes masqués si sous le seuil');
  await p.screenshot({ path: 'shots/admin-filtre-petit-groupe.png', fullPage: false });
  // exports
  await p.goto(BASE + '/admin');
  for (const [label, ext] of [['Export Excel', 'xlsx'], ['Export CSV', 'csv'], ['Rapport PDF', 'pdf']]) {
    const [d] = await Promise.all([p.waitForEvent('download'), p.click(`text=${label}`)]);
    const path = `exports/demo.${ext}`; await d.saveAs(path);
    ok(fs.statSync(path).size > 1000, `${label} téléchargé (${fs.statSync(path).size} octets)`);
  }
  // commentaires
  await p.goto(BASE + '/admin/commentaires');
  await p.waitForSelector('text=Thèmes récurrents');
  await p.click('text=Internet, Wi-Fi et ressources numériques');
  ok(await p.isVisible('text=« Améliorer le wifi et la connexion internet »'), 'commentaires : thème → commentaires originaux vérifiables');
  await p.screenshot({ path: 'shots/admin-commentaires.png', fullPage: true });
  // paramètres
  await p.goto(BASE + '/admin/parametres');
  await p.getByLabel('Génie civil – Licence 1', { exact: true }).fill('60');
  await p.click('text=Enregistrer les effectifs 2026-2027');
  await p.waitForTimeout(800);
  await p.goto(BASE + '/admin/parametres?annee=2025-2026');
  for (const f of FIL) for (const n of NIV) await p.getByLabel(`${f} – ${n}`, { exact: true }).fill('40');
  await p.click('text=Enregistrer les effectifs 2025-2026');
  await p.waitForTimeout(800);
  await p.goto(BASE + '/admin');
  ok((await p.innerText('main')).includes('Taux de participation : 6,3 %'), 'taux de participation calculé (45 / 720)');
  await p.screenshot({ path: 'shots/admin-tableau-de-bord.png', fullPage: true });
  await p.goto(BASE + '/admin/parametres'); await p.screenshot({ path: 'shots/admin-parametres.png', fullPage: true });
  // déconnexion
  await p.click('text=Déconnexion'); await p.waitForURL(/connexion/);
  const r2 = await ctx.request.get(BASE + '/api/admin/export?format=csv', { maxRedirects: 0 });
  ok(r2.status() === 401 || r2.status() === 403, 'après déconnexion, export refusé (' + r2.status() + ')');
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
