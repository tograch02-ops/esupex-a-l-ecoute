# Tests de bout en bout et de sécurité

Ces tests reproduisent localement l'environnement Supabase (PostgreSQL 16 + PostgREST 12 + une mini-passerelle d'authentification `gateway.mjs`) afin de tester l'application réelle dans un navigateur (Playwright).

1. **Sécurité de la base (RLS)** : `supabase_stub.sql`, `schema.sql`, puis `test_rls.sql` sur une base vide (14 vérifications : accès anonyme, non-admin, admin, intégrité).
2. **Parcours complet** : `stub.sql` + `schema.sql` dans une base `e2e`, lancer `postgrest pgrst.conf` et `node gateway.mjs`, construire l'application avec `NEXT_PUBLIC_SUPABASE_URL=http://localhost:54321` et une clé anon signée avec le secret de `pgrst.conf`, puis exécuter `e2e-partie1.cjs` (admin, création/ouverture de campagne, questionnaire sur smartphone) et `e2e-partie2.cjs` (44 réponses de démonstration, attaques sur l'API, anonymat, tableau de bord, exports, commentaires, paramètres).

Les comptes utilisés (`direction@esupex.bf`, `intrus@esupex.bf`) et les réponses générées sont des **données de démonstration** propres à cet environnement de test. Elles n'existent pas dans la base de production.
