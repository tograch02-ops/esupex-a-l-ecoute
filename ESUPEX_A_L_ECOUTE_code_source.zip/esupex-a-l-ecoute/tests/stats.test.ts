import { describe, expect, it } from 'vitest';
import { calculerStatistiques, scoreIndividuel } from '@/lib/stats';
import { DEFAULT_QUESTIONNAIRE as Q, sanitizeAnswers, AUCUNE_DIFFICULTE, questionnaireSchema } from '@/lib/questionnaire';
import { analyserThemes, extraireCommentaires, themesDe } from '@/lib/themes';
import { versCsv } from '@/lib/export';

const rep = (filiere: string, niveau: string, sat: number, extra: Record<string, unknown> = {}) => ({
  filiere,
  niveau,
  annee_academique: '2025-2026',
  reponses: { g_satisfaction_esupex: sat, s_note_globale: sat * 2, d_categories: [AUCUNE_DIFFICULTE], ...extra } as never,
});

describe('questionnaire par défaut', () => {
  it('est valide selon son propre schéma', () => {
    expect(questionnaireSchema.safeParse(Q).success).toBe(true);
  });
  it('comporte 6 rubriques + le profil = 7 rubriques', () => {
    expect(Q.sections.length).toBe(6);
  });
});

describe('calculs statistiques', () => {
  const lignes = [
    rep('Génie civil', 'Licence 1', 5, { p_maitrise: 4, p_disponibilite: 2, i_internet: 'NA' }),
    rep('Génie civil', 'Licence 1', 4, { p_maitrise: 5, i_internet: 1 }),
    rep('Génie civil', 'Licence 2', 2, { p_maitrise: 3, i_internet: 2 }),
    rep('Génie civil', 'Licence 2', 1, { p_maitrise: 1, i_internet: 1 }),
    rep('Électrotechnique', 'Licence 3', 3, { p_maitrise: 4, i_internet: 2 }),
    rep('Électrotechnique', 'Licence 3', 4, { p_maitrise: 4 }),
  ];
  const s = calculerStatistiques(lignes, Q, {
    seuil: 3,
    effectifs: [
      { annee_academique: '2025-2026', filiere: 'Génie civil', niveau: 'Licence 1', effectif: 10 },
      { annee_academique: '2025-2026', filiere: 'Électrotechnique', niveau: 'Licence 3', effectif: 10 },
    ],
  });

  it('moyenne et pourcentages de satisfaction générale', () => {
    // (5+4+2+1+3+4)/6 = 3.1667
    expect(s.indicateurs.satisfactionGlobale).toBe(3.17);
    expect(s.indicateurs.pctSatisfaits).toBe(50); // 5,4,4
    expect(s.indicateurs.pctInsatisfaits).toBe(33.3); // 2,1
    expect(s.indicateurs.pctMoyennementSatisfaits).toBe(16.7);
  });

  it('note globale sur 10', () => {
    expect(s.indicateurs.noteGlobale).toBe(6.33);
  });

  it('« non concerné » exclu des moyennes', () => {
    const it = s.items.find((i) => i.id === 'i_internet')!;
    expect(it.n).toBe(4);
    expect(it.nNA).toBe(1);
    expect(it.moyenne).toBe(1.5);
    expect(it.distribution).toEqual([2, 2, 0, 0, 0]);
  });

  it('score de dimension = moyenne des moyennes individuelles', () => {
    expect(scoreIndividuel({ p_maitrise: 4, p_disponibilite: 2 }, ['p_maitrise', 'p_disponibilite', 'p_tp'])).toBe(3);
    // individus : 3, 5, 3, 1, 4, 4 -> 20/6
    expect(s.indicateurs.pedagogie).toBe(3.33);
  });

  it('masque les groupes sous le seuil', () => {
    const gc = s.comparaisons.filiere.find((g) => g.groupe === 'Génie civil')!;
    const el = s.comparaisons.filiere.find((g) => g.groupe === 'Électrotechnique')!;
    expect(gc.masque).toBe(false);
    expect(gc.satisfactionGlobale).toBe(3);
    expect(el.n).toBe(2);
    expect(el.masque).toBe(true);
    expect(el.satisfactionGlobale).toBeNull();
  });

  it('masque tout quand le total est sous le seuil', () => {
    const t = calculerStatistiques(lignes.slice(0, 2), Q, { seuil: 5 });
    expect(t.masque).toBe(true);
    expect(t.indicateurs.satisfactionGlobale).toBeNull();
    expect(t.items.every((i) => i.moyenne === null)).toBe(true);
    expect(t.total).toBe(2);
  });

  it('taux de participation', () => {
    expect(s.participation.effectifReference).toBe(20);
    expect(s.participation.taux).toBe(30);
  });

  it('priorités : élément le moins bien évalué en tête', () => {
    expect(s.priorites.moinsBienEvalues[0].id).toBe('i_internet');
    expect(s.priorites.mieuxEvalues[0].id).toBe('p_maitrise'); // (4+5+3+1+4+4)/6 = 3,5
  });
});

describe('validation serveur des réponses', () => {
  const complet: Record<string, unknown> = {};
  for (const sec of Q.sections) for (const q of sec.questions) if (q.type === 'likert') complet[q.id] = 3;
  complet.d_categories = [AUCUNE_DIFFICULTE];
  complet.s_note_globale = 7;

  it('accepte un questionnaire complet', () => {
    const r = sanitizeAnswers(Q, complet);
    expect(r.ok).toBe(true);
  });
  it('refuse une note hors échelle', () => {
    expect(sanitizeAnswers(Q, { ...complet, g_satisfaction_esupex: 9 }).ok).toBe(false);
  });
  it('refuse NA sur une question qui ne le permet pas', () => {
    expect(sanitizeAnswers(Q, { ...complet, g_satisfaction_esupex: 'NA' }).ok).toBe(false);
  });
  it('refuse une réponse obligatoire manquante', () => {
    const { s_note_globale, ...sans } = complet;
    expect(sanitizeAnswers(Q, sans).ok).toBe(false);
  });
  it('ignore les champs inconnus (aucune donnée parasite stockée)', () => {
    const r = sanitizeAnswers(Q, { ...complet, nom: 'Ouédraogo', telephone: '70000000' });
    expect(r.ok && 'nom' in r.answers).toBe(false);
  });
  it('exige les questions conditionnelles si une difficulté est cochée', () => {
    expect(sanitizeAnswers(Q, { ...complet, d_categories: ['Difficultés financières'] }).ok).toBe(false);
    const r = sanitizeAnswers(Q, {
      ...complet,
      d_categories: ['Difficultés financières', AUCUNE_DIFFICULTE],
    });
    // « Aucune » est exclusive : elle l'emporte et les questions conditionnelles disparaissent.
    expect(r.ok).toBe(true);
  });
  it('exige la précision pour « Autres »', () => {
    const base = { ...complet, d_categories: ['Autres'], d_principale: 'Autres', d_duree: 'De 1 à 3 mois', d_perturbation: 'Non' };
    expect(sanitizeAnswers(Q, base).ok).toBe(false);
    expect(sanitizeAnswers(Q, { ...base, d_categories_autre: 'Transport' }).ok).toBe(true);
  });
});

describe('analyse des commentaires', () => {
  it('détecte les thèmes sans tenir compte des accents', () => {
    expect(themesDe('Le WIFI ne marche jamais')).toContain('internet');
    expect(themesDe('Les toilettes sont sales')).toContain('sanitaires');
    expect(themesDe('Améliorer la propreté et l’hygiène')).toContain('sanitaires');
  });
  it('conserve les commentaires originaux et compte par thème', () => {
    const c = extraireCommentaires(
      [{ reponses: { s_trois_priorites: 'Internet et salles climatisées' } }, { reponses: { s_trois_priorites: 'Le wifi' } }, { reponses: { s_trois_priorites: 'Rien à dire de spécial' } }],
      Q,
    );
    const r = analyserThemes(c);
    expect(r.total).toBe(3);
    expect(r.themes[0]).toMatchObject({ id: 'internet', n: 2 });
    expect(r.themes[0].commentaires[0].texte).toBe('Internet et salles climatisées');
    expect(r.nonClasses.length).toBe(1);
  });
});

describe('export CSV', () => {
  it('BOM, séparateur ; et neutralisation des formules', () => {
    const csv = versCsv([{ cle: 'a', titre: 'A' }, { cle: 'b', titre: 'B' }], [{ a: '=SOMME(1)', b: 'x;y' }]);
    expect(csv.startsWith('﻿A;B')).toBe(true);
    expect(csv).toContain("'=SOMME(1)");
    expect(csv).toContain('"x;y"');
  });
});
