import type { Config } from 'tailwindcss';

// Couleurs de la charte : remplacer les valeurs ci-dessous par celles de la
// charte graphique officielle de l'ESUPEX (voir docs/GUIDE_DEPLOIEMENT.md).
const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        marque: {
          50: '#eef4fb',
          100: '#d6e4f5',
          200: '#adc8ea',
          500: '#1f5fa8',
          600: '#174d8c',
          700: '#123d70',
          900: '#0b2545',
        },
        accent: {
          100: '#fdf0d5',
          500: '#e0a526',
          600: '#c38b14',
        },
      },
      fontFamily: {
        // Polices système : aucun appel à un service de polices externe.
        sans: ['system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
export default config;
