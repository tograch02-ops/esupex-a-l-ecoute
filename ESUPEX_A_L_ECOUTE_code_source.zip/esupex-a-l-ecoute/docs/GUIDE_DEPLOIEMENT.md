# Guide de déploiement : ESUPEX À L'ÉCOUTE

Ce guide permet d'obtenir, en une heure environ et sans frais, les deux liens attendus :

- **le lien public des étudiants** : `https://<votre-projet>.vercel.app/`
- **le lien privé de la direction** : `https://<votre-projet>.vercel.app/admin`

Il faut créer trois comptes gratuits : **GitHub** (pour héberger le code), **Supabase** (base de données) et **Vercel** (hébergement). Les offres gratuites suffisent largement pour une école de plusieurs milliers d'étudiants.

> Pour le premier déploiement, utilisez une adresse e-mail institutionnelle de l'ESUPEX (et non une adresse personnelle), afin que l'école reste propriétaire des comptes.

---

## Étape 1 : Créer la base de données Supabase

1. Allez sur <https://supabase.com>, cliquez sur **Start your project** et connectez-vous avec GitHub.
2. Cliquez sur **New project** :
   - **Name** : `esupex-a-l-ecoute`
   - **Database Password** : générez un mot de passe fort et conservez-le en lieu sûr.
   - **Region** : choisissez la région la plus proche disponible (par exemple *West EU (Paris)* ou *Central EU (Frankfurt)*).
3. Attendez environ 2 minutes que le projet soit prêt.

### 1.1 Installer le schéma

1. Dans le menu de gauche, ouvrez **SQL Editor**, puis **New query**.
2. Ouvrez le fichier `supabase/schema.sql` du projet, copiez **tout** son contenu, collez-le, puis cliquez sur **Run**.
3. Le message *Success. No rows returned* doit s'afficher. Dans **Table Editor**, vous devez voir 8 tables : `filieres`, `niveaux`, `annees_academiques`, `parametres`, `campagnes`, `reponses`, `effectifs`, `admins`.

Les six filières, les trois niveaux et les années 2025-2026 et 2026-2027 sont déjà insérés. Vous pourrez les modifier depuis l'espace admin.

### 1.2 Sécuriser l'authentification

1. Ouvrez **Authentication > Sign In / Providers** (selon la version : *Authentication > Providers*).
2. Désactivez **Allow new users to sign up**. Seuls les comptes que vous créez vous-même pourront alors exister.
3. Laissez le fournisseur **Email** activé.

### 1.3 Créer le premier compte administrateur

1. Ouvrez **Authentication > Users > Add user > Create new user**.
2. Saisissez l'e-mail du responsable (par exemple `direction@esupex.bf`) et un mot de passe fort. Cochez **Auto Confirm User**.
3. Retournez dans **SQL Editor** et exécutez le contenu de `supabase/ajouter-admin.sql` après avoir remplacé l'adresse e-mail :

```sql
insert into public.admins (user_id, email)
select id, email from auth.users where email = 'direction@esupex.bf'
on conflict (user_id) do nothing;
```

Un compte qui existe dans Supabase sans figurer dans la table `admins` peut se connecter, mais il est refusé à l'entrée du tableau de bord. Il n'a accès à aucune réponse.

### 1.4 Récupérer les deux clés publiques

Ouvrez **Project Settings > API** (ou **Data API**) et notez :

- **Project URL**, par exemple `https://abcdxyz.supabase.co`
- la clé **anon public**, qui commence par `eyJ…` (selon la version, elle peut s'appeler *publishable key*)

Ces deux valeurs sont publiques par conception : la sécurité repose sur les règles RLS installées à l'étape 1.1. **N'utilisez jamais la clé `service_role`** : l'application n'en a pas besoin.

---

## Étape 2 : Déposer le code sur GitHub

1. Créez un compte sur <https://github.com> si nécessaire.
2. Cliquez sur **New repository**, nommez-le `esupex-a-l-ecoute`, choisissez **Private**, puis cliquez sur **Create repository**.
3. Sur la page du dépôt vide, cliquez sur **uploading an existing file**, glissez-déposez **tout le contenu** du dossier du projet (sauf `node_modules` et `.next` s'ils existent), puis cliquez sur **Commit changes**.

Vous pouvez aussi passer par la ligne de commande :

```bash
cd esupex-a-l-ecoute
git init && git add . && git commit -m "ESUPEX À L'ÉCOUTE v1"
git branch -M main
git remote add origin https://github.com/<compte>/esupex-a-l-ecoute.git
git push -u origin main
```

---

## Étape 3 : Mettre en ligne sur Vercel

1. Allez sur <https://vercel.com>, puis cliquez sur **Sign Up** et choisissez **Continue with GitHub**.
2. Cliquez sur **Add New… > Project**, puis **Import** sur le dépôt `esupex-a-l-ecoute`.
3. Le *Framework Preset* doit indiquer **Next.js**. Ne modifiez pas les commandes de build.
4. Dépliez **Environment Variables** et ajoutez :

| Name | Value |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | la Project URL notée en 1.4 |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | la clé anon public notée en 1.4 |
| `ANTHROPIC_API_KEY` *(facultatif)* | clé de l'API Claude, uniquement pour activer la synthèse IA des commentaires |

5. Cliquez sur **Deploy**. Après environ 2 minutes, Vercel affiche l'adresse du site, par exemple `https://esupex-a-l-ecoute.vercel.app`.

**Vous disposez maintenant des deux liens :**

- étudiants : `https://esupex-a-l-ecoute.vercel.app/`
- direction : `https://esupex-a-l-ecoute.vercel.app/admin`

> Si vous modifiez une variable d'environnement plus tard, relancez le déploiement : **Deployments > ⋯ > Redeploy**. Les variables `NEXT_PUBLIC_…` sont intégrées au moment de la construction du site.

### 3.1 (Facultatif) Nom de domaine de l'école

Pour utiliser par exemple `avis.esupex.bf`, ouvrez **Settings > Domains** dans Vercel, ajoutez le domaine, puis créez chez votre hébergeur DNS l'enregistrement CNAME indiqué par Vercel.

### 3.2 Réglages de confidentialité à vérifier dans Vercel

- **Analytics** et **Speed Insights** : laissez-les **désactivés**. Ils ne sont pas utilisés par l'application.
- Ne branchez aucun outil de suivi tiers (Google Analytics, pixel publicitaire, etc.).

---

## Étape 4 : Personnaliser l'identité visuelle

- **Logo** : remplacez `public/logo-esupex.svg` par le logo officiel, en conservant le même nom de fichier. Un PNG fonctionne aussi : renommez-le en `logo-esupex.png` et remplacez `logo-esupex.svg` par `logo-esupex.png` dans `src/components/EnTete.tsx`, `src/app/admin/connexion/page.tsx` et `src/app/admin/(espace)/layout.tsx`.
- **Couleurs** : dans `tailwind.config.ts`, remplacez les valeurs de `marque` (couleur principale) et `accent` (couleur secondaire) par celles de la charte de l'ESUPEX.

Enregistrez les modifications dans GitHub : Vercel redéploie alors automatiquement le site.

---

## Étape 5 : Vérifications avant le lancement officiel

À réaliser avec l'administrateur, dans l'ordre :

1. **Connexion admin** : ouvrez `/admin`, connectez-vous, puis créez une campagne de test et ouvrez-la.
2. **Parcours étudiant** : sur un smartphone, ouvrez le lien public, remplissez le questionnaire jusqu'au bout et vérifiez l'affichage de la page « Merci ».
3. **Enregistrement** : dans l'admin, le tableau de bord doit indiquer 1 participant. Les résultats restent masqués tant que le seuil de confidentialité (5 réponses par défaut) n'est pas atteint.
4. **Étanchéité** : ouvrez dans un navigateur l'adresse ci-dessous en remplaçant les deux valeurs. Le résultat doit être `[]`, ce qui confirme que la clé publique ne permet pas de lire les réponses.
   `https://<project>.supabase.co/rest/v1/reponses?select=*&apikey=<clé anon>`
5. **Exports** : téléchargez les fichiers Excel, CSV et PDF.
6. **Test pilote** : faites remplir le questionnaire par un petit groupe d'étudiants (10 à 15), recueillez leurs remarques, puis effacez les réponses de test (**Campagnes > Gérer > Zone sensible**).
7. **Lancement** : créez la campagne officielle, ouvrez-la, puis diffusez le lien (WhatsApp, affichage, QR code).

---

## Ce que garantit réellement l'anonymat, et ses limites

**Garanties par construction (vérifiées par les tests) :**

- La table `reponses` ne contient aucune colonne d'identité : pas de nom, d'e-mail, de téléphone, d'adresse IP, d'identifiant de compte ni d'empreinte de navigateur.
- La date est enregistrée **au jour près**, sans heure.
- Les réponses sont envoyées à la base **par le serveur de l'application**, pas par le téléphone de l'étudiant. La base de données ne voit donc jamais l'adresse IP des étudiants.
- La partie étudiante ne dépose **aucun cookie** et n'utilise aucun traceur. Les polices sont celles du système : aucun appel à Google.
- La clé publique ne permet ni de lire, ni de modifier, ni d'insérer directement des réponses. Seule la fonction contrôlée `submit_response` peut enregistrer une réponse.
- Les statistiques et les commentaires des groupes de moins de 5 réponses (seuil réglable) ne sont pas affichés. Les commentaires sont présentés sans filière ni niveau.

**Limites à connaître et à expliquer honnêtement :**

- **Journaux techniques de l'hébergeur.** Comme tout site web, Vercel conserve des journaux d'accès techniques pendant une durée limitée (de l'ordre de quelques heures à quelques jours selon l'offre), qui peuvent contenir l'adresse IP des visiteurs. Ces journaux ne contiennent pas les réponses, et aucune donnée stockée ne permet de relier une réponse à une ligne de journal (pas d'identifiant de requête ni d'heure enregistrés). Aucun administrateur de l'école n'a besoin d'y accéder.
- **Anti-doublon.** Après envoi, un simple indicateur est enregistré **dans le navigateur de l'étudiant** (pas sur le serveur). Il affiche un avertissement si quelqu'un tente de répondre à nouveau depuis le même appareil, tout en permettant à un autre étudiant d'utiliser un téléphone partagé. Ce mécanisme ne relie jamais une réponse à une personne, mais il est **contournable** : navigation privée, autre navigateur ou autre appareil. Un contrôle plus strict exigerait d'identifier les étudiants, ce qui est incompatible avec l'anonymat demandé. Les éventuels doublons restent marginaux et peu influents sur les moyennes d'un effectif important.
- **Contenu des commentaires.** Si un étudiant écrit lui-même son nom ou un détail très personnel dans un champ libre, ce texte est enregistré tel quel. Le questionnaire l'invite à ne pas le faire.
- **Exports.** Les fichiers Excel et CSV contiennent toutes les réponses brutes. Ils doivent être conservés de manière sécurisée et ne pas être diffusés hors de la direction.

---

## Sauvegardes

- Supabase effectue des sauvegardes automatiques quotidiennes sur les offres payantes. Sur l'offre gratuite, faites un **export Excel complet à la clôture de chaque campagne** et archivez-le sur un support de l'école.
- Sauvegarde complète de la base (option technique) : **Database > Backups**, ou `pg_dump` avec la chaîne de connexion indiquée dans **Project Settings > Database**.
- Sur l'offre gratuite, un projet Supabase **inactif pendant 7 jours est mis en pause**. Il suffit de le réactiver depuis le tableau de bord Supabase avant d'ouvrir une nouvelle campagne. Les données ne sont pas perdues.

---

## Développement local (pour un informaticien)

```bash
npm install
cp .env.example .env.local   # puis renseigner les deux variables Supabase
npm run dev                  # http://localhost:3000
npm test                     # tests unitaires (calculs statistiques, validation, thèmes, export)
npm run build                # vérification de compilation
```

Les tests de bout en bout et de sécurité (RLS) sont décrits dans `tests/e2e/LISEZMOI.md`.
