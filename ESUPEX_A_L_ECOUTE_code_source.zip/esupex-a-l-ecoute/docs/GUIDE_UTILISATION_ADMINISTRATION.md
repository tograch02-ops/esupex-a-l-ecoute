# Guide d'utilisation de l'administration : ESUPEX À L'ÉCOUTE

*Observatoire de la satisfaction estudiantine. Document destiné à la direction et au service chargé de la qualité.*

---

## 1. Accéder à l'espace d'administration

- Adresse : `https://<adresse-du-site>/admin`
- Connectez-vous avec l'e-mail et le mot de passe fournis par l'administrateur principal.
- Pour ajouter un collègue, l'administrateur technique crée son compte dans Supabase, puis l'ajoute à la table des administrateurs (voir *Guide de déploiement*, étape 1.3).
- Cliquez toujours sur **Déconnexion** après usage sur un ordinateur partagé.

L'espace comporte quatre onglets : **Tableau de bord**, **Commentaires**, **Campagnes**, **Référentiels et paramètres**.

---

## 2. Cycle de vie d'une campagne

Une **campagne** correspond à une période de recensement, par exemple « Campagne 2026-2027 – Semestre 1 ». Une seule campagne peut être ouverte à la fois : c'est elle qui apparaît sur le lien public.

| Étape | Action dans l'onglet **Campagnes** |
|---|---|
| 1. Préparer | **Nouvelle campagne** : saisir le titre, choisir l'année académique (présélectionnée pour les étudiants) et le questionnaire de départ (standard ou copie d'une campagne précédente). La campagne est créée en *brouillon*. |
| 2. Relire | **Gérer** affiche l'aperçu du questionnaire. Il reste modifiable tant qu'aucune réponse n'a été reçue (voir § 6). |
| 3. Ouvrir | **Ouvrir l'enquête**. Le lien public à diffuser s'affiche en vert. Si une autre campagne était ouverte, elle est clôturée automatiquement. |
| 4. Suivre | Le **Tableau de bord** se met à jour à chaque nouvelle réponse : actualisez simplement la page. |
| 5. Clôturer | **Clôturer l'enquête**. Les étudiants voient alors « Aucune consultation n'est ouverte ». Les résultats restent consultables. |
| 6. Archiver | Téléchargez l'**export Excel** et le **rapport PDF**, puis conservez-les dans les archives de l'école. |

**Conseil :** organisez une campagne par semestre ou par année académique, en conservant le même questionnaire, afin de pouvoir comparer les résultats d'une campagne à l'autre.

**Effacer des réponses de test :** **Gérer > Zone sensible**, tapez `SUPPRIMER`, puis cliquez sur **Effacer les réponses**. Cette action est irréversible.

---

## 3. Lire le tableau de bord

Les **filtres** situés en haut de la page (campagne, filière, niveau, année) s'appliquent à tout le tableau de bord et aux exports.

### A. Indicateurs généraux
- **Participants** : nombre de questionnaires reçus.
- **Taux de participation** : participants divisés par l'effectif de référence. Il n'apparaît que si les effectifs ont été renseignés (voir § 5).
- **Répartition** par filière, niveau et année (en bas de page).

### B. Indicateurs de satisfaction
Échelle : **1** Très insatisfait · **2** Insatisfait · **3** Moyennement satisfait · **4** Satisfait · **5** Très satisfait.

- **Satisfaction générale** : moyenne sur 5 de la question « Satisfaction générale concernant l'ESUPEX ».
- **% satisfaits** = part des notes 4 et 5. **% insatisfaits** = part des notes 1 et 2.
- **Scores par rubrique** (générale, pédagogie, administration, infrastructures) : pour chaque étudiant, on calcule la moyenne de ses réponses dans la rubrique, puis la moyenne de ces moyennes. Chaque étudiant pèse donc autant que les autres.
- Les réponses « **Non concerné / Non disponible** » sont exclues des moyennes. Elles sont comptées dans la colonne *N.C.*
- **Note globale** : moyenne de la note de 0 à 10.

**Repères de lecture :** une moyenne inférieure à 2,5 signale un point critique ; entre 2,5 et 3,4, une situation à améliorer ; à partir de 3,5, un point satisfaisant.

### C. Analyse comparative
Les tableaux comparent les filières, les niveaux (L1, L2, L3) et les années académiques. Plus la case est foncée, meilleur est le score. Le tableau **Évolution entre campagnes** (visible dès qu'au moins deux campagnes existent) constitue le **baromètre** annuel.

### D. Priorités d'intervention
- **Domaines d'intervention prioritaire** : les 5 éléments les moins bien notés, avec le pourcentage d'insatisfaits. Ils répondent directement à la question « quelles sont les cinq actions à entreprendre en priorité ? ».
- **Points forts** : les 5 éléments les mieux notés, à valoriser.
- **Principales difficultés signalées** et **difficulté la plus pénalisante**, avec son ancienneté et son impact sur le parcours.
- **Améliorations les plus demandées** : thèmes les plus fréquents dans la question « trois améliorations prioritaires ».

### Protection de l'anonymat (seuil de confidentialité)
Lorsqu'un groupe compte **moins de 5 réponses** (valeur réglable), ses résultats sont remplacés par « Effectif insuffisant – masqué ». Si la sélection entière est sous le seuil, tout le tableau de bord est masqué. Cette règle empêche de deviner l'avis d'un étudiant appartenant à un petit groupe, par exemple trois étudiants d'une même filière et d'un même niveau.

---

## 4. Analyser les commentaires (onglet Commentaires)

- Les réponses libres sont **regroupées automatiquement par thèmes** : Internet, sanitaires, équipements et TP, enseignants, administration, frais, stages, etc. Un même commentaire peut relever de plusieurs thèmes.
- Cliquez sur un thème pour lire les **commentaires originaux**, sans aucune modification. Chaque commentaire porte une référence (par exemple `R12-s_trois_priorites`) et la question concernée.
- **Question ouverte** : permet de n'analyser qu'une seule question.
- **Rechercher un mot** : retrouve tous les commentaires qui contiennent un mot (par exemple *wifi*, *toilettes*, *stage*).
- **Synthèse assistée par IA** (si elle est activée) : l'IA propose des thèmes résumés. Chaque thème cite les références des commentaires sources : **vérifiez toujours la synthèse à partir de ces commentaires** avant de l'utiliser dans un rapport officiel. Les références inexistantes sont rejetées automatiquement.

Pour protéger l'anonymat, la filière et le niveau de l'auteur ne sont pas affichés à côté des commentaires.

---

## 5. Référentiels et paramètres

- **Filières, niveaux, années académiques** : ajoutez un élément, modifiez l'ordre d'affichage (↑ ↓) ou **désactivez** un élément pour qu'il ne soit plus proposé aux étudiants. Les réponses passées restent intactes. Il n'existe pas de suppression définitive, afin de préserver l'historique.
- **Effectifs de référence** : choisissez l'année, saisissez le nombre d'inscrits par filière et par niveau, puis enregistrez. Le taux de participation s'affiche ensuite automatiquement.
- **Seuil de confidentialité** : la valeur 5 est recommandée. Ne descendez pas en dessous de 3.

---

## 6. Modifier le questionnaire (usage avancé)

Le questionnaire de chaque campagne est enregistré au format JSON. On le modifie depuis **Campagnes > Gérer > Modifier le questionnaire**, **uniquement avant la première réponse**. Ensuite, il est verrouillé pour garantir la cohérence des résultats. Pour faire évoluer le questionnaire, créez une nouvelle campagne « Copie de… » et modifiez la copie.

Types de questions disponibles :

| type | Usage | Exemple |
|---|---|---|
| `likert` | Échelle 1 à 5 ; ajoutez `"allowNA": true` pour proposer « Non concerné » | `{"id":"i_parking","type":"likert","label":"Parking des engins","required":true,"allowNA":true}` |
| `scale10` | Note de 0 à 10 | `{"id":"s_note","type":"scale10","label":"Note globale","required":true}` |
| `text` | Réponse libre (facultative) | `{"id":"s_idee","type":"text","label":"Une idée pour l'école ?","maxLength":1000}` |
| `single` | Choix unique | `{"id":"x_transport","type":"single","label":"Moyen de transport","options":["Moto","Vélo","À pied","Autre"]}` |
| `multi` | Choix multiples | `{"id":"x_services","type":"multi","label":"Services utilisés","options":["Bibliothèque","Salle info","Cafétéria"]}` |

Règles importantes :
- Chaque `id` doit être **unique** et écrit en minuscules, chiffres et `_` uniquement.
- Les questions `likert` sont automatiquement prises en compte dans le score de leur rubrique (`dimension` : `generale`, `pedagogie`, `administration`, `infrastructures`).
- Le bloc `roles` indique les questions clés utilisées par le tableau de bord (satisfaction générale, note globale, difficultés, etc.). Ne supprimez pas ces questions sans mettre `roles` à jour.
- Le contenu est **vérifié avant l'enregistrement** : en cas d'erreur, un message précise le problème et rien n'est modifié.
- **Rétablir le questionnaire standard ESUPEX** permet de revenir au modèle d'origine.

---

## 7. Exports et rapports

| Bouton | Contenu | Usage |
|---|---|---|
| **Export Excel** | Feuilles « Réponses » (une ligne par questionnaire), « Synthèse par élément », « Comparaisons », « Dictionnaire » (codes et échelles) | Analyses complémentaires, archivage |
| **Export CSV** | Réponses brutes (séparateur `;`, s'ouvre directement dans Excel) | Logiciels statistiques (SPSS, R, Sphinx…) |
| **Rapport PDF** | « Baromètre de la satisfaction estudiantine » : indicateurs clés, cinq priorités, points forts, difficultés, améliorations demandées, comparaisons, détail par élément, évolution | Conseil de direction, rapport annuel |

Les exports respectent les filtres sélectionnés. **Les fichiers Excel et CSV contiennent les réponses brutes : ne les diffusez pas en dehors de la direction.**

---

## 8. Bonnes pratiques de diffusion

- Diffusez le lien par les délégués de classe, les groupes WhatsApp de promotion, l'affichage (avec un **QR code**) et l'annonce en début de cours.
- Rappelez systématiquement que la consultation est **anonyme** et qu'elle sert à améliorer l'école.
- Laissez la campagne ouverte **deux à trois semaines** et relancez à mi-parcours, en suivant le taux de participation par filière.
- **Restituez les résultats aux étudiants** : publiez une synthèse et les actions décidées. C'est ce qui maintient la participation aux campagnes suivantes.
- Présentez chaque année le **Baromètre annuel de la satisfaction estudiantine** en conseil de direction, avec le suivi des actions engagées sur les cinq priorités.
