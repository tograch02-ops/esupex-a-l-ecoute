-- =====================================================================
-- ESUPEX À L'ÉCOUTE – Observatoire de la satisfaction estudiantine
-- Schéma de base de données Supabase / PostgreSQL
--
-- À exécuter UNE FOIS dans Supabase : SQL Editor > New query > coller > Run.
-- Le script est idempotent pour les tables (IF NOT EXISTS) et remplace
-- les fonctions et politiques existantes.
--
-- PRINCIPES D'ANONYMAT APPLIQUÉS PAR CONSTRUCTION
--   * La table des réponses ne contient AUCUNE colonne d'identité :
--     ni nom, ni e-mail, ni téléphone, ni adresse IP, ni identifiant de
--     compte, ni empreinte de navigateur.
--   * La date de soumission est enregistrée au JOUR près (pas d'heure),
--     pour empêcher de relier une réponse à un moment précis.
--   * Les étudiants ne peuvent PAS lire la table des réponses : ils ne
--     peuvent qu'appeler la fonction submit_response(), qui ne renvoie
--     aucun identifiant.
--   * Seuls les comptes listés dans la table « admins » peuvent lire les
--     réponses (politiques RLS).
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1. Référentiels modifiables par l'administration (sans toucher au code)
-- ---------------------------------------------------------------------
create table if not exists public.filieres (
  id          bigint generated always as identity primary key,
  libelle     text not null unique check (char_length(libelle) between 2 and 150),
  ordre       int  not null default 0,
  actif       boolean not null default true,
  created_at  timestamptz not null default now()
);

create table if not exists public.niveaux (
  id          bigint generated always as identity primary key,
  libelle     text not null unique check (char_length(libelle) between 2 and 60),
  ordre       int  not null default 0,
  actif       boolean not null default true,
  created_at  timestamptz not null default now()
);

create table if not exists public.annees_academiques (
  id          bigint generated always as identity primary key,
  libelle     text not null unique check (char_length(libelle) between 4 and 30),
  ordre       int  not null default 0,
  actif       boolean not null default true,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 2. Paramètres généraux (ligne unique)
-- ---------------------------------------------------------------------
create table if not exists public.parametres (
  id                       int primary key default 1 check (id = 1),
  seuil_confidentialite    int not null default 5 check (seuil_confidentialite between 1 and 50),
  nom_etablissement        text not null default 'ESUPEX',
  updated_at               timestamptz not null default now()
);
insert into public.parametres (id) values (1) on conflict (id) do nothing;

-- ---------------------------------------------------------------------
-- 3. Campagnes de recensement (chacune porte sa version du questionnaire)
-- ---------------------------------------------------------------------
create table if not exists public.campagnes (
  id              uuid primary key default gen_random_uuid(),
  titre           text not null check (char_length(titre) between 3 and 200),
  description     text,
  annee_academique text,
  statut          text not null default 'brouillon'
                  check (statut in ('brouillon', 'ouverte', 'cloturee')),
  questionnaire   jsonb not null,
  date_ouverture  timestamptz,
  date_cloture    timestamptz,
  created_at      timestamptz not null default now()
);

-- Une seule campagne ouverte à la fois : le lien public reste unique et simple.
create unique index if not exists campagnes_une_seule_ouverte
  on public.campagnes ((statut)) where statut = 'ouverte';

-- ---------------------------------------------------------------------
-- 4. Réponses anonymes
-- ---------------------------------------------------------------------
create table if not exists public.reponses (
  id                uuid primary key default gen_random_uuid(),
  campagne_id       uuid not null references public.campagnes(id) on delete cascade,
  -- Profil académique conservé en texte (instantané) : l'historique reste
  -- lisible même si un libellé de filière est modifié plus tard.
  filiere           text not null,
  niveau            text not null,
  annee_academique  text not null,
  reponses          jsonb not null,
  date_soumission   date not null default current_date
);
create index if not exists reponses_campagne_idx on public.reponses (campagne_id);

-- ---------------------------------------------------------------------
-- 5. Effectifs de référence (pour le taux de participation)
-- ---------------------------------------------------------------------
create table if not exists public.effectifs (
  id                bigint generated always as identity primary key,
  annee_academique  text not null,
  filiere           text not null,
  niveau            text not null,
  effectif          int  not null check (effectif >= 0),
  unique (annee_academique, filiere, niveau)
);

-- ---------------------------------------------------------------------
-- 6. Administrateurs autorisés
--    (gérés uniquement depuis le SQL Editor de Supabase, voir le guide)
-- ---------------------------------------------------------------------
create table if not exists public.admins (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  email       text,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 7. Fonctions
-- ---------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

-- Soumission d'un questionnaire. Seule porte d'entrée pour les étudiants.
-- Ne renvoie rien : aucun identifiant de réponse n'est communiqué au client.
create or replace function public.submit_response(
  p_campagne_id uuid,
  p_filiere text,
  p_niveau text,
  p_annee_academique text,
  p_reponses jsonb
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from public.campagnes
                 where id = p_campagne_id and statut = 'ouverte') then
    raise exception 'CAMPAGNE_FERMEE' using errcode = 'P0001';
  end if;
  if not exists (select 1 from public.filieres where libelle = p_filiere and actif) then
    raise exception 'FILIERE_INVALIDE' using errcode = 'P0001';
  end if;
  if not exists (select 1 from public.niveaux where libelle = p_niveau and actif) then
    raise exception 'NIVEAU_INVALIDE' using errcode = 'P0001';
  end if;
  if not exists (select 1 from public.annees_academiques
                 where libelle = p_annee_academique and actif) then
    raise exception 'ANNEE_INVALIDE' using errcode = 'P0001';
  end if;
  if p_reponses is null or jsonb_typeof(p_reponses) <> 'object' then
    raise exception 'REPONSES_INVALIDES' using errcode = 'P0001';
  end if;
  if octet_length(p_reponses::text) > 60000 then
    raise exception 'REPONSES_TROP_LONGUES' using errcode = 'P0001';
  end if;

  insert into public.reponses (campagne_id, filiere, niveau, annee_academique, reponses)
  values (p_campagne_id, p_filiere, p_niveau, p_annee_academique, p_reponses);
end;
$$;

revoke all on function public.submit_response(uuid, text, text, text, jsonb) from public;
grant execute on function public.submit_response(uuid, text, text, text, jsonb) to anon, authenticated;
grant execute on function public.is_admin() to anon, authenticated;

-- ---------------------------------------------------------------------
-- 8. Sécurité au niveau des lignes (RLS)
-- ---------------------------------------------------------------------
alter table public.filieres            enable row level security;
alter table public.niveaux             enable row level security;
alter table public.annees_academiques  enable row level security;
alter table public.parametres          enable row level security;
alter table public.campagnes           enable row level security;
alter table public.reponses            enable row level security;
alter table public.effectifs           enable row level security;
alter table public.admins              enable row level security;

-- Référentiels : lecture publique des éléments actifs, écriture admin.
do $$
declare t text;
begin
  foreach t in array array['filieres', 'niveaux', 'annees_academiques'] loop
    execute format('drop policy if exists "%1$s_lecture" on public.%1$I', t);
    execute format('drop policy if exists "%1$s_admin" on public.%1$I', t);
    execute format(
      'create policy "%1$s_lecture" on public.%1$I for select to anon, authenticated
         using (actif or public.is_admin())', t);
    execute format(
      'create policy "%1$s_admin" on public.%1$I for all to authenticated
         using (public.is_admin()) with check (public.is_admin())', t);
  end loop;
end $$;

-- Campagnes : le public ne voit que la campagne ouverte.
drop policy if exists "campagnes_lecture" on public.campagnes;
drop policy if exists "campagnes_admin" on public.campagnes;
create policy "campagnes_lecture" on public.campagnes for select to anon, authenticated
  using (statut = 'ouverte' or public.is_admin());
create policy "campagnes_admin" on public.campagnes for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Réponses : AUCUN accès public. Lecture et suppression réservées aux admins.
-- (Pas de politique INSERT : l'insertion passe exclusivement par submit_response.)
-- (Pas de politique UPDATE : une réponse ne peut pas être modifiée.)
drop policy if exists "reponses_admin_lecture" on public.reponses;
drop policy if exists "reponses_admin_suppression" on public.reponses;
create policy "reponses_admin_lecture" on public.reponses for select to authenticated
  using (public.is_admin());
create policy "reponses_admin_suppression" on public.reponses for delete to authenticated
  using (public.is_admin());

-- Effectifs et paramètres : administrateurs uniquement.
drop policy if exists "effectifs_admin" on public.effectifs;
create policy "effectifs_admin" on public.effectifs for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "parametres_admin" on public.parametres;
create policy "parametres_admin" on public.parametres for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Admins : chacun peut vérifier son propre statut ; aucune écriture via l'API.
drop policy if exists "admins_lecture" on public.admins;
create policy "admins_lecture" on public.admins for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- Ceinture et bretelles : retirer les droits d'écriture directs du rôle anon.
revoke insert, update, delete on public.reponses from anon;
revoke update on public.reponses from authenticated;
revoke all on public.admins from anon;

-- ---------------------------------------------------------------------
-- 9. Données initiales (référentiels ESUPEX) – modifiables ensuite
-- ---------------------------------------------------------------------
insert into public.filieres (libelle, ordre) values
  ('Génie civil', 1),
  ('Électrotechnique', 2),
  ('Maintenance industrielle', 3),
  ('Électronique et informatique industrielle', 4),
  ('Réseaux informatiques et télécommunications', 5),
  ('Systèmes d''information et réseaux', 6)
on conflict (libelle) do nothing;

insert into public.niveaux (libelle, ordre) values
  ('Licence 1', 1),
  ('Licence 2', 2),
  ('Licence 3', 3)
on conflict (libelle) do nothing;

insert into public.annees_academiques (libelle, ordre) values
  ('2025-2026', 1),
  ('2026-2027', 2)
on conflict (libelle) do nothing;
