-- Donner l'accès au tableau de bord à un compte existant.
-- 1) Créer d'abord le compte : Supabase > Authentication > Users > Add user (cocher « Auto Confirm User »).
-- 2) Remplacer l'adresse ci-dessous, puis exécuter dans SQL Editor.
insert into public.admins (user_id, email)
select id, email from auth.users where email = 'direction@esupex.bf'
on conflict (user_id) do nothing;

-- Retirer un administrateur :
-- delete from public.admins where email = 'ancien.responsable@esupex.bf';

-- Lister les administrateurs :
-- select email, created_at from public.admins order by created_at;
