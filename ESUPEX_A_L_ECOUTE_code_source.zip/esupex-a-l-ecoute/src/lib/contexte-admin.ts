import 'server-only';
import type { SupabaseClient } from '@supabase/supabase-js';
import { getAllResponses, getCampaigns, getEffectifs, getReferentiels, getSeuil } from './data';
import { questionnaireSchema } from './questionnaire';

export type SP = { campagne?: string; filiere?: string; niveau?: string; annee?: string };

/** Charge tout ce dont les pages d'analyse ont besoin, selon les filtres de l'URL. */
export async function chargerContexte(sb: SupabaseClient, sp: SP) {
  const [campagnes, ref, seuil, effectifs] = await Promise.all([
    getCampaigns(sb),
    getReferentiels(sb, false),
    getSeuil(sb),
    getEffectifs(sb),
  ]);
  const campagne =
    campagnes.find((c) => c.id === sp.campagne) ??
    campagnes.find((c) => c.statut === 'ouverte') ??
    campagnes.find((c) => c.statut === 'cloturee') ??
    campagnes[0] ??
    null;
  if (!campagne) return { campagnes, campagne: null } as const;

  const parsed = questionnaireSchema.safeParse(campagne.questionnaire);
  if (!parsed.success) throw new Error(`Questionnaire de la campagne « ${campagne.titre} » invalide.`);
  const filtres = { filiere: sp.filiere || undefined, niveau: sp.niveau || undefined, annee: sp.annee || undefined };
  const lignes = await getAllResponses(sb, { campagneId: campagne.id, ...filtres });

  return {
    campagnes,
    campagne: { ...campagne, questionnaire: parsed.data },
    questionnaire: parsed.data,
    lignes,
    filtres,
    seuil,
    effectifs,
    ordre: {
      filieres: ref.filieres.map((f) => f.libelle),
      niveaux: ref.niveaux.map((f) => f.libelle),
      annees: ref.annees.map((f) => f.libelle),
    },
  } as const;
}
