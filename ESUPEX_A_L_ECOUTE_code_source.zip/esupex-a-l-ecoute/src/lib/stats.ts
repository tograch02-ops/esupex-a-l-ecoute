/**
 * Calculs statistiques du tableau de bord.
 * Fonctions pures (sans accès réseau) : testées dans tests/stats.test.ts.
 *
 * Conventions :
 *  - Échelle de satisfaction 1 à 5. « Non concerné » (NA) est exclu des
 *    moyennes et des pourcentages.
 *  - « Satisfaits » = notes 4 et 5 ; « insatisfaits » = notes 1 et 2.
 *  - Score d'une dimension = moyenne, sur les répondants, de la moyenne
 *    individuelle des items de la dimension (chaque étudiant pèse autant).
 *  - Tout groupe dont l'effectif est inférieur au seuil de confidentialité
 *    est masqué (valeur null + masque = true).
 */
import { allQuestions, type Answers, type Dimension, type Questionnaire } from './questionnaire';

export type LigneReponse = { filiere: string; niveau: string; annee_academique: string; reponses: Answers };

export type StatItem = {
  id: string;
  label: string;
  dimension: Dimension;
  n: number;
  nNA: number;
  moyenne: number | null;
  distribution: [number, number, number, number, number];
  pctSatisfaits: number | null;
  pctInsatisfaits: number | null;
};

export type ScoresGroupe = {
  groupe: string;
  n: number;
  masque: boolean;
  satisfactionGlobale: number | null;
  pctSatisfaits: number | null;
  generale: number | null;
  pedagogie: number | null;
  administration: number | null;
  infrastructures: number | null;
  noteGlobale: number | null;
};

export type Comptage = { libelle: string; n: number; pct: number };

export type Statistiques = {
  total: number;
  masque: boolean;
  seuil: number;
  repartition: { filiere: Comptage[]; niveau: Comptage[]; annee: Comptage[] };
  participation: { effectifReference: number | null; taux: number | null; parFiliere: { filiere: string; n: number; effectif: number | null; taux: number | null }[] };
  indicateurs: {
    satisfactionGlobale: number | null;
    pctSatisfaits: number | null;
    pctInsatisfaits: number | null;
    pctMoyennementSatisfaits: number | null;
    generale: number | null;
    pedagogie: number | null;
    administration: number | null;
    infrastructures: number | null;
    noteGlobale: number | null;
    distributionNote: number[];
  };
  items: StatItem[];
  comparaisons: { filiere: ScoresGroupe[]; niveau: ScoresGroupe[]; annee: ScoresGroupe[] };
  priorites: { mieuxEvalues: StatItem[]; moinsBienEvalues: StatItem[] };
  difficultes: { categories: Comptage[]; principale: Comptage[]; duree: Comptage[]; perturbation: Comptage[]; autresPrecisions: string[] };
};

const DIMS_SCORE = ['generale', 'pedagogie', 'administration', 'infrastructures'] as const;

export const arrondi = (x: number | null, d = 2) => (x === null || Number.isNaN(x) ? null : Math.round(x * 10 ** d) / 10 ** d);
const moyenne = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);
const pct = (num: number, den: number) => (den > 0 ? arrondi((100 * num) / den, 1) : null);
const estNote = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

function itemsParDimension(q: Questionnaire) {
  const map: Record<string, string[]> = {};
  for (const s of q.sections) for (const qu of s.questions) if (qu.type === 'likert') (map[s.dimension] ??= []).push(qu.id);
  return map;
}

/** Moyenne individuelle d'un étudiant sur les items d'une dimension (NA exclus). */
export function scoreIndividuel(a: Answers, ids: string[] | undefined): number | null {
  if (!ids?.length) return null;
  return moyenne(ids.map((id) => a[id]).filter(estNote));
}

function scoresGroupe(groupe: string, lignes: LigneReponse[], q: Questionnaire, seuil: number): ScoresGroupe {
  const n = lignes.length;
  const masque = n < seuil;
  const dims = itemsParDimension(q);
  const sat = lignes.map((l) => l.reponses[q.roles.satisfactionGlobale]).filter(estNote);
  const dim = (d: string) => arrondi(moyenne(lignes.map((l) => scoreIndividuel(l.reponses, dims[d])).filter(estNote)));
  const note = lignes.map((l) => l.reponses[q.roles.noteGlobale]).filter(estNote);
  if (masque)
    return { groupe, n, masque, satisfactionGlobale: null, pctSatisfaits: null, generale: null, pedagogie: null, administration: null, infrastructures: null, noteGlobale: null };
  return {
    groupe,
    n,
    masque,
    satisfactionGlobale: arrondi(moyenne(sat)),
    pctSatisfaits: pct(sat.filter((x) => x >= 4).length, sat.length),
    generale: dim('generale'),
    pedagogie: dim('pedagogie'),
    administration: dim('administration'),
    infrastructures: dim('infrastructures'),
    noteGlobale: arrondi(moyenne(note)),
  };
}

function compter(valeurs: string[], ordre?: string[], denominateur?: number): Comptage[] {
  const m = new Map<string, number>();
  for (const v of valeurs) m.set(v, (m.get(v) ?? 0) + 1);
  const den = denominateur ?? valeurs.length;
  const cles = ordre ? [...ordre.filter((o) => m.has(o)), ...[...m.keys()].filter((k) => !ordre.includes(k))] : [...m.keys()];
  const res = cles.map((libelle) => ({ libelle, n: m.get(libelle) ?? 0, pct: pct(m.get(libelle) ?? 0, den) ?? 0 }));
  return ordre ? res : res.sort((a, b) => b.n - a.n);
}

function grouper(lignes: LigneReponse[], cle: (l: LigneReponse) => string, ordre: string[]) {
  const m = new Map<string, LigneReponse[]>();
  for (const l of lignes) {
    const k = cle(l);
    if (!m.has(k)) m.set(k, []);
    m.get(k)!.push(l);
  }
  const cles = [...ordre.filter((o) => m.has(o)), ...[...m.keys()].filter((k) => !ordre.includes(k)).sort()];
  return cles.map((k) => [k, m.get(k)!] as const);
}

export function calculerStatistiques(
  lignes: LigneReponse[],
  q: Questionnaire,
  opts: {
    seuil: number;
    ordreFilieres?: string[];
    ordreNiveaux?: string[];
    ordreAnnees?: string[];
    effectifs?: { annee_academique: string; filiere: string; niveau: string; effectif: number }[];
    filtres?: { filiere?: string; niveau?: string; annee?: string };
  },
): Statistiques {
  const seuil = Math.max(1, opts.seuil);
  const total = lignes.length;
  const masque = total < seuil;
  const oF = opts.ordreFilieres ?? [];
  const oN = opts.ordreNiveaux ?? [];
  const oA = opts.ordreAnnees ?? [];

  // --- Répartition (effectifs de participants : toujours affichés, ce ne sont pas des opinions)
  const repartition = {
    filiere: compter(lignes.map((l) => l.filiere), oF),
    niveau: compter(lignes.map((l) => l.niveau), oN),
    annee: compter(lignes.map((l) => l.annee_academique), oA),
  };

  // --- Participation par rapport aux effectifs de référence
  const f = opts.filtres ?? {};
  const anneesConcernees = f.annee ? [f.annee] : [...new Set(lignes.map((l) => l.annee_academique))];
  const effs = (opts.effectifs ?? []).filter(
    (e) => anneesConcernees.includes(e.annee_academique) && (!f.filiere || e.filiere === f.filiere) && (!f.niveau || e.niveau === f.niveau),
  );
  const effectifReference = effs.length ? effs.reduce((s, e) => s + e.effectif, 0) : null;
  const parFiliere = grouper(lignes, (l) => l.filiere, oF).map(([filiere, ls]) => {
    const e = effs.filter((x) => x.filiere === filiere);
    const eff = e.length ? e.reduce((s, x) => s + x.effectif, 0) : null;
    return { filiere, n: ls.length, effectif: eff, taux: eff ? pct(ls.length, eff) : null };
  });

  // --- Items
  const dimOf: Record<string, Dimension> = {};
  for (const s of q.sections) for (const qu of s.questions) dimOf[qu.id] = s.dimension;
  const items: StatItem[] = allQuestions(q)
    .filter((qu) => qu.type === 'likert')
    .map((qu) => {
      const vals = lignes.map((l) => l.reponses[qu.id]);
      const notes = vals.filter(estNote).filter((x) => x >= 1 && x <= 5);
      const dist: [number, number, number, number, number] = [0, 0, 0, 0, 0];
      notes.forEach((x) => dist[x - 1]++);
      return {
        id: qu.id,
        label: qu.label,
        dimension: dimOf[qu.id],
        n: notes.length,
        nNA: vals.filter((v) => v === 'NA').length,
        moyenne: masque ? null : arrondi(moyenne(notes)),
        distribution: masque ? [0, 0, 0, 0, 0] : dist,
        pctSatisfaits: masque ? null : pct(dist[3] + dist[4], notes.length),
        pctInsatisfaits: masque ? null : pct(dist[0] + dist[1], notes.length),
      };
    });

  // --- Indicateurs globaux
  const global = scoresGroupe('Ensemble', lignes, q, seuil);
  const sat = lignes.map((l) => l.reponses[q.roles.satisfactionGlobale]).filter(estNote);
  const notes10 = lignes.map((l) => l.reponses[q.roles.noteGlobale]).filter(estNote);
  const distributionNote = Array.from({ length: 11 }, (_, i) => (masque ? 0 : notes10.filter((x) => x === i).length));
  const indicateurs = {
    satisfactionGlobale: global.satisfactionGlobale,
    pctSatisfaits: masque ? null : pct(sat.filter((x) => x >= 4).length, sat.length),
    pctInsatisfaits: masque ? null : pct(sat.filter((x) => x <= 2).length, sat.length),
    pctMoyennementSatisfaits: masque ? null : pct(sat.filter((x) => x === 3).length, sat.length),
    generale: global.generale,
    pedagogie: global.pedagogie,
    administration: global.administration,
    infrastructures: global.infrastructures,
    noteGlobale: global.noteGlobale,
    distributionNote,
  };

  // --- Comparaisons
  const comparaisons = {
    filiere: grouper(lignes, (l) => l.filiere, oF).map(([g, ls]) => scoresGroupe(g, ls, q, seuil)),
    niveau: grouper(lignes, (l) => l.niveau, oN).map(([g, ls]) => scoresGroupe(g, ls, q, seuil)),
    annee: grouper(lignes, (l) => l.annee_academique, oA).map(([g, ls]) => scoresGroupe(g, ls, q, seuil)),
  };

  // --- Priorités : uniquement les items évalués par au moins « seuil » répondants
  const classables = items.filter((i) => i.moyenne !== null && i.n >= seuil);
  const tri = [...classables].sort((a, b) => (b.moyenne! - a.moyenne!) || ((b.pctSatisfaits ?? 0) - (a.pctSatisfaits ?? 0)));
  const priorites = {
    mieuxEvalues: tri.slice(0, 5),
    moinsBienEvalues: [...tri].reverse().slice(0, 5),
  };

  // --- Difficultés
  const qDiff = allQuestions(q).find((x) => x.id === q.roles.difficultes);
  const optionsDiff = qDiff && qDiff.type === 'multi' ? qDiff.options : undefined;
  const valsDiff = masque ? [] : lignes.flatMap((l) => (Array.isArray(l.reponses[q.roles.difficultes]) ? (l.reponses[q.roles.difficultes] as string[]) : []));
  const nRepDiff = lignes.filter((l) => Array.isArray(l.reponses[q.roles.difficultes])).length;
  const categories = compter(valsDiff, undefined, nRepDiff);
  const singleCount = (id: string | undefined) => {
    if (!id || masque) return [];
    const qq = allQuestions(q).find((x) => x.id === id);
    const vals = lignes.map((l) => l.reponses[id]).filter((v): v is string => typeof v === 'string');
    return compter(vals, qq && qq.type === 'single' ? qq.options : undefined);
  };
  const difficultes = {
    categories: optionsDiff ? categories.sort((a, b) => b.n - a.n) : categories,
    principale: singleCount(q.roles.difficultePrincipale).sort((a, b) => b.n - a.n),
    duree: singleCount('d_duree'),
    perturbation: singleCount('d_perturbation'),
    autresPrecisions: masque
      ? []
      : lignes.map((l) => l.reponses[`${q.roles.difficultes}_autre`]).filter((v): v is string => typeof v === 'string' && v.trim().length > 0),
  };

  return {
    total,
    masque,
    seuil,
    repartition,
    participation: { effectifReference, taux: effectifReference ? pct(total, effectifReference) : null, parFiliere },
    indicateurs,
    items,
    comparaisons,
    priorites,
    difficultes,
  };
}

/** Indicateurs synthétiques d'une campagne, pour le suivi de l'évolution entre campagnes. */
export function syntheseCampagne(lignes: LigneReponse[], q: Questionnaire, seuil: number) {
  return scoresGroupe('', lignes, q, seuil);
}

export { DIMS_SCORE };
