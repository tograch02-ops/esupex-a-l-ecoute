/**
 * Définition du questionnaire ESUPEX À L'ÉCOUTE.
 *
 * Le questionnaire est stocké en JSON dans chaque campagne (colonne
 * campagnes.questionnaire). Le modèle ci-dessous sert de version par défaut
 * lors de la création d'une campagne ; l'administration peut ensuite le
 * modifier depuis l'espace admin, sans toucher au code source.
 *
 * La section 1 (profil académique : filière, niveau, année) n'est pas
 * décrite ici : elle est générée à partir des référentiels de la base.
 */
import { z } from 'zod';

export type Dimension =
  | 'generale'
  | 'pedagogie'
  | 'administration'
  | 'infrastructures'
  | 'difficultes'
  | 'suggestions';

export const DIMENSION_LIBELLES: Record<Dimension, string> = {
  generale: 'Satisfaction générale',
  pedagogie: 'Enseignement et encadrement pédagogique',
  administration: 'Administration et services',
  infrastructures: 'Infrastructures et conditions d’études',
  difficultes: 'Difficultés et préoccupations',
  suggestions: 'Suggestions et recommandations',
};

const conditionSchema = z.object({
  question: z.string(),
  /** Visible si la question référencée a au moins une réponse différente de cette valeur. */
  anyExcept: z.string().optional(),
});

const base = {
  id: z.string().regex(/^[a-z0-9_]+$/, 'identifiant : minuscules, chiffres et _ uniquement'),
  label: z.string().min(3),
  help: z.string().optional(),
  required: z.boolean().optional(),
  showIf: conditionSchema.optional(),
};

export const questionSchema = z.discriminatedUnion('type', [
  z.object({ ...base, type: z.literal('likert'), allowNA: z.boolean().optional() }),
  z.object({ ...base, type: z.literal('scale10') }),
  z.object({
    ...base,
    type: z.literal('text'),
    maxLength: z.number().int().min(50).max(3000).optional(),
    placeholder: z.string().optional(),
  }),
  z.object({
    ...base,
    type: z.literal('multi'),
    options: z.array(z.string().min(1)).min(2),
    /** Option exclusive (ex. « Aucune difficulté ») qui désélectionne les autres. */
    exclusive: z.string().optional(),
    /** Option qui ouvre un champ « préciser » (ex. « Autres »). */
    otherOption: z.string().optional(),
  }),
  z.object({ ...base, type: z.literal('single'), options: z.array(z.string().min(1)).min(2) }),
]);

export const sectionSchema = z.object({
  id: z.string().regex(/^[a-z0-9_]+$/),
  title: z.string().min(3),
  intro: z.string().optional(),
  dimension: z.enum(['generale', 'pedagogie', 'administration', 'infrastructures', 'difficultes', 'suggestions']),
  questions: z.array(questionSchema).min(1),
});

export const questionnaireSchema = z
  .object({
    version: z.literal(1),
    likertLabels: z.array(z.string()).length(5),
    naLabel: z.string(),
    roles: z.object({
      satisfactionGlobale: z.string(),
      noteGlobale: z.string(),
      difficultes: z.string(),
      difficultePrincipale: z.string().optional(),
      ameliorations: z.string().optional(),
    }),
    sections: z.array(sectionSchema).min(1),
  })
  .superRefine((q, ctx) => {
    const ids = new Set<string>();
    for (const s of q.sections)
      for (const qu of s.questions) {
        if (ids.has(qu.id)) ctx.addIssue({ code: 'custom', message: `Identifiant de question en double : ${qu.id}` });
        ids.add(qu.id);
      }
    for (const [role, id] of Object.entries(q.roles))
      if (id && !ids.has(id)) ctx.addIssue({ code: 'custom', message: `Rôle « ${role} » : question introuvable (${id})` });
    for (const s of q.sections)
      for (const qu of s.questions)
        if (qu.showIf && !ids.has(qu.showIf.question))
          ctx.addIssue({ code: 'custom', message: `Condition de ${qu.id} : question introuvable (${qu.showIf.question})` });
  });

export type Question = z.infer<typeof questionSchema>;
export type Section = z.infer<typeof sectionSchema>;
export type Questionnaire = z.infer<typeof questionnaireSchema>;
export type AnswerValue = number | 'NA' | string | string[] | null;
export type Answers = Record<string, AnswerValue>;

export function allQuestions(q: Questionnaire): Question[] {
  return q.sections.flatMap((s) => s.questions);
}

export function isVisible(question: Question, answers: Answers): boolean {
  if (!question.showIf) return true;
  const v = answers[question.showIf.question];
  if (Array.isArray(v)) {
    const rest = question.showIf.anyExcept ? v.filter((x) => x !== question.showIf!.anyExcept) : v;
    return rest.length > 0;
  }
  if (v === null || v === undefined || v === '') return false;
  return question.showIf.anyExcept ? v !== question.showIf.anyExcept : true;
}

/** Retourne la liste des erreurs (id de question → message) pour une section. */
export function validateSection(section: Section, answers: Answers): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const q of section.questions) {
    if (!isVisible(q, answers)) continue;
    const v = answers[q.id];
    const empty = v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0);
    if (q.required && empty) {
      errors[q.id] = 'Merci de répondre à cette question.';
      continue;
    }
    if (empty) continue;
    if (q.type === 'multi' && q.otherOption && Array.isArray(v) && v.includes(q.otherOption)) {
      const precision = answers[`${q.id}_autre`];
      if (typeof precision !== 'string' || precision.trim().length < 2)
        errors[q.id] = `Merci de préciser « ${q.otherOption} ».`;
    }
  }
  return errors;
}

/**
 * Nettoie et valide strictement les réponses reçues côté serveur :
 * seules les questions connues et visibles sont conservées, avec des
 * valeurs conformes à leur type. Toute valeur inattendue est rejetée.
 */
export function sanitizeAnswers(
  q: Questionnaire,
  raw: unknown,
): { ok: true; answers: Answers } | { ok: false; error: string } {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { ok: false, error: 'Format de réponses invalide.' };
  const input = raw as Record<string, unknown>;
  const out: Answers = {};
  for (const question of allQuestions(q)) {
    const v = input[question.id];
    if (v === undefined || v === null || v === '') continue;
    switch (question.type) {
      case 'likert':
        if (v === 'NA' && question.allowNA) out[question.id] = 'NA';
        else if (typeof v === 'number' && Number.isInteger(v) && v >= 1 && v <= 5) out[question.id] = v;
        else return { ok: false, error: `Valeur invalide pour ${question.id}.` };
        break;
      case 'scale10':
        if (typeof v === 'number' && Number.isInteger(v) && v >= 0 && v <= 10) out[question.id] = v;
        else return { ok: false, error: `Valeur invalide pour ${question.id}.` };
        break;
      case 'text': {
        if (typeof v !== 'string') return { ok: false, error: `Valeur invalide pour ${question.id}.` };
        const t = v.trim().slice(0, question.maxLength ?? 1500);
        if (t) out[question.id] = t;
        break;
      }
      case 'single':
        if (typeof v === 'string' && question.options.includes(v)) out[question.id] = v;
        else return { ok: false, error: `Valeur invalide pour ${question.id}.` };
        break;
      case 'multi': {
        if (!Array.isArray(v) || !v.every((x) => typeof x === 'string' && question.options.includes(x)))
          return { ok: false, error: `Valeur invalide pour ${question.id}.` };
        let arr = Array.from(new Set(v as string[]));
        if (question.exclusive && arr.includes(question.exclusive)) arr = [question.exclusive];
        if (arr.length) out[question.id] = arr;
        if (question.otherOption && arr.includes(question.otherOption)) {
          const p = input[`${question.id}_autre`];
          if (typeof p === 'string' && p.trim()) out[`${question.id}_autre`] = p.trim().slice(0, 300);
        }
        break;
      }
    }
  }
  // Retirer les réponses aux questions masquées par une condition.
  for (const question of allQuestions(q)) if (!isVisible(question, out)) delete out[question.id];
  for (const section of q.sections) {
    const errors = validateSection(section, out);
    const first = Object.keys(errors)[0];
    if (first) return { ok: false, error: `Réponse manquante ou incomplète : « ${allQuestions(q).find((x) => x.id === first)?.label} »` };
  }
  return { ok: true, answers: out };
}

// ---------------------------------------------------------------------------
// Questionnaire par défaut (cahier des charges ESUPEX)
// ---------------------------------------------------------------------------
const L = (id: string, label: string, allowNA = false): Question => ({ id, type: 'likert', label, required: true, ...(allowNA ? { allowNA } : {}) });

const DIFFICULTES = [
  'Difficultés pédagogiques',
  'Difficultés administratives',
  'Difficultés financières',
  'Difficultés liées aux infrastructures',
  'Difficultés liées à l’organisation des cours',
  'Difficultés de communication',
  'Difficultés liées aux équipements et aux travaux pratiques',
  'Difficultés liées aux stages et à l’insertion professionnelle',
  'Autres',
];
export const AUCUNE_DIFFICULTE = 'Aucune difficulté particulière';

export const DEFAULT_QUESTIONNAIRE: Questionnaire = {
  version: 1,
  likertLabels: ['Très insatisfait', 'Insatisfait', 'Moyennement satisfait', 'Satisfait', 'Très satisfait'],
  naLabel: 'Non concerné / Non disponible',
  roles: {
    satisfactionGlobale: 'g_satisfaction_esupex',
    noteGlobale: 's_note_globale',
    difficultes: 'd_categories',
    difficultePrincipale: 'd_principale',
    ameliorations: 's_trois_priorites',
  },
  sections: [
    {
      id: 'satisfaction_generale',
      title: 'Satisfaction générale',
      intro: 'Donne ton appréciation globale sur l’ESUPEX.',
      dimension: 'generale',
      questions: [
        L('g_satisfaction_esupex', 'Satisfaction générale concernant l’ESUPEX'),
        L('g_qualite_formation', 'Qualité globale de la formation reçue'),
        L('g_adequation_attentes', 'Adéquation de la formation avec tes attentes initiales'),
        L('g_encadrement', 'Qualité de l’encadrement pédagogique'),
        L('g_prestations_attentes', 'Rapport entre les prestations de l’école et les attentes des étudiants'),
        L('g_recommandation', 'Recommanderais-tu l’ESUPEX à un nouvel étudiant ?'),
      ],
    },
    {
      id: 'pedagogie',
      title: 'Qualité de l’enseignement et encadrement pédagogique',
      dimension: 'pedagogie',
      questions: [
        L('p_maitrise', 'Maîtrise des matières par les enseignants'),
        L('p_disponibilite', 'Disponibilité des enseignants'),
        L('p_explications', 'Qualité des explications'),
        L('p_horaires', 'Respect des horaires de cours'),
        L('p_programme', 'Respect du programme pédagogique'),
        L('p_evaluations', 'Organisation des évaluations'),
        L('p_resultats', 'Communication des résultats'),
        L('p_tp', 'Encadrement des travaux pratiques', true),
        L('p_supports', 'Disponibilité des supports pédagogiques'),
        L('p_accompagnement', 'Accompagnement des étudiants en difficulté', true),
        {
          id: 'p_ameliorations',
          type: 'text',
          label: 'Quelles améliorations souhaites-tu concernant l’enseignement et l’encadrement pédagogique ?',
          maxLength: 1500,
        },
      ],
    },
    {
      id: 'administration',
      title: 'Administration et services aux étudiants',
      dimension: 'administration',
      questions: [
        L('a_accueil', 'Qualité de l’accueil à l’administration'),
        L('a_disponibilite', 'Disponibilité du personnel administratif'),
        L('a_traitement', 'Rapidité du traitement des dossiers', true),
        L('a_inscriptions', 'Organisation des inscriptions'),
        L('a_documents', 'Délivrance des documents administratifs', true),
        L('a_communication', 'Communication entre la direction et les étudiants'),
        L('a_informations', 'Diffusion des informations importantes'),
        L('a_reclamations', 'Gestion des réclamations', true),
        L('a_transparence', 'Transparence dans les procédures administratives'),
        {
          id: 'a_difficultes',
          type: 'text',
          label: 'Quelles difficultés rencontres-tu dans tes relations avec l’administration ?',
          maxLength: 1500,
        },
      ],
    },
    {
      id: 'infrastructures',
      title: 'Infrastructures et conditions d’études',
      intro: 'Choisis « Non concerné / Non disponible » si tu ne peux pas évaluer un élément.',
      dimension: 'infrastructures',
      questions: [
        L('i_salles', 'Qualité des salles de cours', true),
        L('i_capacite', 'Capacité d’accueil des salles', true),
        L('i_mobilier', 'Disponibilité des tables et chaises', true),
        L('i_eclairage', 'Éclairage et ventilation', true),
        L('i_informatique', 'Équipements informatiques', true),
        L('i_laboratoires', 'Laboratoires et matériels pratiques', true),
        L('i_sanitaires', 'Installations sanitaires', true),
        L('i_proprete', 'Propreté et entretien des locaux', true),
        L('i_espaces', 'Espaces de travail et de repos', true),
        L('i_securite', 'Sécurité au sein de l’établissement', true),
        L('i_internet', 'Accès à Internet et aux ressources numériques', true),
      ],
    },
    {
      id: 'difficultes',
      title: 'Difficultés et préoccupations',
      dimension: 'difficultes',
      questions: [
        {
          id: 'd_categories',
          type: 'multi',
          label: 'Quelles sont les principales difficultés que tu rencontres actuellement à l’ESUPEX ?',
          help: 'Plusieurs réponses possibles.',
          options: [...DIFFICULTES, AUCUNE_DIFFICULTE],
          exclusive: AUCUNE_DIFFICULTE,
          otherOption: 'Autres',
          required: true,
        },
        {
          id: 'd_principale',
          type: 'single',
          label: 'Quelle est la difficulté qui affecte le plus tes études ?',
          options: DIFFICULTES,
          required: true,
          showIf: { question: 'd_categories', anyExcept: AUCUNE_DIFFICULTE },
        },
        {
          id: 'd_duree',
          type: 'single',
          label: 'Depuis combien de temps rencontres-tu cette difficulté ?',
          options: ['Moins d’un mois', 'De 1 à 3 mois', 'De 3 à 6 mois', 'Plus de 6 mois', 'Depuis mon inscription'],
          required: true,
          showIf: { question: 'd_categories', anyExcept: AUCUNE_DIFFICULTE },
        },
        {
          id: 'd_perturbation',
          type: 'single',
          label: 'Cette difficulté a-t-elle déjà perturbé ton parcours académique ?',
          options: ['Oui, fortement', 'Oui, un peu', 'Non'],
          required: true,
          showIf: { question: 'd_categories', anyExcept: AUCUNE_DIFFICULTE },
        },
      ],
    },
    {
      id: 'suggestions',
      title: 'Suggestions et recommandations',
      intro: 'Exprime-toi librement : tes réponses sont anonymes. Évite d’écrire ton nom ou celui d’une autre personne.',
      dimension: 'suggestions',
      questions: [
        {
          id: 's_trois_priorites',
          type: 'text',
          label: 'Quelles sont les trois améliorations prioritaires que tu souhaites voir à l’ESUPEX ?',
          placeholder: '1. …\n2. …\n3. …',
          maxLength: 1500,
        },
        { id: 's_enseignement', type: 'text', label: 'Que proposes-tu pour améliorer la qualité de l’enseignement ?', maxLength: 1500 },
        { id: 's_administration', type: 'text', label: 'Que proposes-tu pour améliorer le fonctionnement administratif ?', maxLength: 1500 },
        { id: 's_infrastructures', type: 'text', label: 'Quelles infrastructures ou quels équipements devraient être renforcés ?', maxLength: 1500 },
        { id: 's_message_direction', type: 'text', label: 'Quel message souhaites-tu adresser à la direction de l’ESUPEX ?', maxLength: 1500 },
        { id: 's_note_globale', type: 'scale10', label: 'Sur une échelle de 0 à 10, quelle note globale attribues-tu à l’ESUPEX ?', required: true },
      ],
    },
  ],
};
