import { allQuestions, type Questionnaire, type AnswerValue } from './questionnaire';
import type { Reponse } from './data';

/** Transforme les réponses en tableau (une ligne par réponse, une colonne par question). */
export function tabulaire(q: Questionnaire, lignes: Reponse[]) {
  const questions = allQuestions(q);
  const colonnes: { cle: string; titre: string }[] = [
    { cle: '_n', titre: 'N°' },
    { cle: '_date', titre: 'Date de soumission' },
    { cle: '_filiere', titre: 'Filière' },
    { cle: '_niveau', titre: 'Niveau' },
    { cle: '_annee', titre: 'Année académique' },
  ];
  for (const qu of questions) {
    colonnes.push({ cle: qu.id, titre: qu.label });
    if (qu.type === 'multi' && qu.otherOption) colonnes.push({ cle: `${qu.id}_autre`, titre: `${qu.label} – précision « ${qu.otherOption} »` });
  }
  const fmt = (v: AnswerValue | undefined): string | number => {
    if (v === undefined || v === null) return '';
    if (v === 'NA') return 'NC';
    if (Array.isArray(v)) return v.join(' ; ');
    return v;
  };
  // Ordre de restitution : par date puis aléatoire (l'ordre d'arrivée n'est pas reconstitué).
  const triees = [...lignes].sort((a, b) => a.date_soumission.localeCompare(b.date_soumission) || a.id.localeCompare(b.id));
  const donnees = triees.map((l, i) => {
    const r: Record<string, string | number> = {
      _n: i + 1,
      _date: l.date_soumission,
      _filiere: l.filiere,
      _niveau: l.niveau,
      _annee: l.annee_academique,
    };
    for (const c of colonnes.slice(5)) r[c.cle] = fmt(l.reponses[c.cle]);
    return r;
  });
  return { colonnes, donnees };
}

export function versCsv(colonnes: { cle: string; titre: string }[], donnees: Record<string, string | number>[]) {
  const echap = (v: string | number) => {
    let s = String(v ?? '');
    // Neutralise l'injection de formules dans les tableurs.
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
    return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  // Séparateur « ; » et BOM UTF-8 : ouverture directe et correcte dans Excel en français.
  const lignes = [colonnes.map((c) => echap(c.titre)).join(';'), ...donnees.map((d) => colonnes.map((c) => echap(d[c.cle])).join(';'))];
  return '﻿' + lignes.join('\r\n');
}
