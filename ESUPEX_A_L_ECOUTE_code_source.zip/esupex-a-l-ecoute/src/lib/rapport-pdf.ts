'use client';
/**
 * Génération du rapport PDF « Baromètre de la satisfaction estudiantine »,
 * entièrement dans le navigateur de l'administrateur (aucune donnée envoyée
 * à un service tiers).
 */
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Statistiques } from './stats';
import { DIMENSION_LIBELLES } from './questionnaire';
import type { Evolution } from '@/components/admin/TableauDeBord';

// Les polices standard du PDF couvrent le français (é, è, à, ç…) mais pas certains signes typographiques.
const txt = (v: string | number) => (typeof v === 'number' ? String(v) : v.replace(/[\u2019\u2018]/g, "'").replace(/[\u201c\u201d\u00ab\u00bb]/g, '"').replace(/\u2026/g, '...').replace(/[\u2013\u2014]/g, '-'));
const BLEU: [number, number, number] = [18, 61, 112];
const n2 = (x: number | null | undefined, d = 2) => (x === null || x === undefined ? '-' : x.toFixed(d).replace('.', ','));
const pc = (x: number | null | undefined) => (x === null || x === undefined ? '-' : `${x.toFixed(1).replace('.', ',')} %`);

export async function genererRapportPdf(p: {
  stats: Statistiques;
  campagneTitre: string;
  filtresTexte: string;
  ameliorations: { libelle: string; n: number }[];
  evolution: Evolution[];
  likertLabels: string[];
}) {
  const { stats, campagneTitre, filtresTexte } = p;
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const date = new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

  // Page de garde / en-tête
  doc.setFillColor(...BLEU);
  doc.rect(0, 0, W, 38, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text("ESUPEX À L'ÉCOUTE", 14, 16);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.text('Baromètre de la satisfaction estudiantine', 14, 24);
  doc.setFontSize(9);
  doc.text(txt(`${campagneTitre} - ${filtresTexte} - édité le ${date}`), 14, 31);
  doc.setTextColor(30, 30, 30);

  let y = 48;
  const titre = (t: string) => {
    if (y > 260) {
      doc.addPage();
      y = 18;
    }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(...BLEU);
    doc.text(txt(t), 14, y);
    doc.setTextColor(30, 30, 30);
    doc.setFont('helvetica', 'normal');
    y += 3;
  };
  const tableau = (head: string[], body: (string | number)[][], opts: Record<string, unknown> = {}) => {
    autoTable(doc, {
      startY: y,
      head: [head.map(txt)],
      body: body.map((r) => r.map(txt)),
      theme: 'grid',
      styles: { fontSize: 8.5, cellPadding: 1.8 },
      headStyles: { fillColor: BLEU, textColor: 255 },
      margin: { left: 14, right: 14 },
      ...opts,
    });
    // @ts-expect-error propriété ajoutée par jspdf-autotable
    y = doc.lastAutoTable.finalY + 9;
  };

  const i = stats.indicateurs;
  titre('1. Indicateurs clés');
  tableau(
    ['Indicateur', 'Valeur'],
    [
      ['Nombre de participants', String(stats.total)],
      ['Taux de participation', stats.participation.taux !== null ? pc(stats.participation.taux) : 'Effectifs non renseignés'],
      ['Satisfaction générale (moyenne / 5)', n2(i.satisfactionGlobale)],
      ['Étudiants satisfaits (notes 4-5)', pc(i.pctSatisfaits)],
      ['Étudiants moyennement satisfaits (note 3)', pc(i.pctMoyennementSatisfaits)],
      ['Étudiants insatisfaits (notes 1-2)', pc(i.pctInsatisfaits)],
      [`${DIMENSION_LIBELLES.generale} (/ 5)`, n2(i.generale)],
      [`${DIMENSION_LIBELLES.pedagogie} (/ 5)`, n2(i.pedagogie)],
      [`${DIMENSION_LIBELLES.administration} (/ 5)`, n2(i.administration)],
      [`${DIMENSION_LIBELLES.infrastructures} (/ 5)`, n2(i.infrastructures)],
      ['Note globale attribuée à l’ESUPEX (/ 10)', n2(i.noteGlobale, 1)],
    ],
    { columnStyles: { 1: { halign: 'right', cellWidth: 45 } } },
  );

  titre('2. Les cinq domaines d’intervention prioritaire');
  tableau(
    ['#', 'Élément', 'Rubrique', 'Moy. / 5', '% insatisfaits'],
    stats.priorites.moinsBienEvalues.map((it, k) => [k + 1, it.label, DIMENSION_LIBELLES[it.dimension], n2(it.moyenne), pc(it.pctInsatisfaits)]),
    { columnStyles: { 0: { cellWidth: 8 }, 3: { halign: 'right' }, 4: { halign: 'right' } } },
  );

  titre('3. Points forts');
  tableau(
    ['#', 'Élément', 'Rubrique', 'Moy. / 5', '% satisfaits'],
    stats.priorites.mieuxEvalues.map((it, k) => [k + 1, it.label, DIMENSION_LIBELLES[it.dimension], n2(it.moyenne), pc(it.pctSatisfaits)]),
    { columnStyles: { 0: { cellWidth: 8 }, 3: { halign: 'right' }, 4: { halign: 'right' } } },
  );

  titre('4. Principales difficultés signalées');
  tableau(
    ['Difficulté', 'Effectif', '% des répondants'],
    stats.difficultes.categories.map((c) => [c.libelle, c.n, pc(c.pct)]),
    { columnStyles: { 1: { halign: 'right' }, 2: { halign: 'right' } } },
  );

  if (p.ameliorations.length) {
    titre('5. Améliorations les plus demandées (thèmes)');
    tableau(['Thème', 'Mentions'], p.ameliorations.map((a) => [a.libelle, a.n]), { columnStyles: { 1: { halign: 'right' } } });
  }

  titre('6. Comparaison entre filières (moyennes / 5)');
  const comp = (lignes: Statistiques['comparaisons']['filiere']) =>
    lignes.map((l) =>
      l.masque
        ? [l.groupe, l.n, 'masqué', 'masqué', 'masqué', 'masqué', 'masqué']
        : [l.groupe, l.n, n2(l.satisfactionGlobale), n2(l.pedagogie), n2(l.administration), n2(l.infrastructures), n2(l.noteGlobale, 1)],
    );
  const enteteComp = ['Groupe', 'N', 'Satisf.', 'Pédagogie', 'Admin.', 'Infra.', 'Note /10'];
  const stylesComp = { columnStyles: { 1: { halign: 'right' }, 2: { halign: 'right' }, 3: { halign: 'right' }, 4: { halign: 'right' }, 5: { halign: 'right' }, 6: { halign: 'right' } } };
  tableau(enteteComp, comp(stats.comparaisons.filiere), stylesComp);
  titre('7. Comparaison entre niveaux');
  tableau(enteteComp, comp(stats.comparaisons.niveau), stylesComp);

  titre('8. Détail des appréciations par élément');
  tableau(
    ['Élément', 'Moy.', ...p.likertLabels.map((_, k) => String(k + 1)), 'N.C.'],
    stats.items.map((it) => [it.label, n2(it.moyenne), ...it.distribution, it.nNA]),
    { styles: { fontSize: 7.5, cellPadding: 1.4 }, columnStyles: { 1: { halign: 'right' } } },
  );

  if (p.evolution.length > 1) {
    titre('9. Évolution entre campagnes');
    tableau(
      ['Campagne', 'N', 'Satisf.', 'Pédagogie', 'Admin.', 'Infra.', 'Note /10'],
      p.evolution.map((e) => [e.titre, e.n, n2(e.satisfactionGlobale), n2(e.pedagogie), n2(e.administration), n2(e.infrastructures), n2(e.noteGlobale, 1)]),
    );
  }

  // Pied de page sur chaque page
  const nb = doc.getNumberOfPages();
  for (let k = 1; k <= nb; k++) {
    doc.setPage(k);
    doc.setFontSize(7.5);
    doc.setTextColor(120, 120, 120);
    doc.text(
      `ESUPEX À L'ÉCOUTE - Données anonymes. Groupes de moins de ${stats.seuil} réponses masqués. Échelle : 1 = très insatisfait ... 5 = très satisfait.`,
      14,
      290,
    );
    doc.text(`${k} / ${nb}`, W - 14, 290, { align: 'right' });
  }

  doc.save(`ESUPEX_barometre_${campagneTitre.replace(/[^a-zA-Z0-9]+/g, '_')}.pdf`);
}
