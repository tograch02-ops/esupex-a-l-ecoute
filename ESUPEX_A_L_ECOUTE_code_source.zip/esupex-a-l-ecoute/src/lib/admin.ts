import 'server-only';
import { redirect } from 'next/navigation';
import { createSessionClient } from './supabase/server';

/** Vérifie que l'utilisateur est connecté ET inscrit dans la table admins. */
export async function requireAdmin() {
  const supabase = createSessionClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect('/admin/connexion');
  const { data } = await supabase.rpc('is_admin');
  if (data !== true) redirect('/admin/connexion?erreur=non-autorise');
  return { supabase, user };
}

/** Variante pour les routes API : renvoie null si l'accès est refusé. */
export async function getAdminOrNull() {
  const supabase = createSessionClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.rpc('is_admin');
  return data === true ? { supabase, user } : null;
}
