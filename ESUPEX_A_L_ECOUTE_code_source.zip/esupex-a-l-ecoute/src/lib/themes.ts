/**
 * Analyse automatique des réponses ouvertes par thèmes (mots-clés).
 *
 * Méthode déterministe et vérifiable : chaque commentaire est rattaché aux
 * thèmes dont il contient au moins un mot-clé ; chaque thème affiche la liste
 * des commentaires originaux qui le composent. Rien n'est inventé ni
 * reformulé. Les listes de mots-clés peuvent être complétées ci-dessous.
 */
import { allQuestions, type Answers, type Questionnaire } from './questionnaire';

export type Theme = { id: string; libelle: string; motsCles: string[] };

export const THEMES: Theme[] = [
  { id: 'internet', libelle: 'Internet, Wi-Fi et ressources numériques', motsCles: ['internet', 'wifi', 'wi-fi', 'wi fi', 'connexion', 'debit', 'en ligne', 'numerique', 'plateforme'] },
  { id: 'equipements', libelle: 'Équipements, laboratoires et travaux pratiques', motsCles: ['labo', 'laboratoire', 'materiel', 'equipement', ' tp', 'tp ', 'travaux pratiques', 'pratique', 'machine', 'outil', 'atelier', 'ordinateur', 'informatique', 'logiciel', 'appareil'] },
  { id: 'salles', libelle: 'Salles, mobilier, éclairage et ventilation', motsCles: ['salle', 'table', 'chaise', 'banc', 'mobilier', 'place', 'ventil', 'climatis', 'chaleur', 'chaud', 'eclairage', 'lumiere', 'courant', 'electricite', 'delestage', 'amphi'] },
  { id: 'sanitaires', libelle: 'Sanitaires, hygiène et propreté', motsCles: ['toilette', 'wc', 'sanitaire', 'latrine', 'propre', 'proprete', 'hygiene', 'sale', 'eau potable', 'entretien'] },
  { id: 'enseignants', libelle: 'Enseignants et qualité des cours', motsCles: ['enseignant', 'professeur', 'prof ', 'profs', 'formateur', 'cours', 'explication', 'expliquer', 'pedagog', 'methode', 'competen', 'absence', 'absent'] },
  { id: 'organisation', libelle: 'Emploi du temps et organisation des cours', motsCles: ['emploi du temps', 'horaire', 'planning', 'programme', 'retard', 'report', 'organisation', 'calendrier', 'volume horaire', 'quantum'] },
  { id: 'evaluations', libelle: 'Évaluations, notes et résultats', motsCles: ['examen', 'devoir', 'evaluation', 'note', 'resultat', 'rattrapage', 'correction', 'bulletin', 'releve'] },
  { id: 'administration', libelle: 'Administration et scolarité', motsCles: ['administration', 'administratif', 'scolarite', 'dossier', 'attestation', 'document', 'inscription', 'accueil', 'secretariat', 'guichet', 'lenteur', 'reclamation'] },
  { id: 'communication', libelle: 'Communication et information', motsCles: ['communication', 'communiquer', 'information', 'informer', 'annonce', 'affichage', 'whatsapp', 'message', 'prevenir', 'transparence'] },
  { id: 'finances', libelle: 'Frais de scolarité et difficultés financières', motsCles: ['frais', 'paiement', 'payer', 'argent', 'cher', 'cout', 'financ', 'bourse', 'tranche', 'reduction'] },
  { id: 'stages', libelle: 'Stages, insertion professionnelle et entreprises', motsCles: ['stage', 'emploi apres', 'trouver un emploi', 'insertion', 'entreprise', 'professionnel', 'partenariat', 'debouche', 'visite', 'sortie pedagogique'] },
  { id: 'documentation', libelle: 'Bibliothèque et supports pédagogiques', motsCles: ['bibliotheque', 'livre', 'ouvrage', 'documentation', 'support', 'polycopie', 'fascicule', 'manuel'] },
  { id: 'securite', libelle: 'Sécurité et cadre de vie', motsCles: ['securite', 'vol', 'gardien', 'parking', 'moto', 'cantine', 'restauration', 'repos', 'ombre', 'transport'] },
  { id: 'accompagnement', libelle: 'Écoute, accompagnement et relations', motsCles: ['ecoute', 'accompagn', 'soutien', 'tutorat', 'encadrement', 'relation', 'dialogue', 'consideration'] },
];

export const normaliser = (s: string) =>
  ' ' +
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[’'`]/g, ' ')
    .replace(/[^a-z0-9\- ]+/g, ' ')
    .replace(/\s+/g, ' ') +
  ' ';

export function themesDe(texte: string): string[] {
  const t = normaliser(texte);
  // Un mot-clé doit correspondre au DÉBUT d'un mot (« livre » ne doit pas détecter « délivrer »).
  return THEMES.filter((th) => th.motsCles.some((m) => t.includes(' ' + m.trim()))).map((th) => th.id);
}

// Volontairement, la filière et le niveau ne sont PAS rattachés à chaque commentaire
// affiché : dans un petit groupe, cela suffirait à identifier l'auteur.
export type Commentaire = { ref: string; question: string; questionId: string; texte: string };
export type ResultatThemes = {
  themes: { id: string; libelle: string; n: number; commentaires: Commentaire[] }[];
  nonClasses: Commentaire[];
  total: number;
};

export function extraireCommentaires(
  lignes: { reponses: Answers }[],
  q: Questionnaire,
  questionId?: string,
): Commentaire[] {
  const textes = allQuestions(q).filter((x) => x.type === 'text' && (!questionId || x.id === questionId));
  const out: Commentaire[] = [];
  lignes.forEach((l, i) => {
    for (const qu of textes) {
      const v = l.reponses[qu.id];
      if (typeof v === 'string' && v.trim().length >= 3)
        out.push({ ref: `R${i + 1}-${qu.id}`, question: qu.label, questionId: qu.id, texte: v.trim() });
    }
  });
  return out;
}

export function analyserThemes(commentaires: Commentaire[]): ResultatThemes {
  const parTheme = new Map<string, Commentaire[]>();
  const nonClasses: Commentaire[] = [];
  for (const c of commentaires) {
    const ths = themesDe(c.texte);
    if (!ths.length) nonClasses.push(c);
    for (const t of ths) {
      if (!parTheme.has(t)) parTheme.set(t, []);
      parTheme.get(t)!.push(c);
    }
  }
  const themes = THEMES.filter((t) => parTheme.has(t.id))
    .map((t) => ({ id: t.id, libelle: t.libelle, n: parTheme.get(t.id)!.length, commentaires: parTheme.get(t.id)! }))
    .sort((a, b) => b.n - a.n);
  return { themes, nonClasses, total: commentaires.length };
}
