import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { createClient as createPlainClient } from '@supabase/supabase-js';
import { cookies } from 'next/headers';

// Next.js met en cache les requêtes fetch côté serveur : on le désactive pour
// toujours lire l'état réel de la base (campagne ouverte, nouvelles réponses…).
const fetchSansCache: typeof fetch = (input, init) => fetch(input, { ...init, cache: 'no-store' });

function env() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error('Variables NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY manquantes.');
  return { url, key };
}

/** Client lié à la session de l'administrateur connecté (cookies). Les droits sont ceux des politiques RLS. */
export function createSessionClient() {
  const { url, key } = env();
  const cookieStore = cookies();
  return createServerClient(url, key, {
    global: { fetch: fetchSansCache },
    cookies: {
      getAll: () => cookieStore.getAll(),
      setAll: (list: { name: string; value: string; options: CookieOptions }[]) => {
        try {
          list.forEach(({ name, value, options }) => cookieStore.set(name, value, options));
        } catch {
          // Appel depuis un Server Component : le middleware se charge du rafraîchissement.
        }
      },
    },
  });
}

/**
 * Client anonyme, sans cookie ni session : utilisé pour la partie publique.
 * Les requêtes partent du serveur : l'adresse IP de l'étudiant n'est jamais
 * transmise à la base de données.
 */
export function createAnonClient() {
  const { url, key } = env();
  return createPlainClient(url, key, { auth: { persistSession: false, autoRefreshToken: false },
    global: { fetch: fetchSansCache },
  });
}
