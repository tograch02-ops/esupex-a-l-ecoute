import 'server-only';
import type { SupabaseClient } from '@supabase/supabase-js';
import { questionnaireSchema, type Questionnaire, type Answers } from './questionnaire';

export type Campagne = {
  id: string;
  titre: string;
  description: string | null;
  annee_academique: string | null;
  statut: 'brouillon' | 'ouverte' | 'cloturee';
  questionnaire: Questionnaire;
  date_ouverture: string | null;
  date_cloture: string | null;
  created_at: string;
};

export type Referentiel = { id: number; libelle: string; ordre: number; actif: boolean };
export type Reponse = {
  id: string;
  campagne_id: string;
  filiere: string;
  niveau: string;
  annee_academique: string;
  reponses: Answers;
  date_soumission: string;
};
export type Effectif = { id: number; annee_academique: string; filiere: string; niveau: string; effectif: number };

export async function getOpenCampaign(sb: SupabaseClient): Promise<Campagne | null> {
  const { data, error } = await sb.from('campagnes').select('*').eq('statut', 'ouverte').maybeSingle();
  if (error || !data) { if (error) console.error('[getOpenCampaign]', error.message); return null; }
  const parsed = questionnaireSchema.safeParse(data.questionnaire);
  if (!parsed.success) return null;
  return { ...data, questionnaire: parsed.data } as Campagne;
}

export async function getReferentiels(sb: SupabaseClient, onlyActive = true) {
  const q = (t: string) => {
    let query = sb.from(t).select('*').order('ordre').order('libelle');
    if (onlyActive) query = query.eq('actif', true);
    return query;
  };
  const [f, n, a] = await Promise.all([q('filieres'), q('niveaux'), q('annees_academiques')]);
  return {
    filieres: (f.data ?? []) as Referentiel[],
    niveaux: (n.data ?? []) as Referentiel[],
    annees: (a.data ?? []) as Referentiel[],
  };
}

export async function getCampaigns(sb: SupabaseClient): Promise<Campagne[]> {
  const { data } = await sb.from('campagnes').select('*').order('created_at', { ascending: false });
  return (data ?? []).map((c) => ({ ...c, questionnaire: c.questionnaire as Questionnaire })) as Campagne[];
}

/** Récupère toutes les réponses (pagination : Supabase limite à 1000 lignes par requête). */
export async function getAllResponses(
  sb: SupabaseClient,
  filters: { campagneId?: string; filiere?: string; niveau?: string; annee?: string } = {},
): Promise<Reponse[]> {
  const pageSize = 1000;
  const out: Reponse[] = [];
  for (let from = 0; ; from += pageSize) {
    let q = sb.from('reponses').select('*').order('id').range(from, from + pageSize - 1);
    if (filters.campagneId) q = q.eq('campagne_id', filters.campagneId);
    if (filters.filiere) q = q.eq('filiere', filters.filiere);
    if (filters.niveau) q = q.eq('niveau', filters.niveau);
    if (filters.annee) q = q.eq('annee_academique', filters.annee);
    const { data, error } = await q;
    if (error) throw new Error(error.message);
    out.push(...((data ?? []) as Reponse[]));
    if (!data || data.length < pageSize) break;
  }
  return out;
}

export async function getEffectifs(sb: SupabaseClient): Promise<Effectif[]> {
  const { data } = await sb.from('effectifs').select('*').order('annee_academique').order('filiere').order('niveau');
  return (data ?? []) as Effectif[];
}

export async function getSeuil(sb: SupabaseClient): Promise<number> {
  const { data } = await sb.from('parametres').select('seuil_confidentialite').eq('id', 1).maybeSingle();
  return data?.seuil_confidentialite ?? 5;
}
