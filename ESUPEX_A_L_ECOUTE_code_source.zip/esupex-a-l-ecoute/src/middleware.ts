import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

// Le middleware ne s'applique qu'à l'espace d'administration :
// la partie étudiante ne crée ni ne lit aucun cookie.
export async function middleware(request: NextRequest) {
  let response = NextResponse.next({ request });
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => request.cookies.getAll(),
        setAll: (list: { name: string; value: string; options: CookieOptions }[]) => {
          list.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          list.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
        },
      },
    },
  );
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;
  const isLogin = path.startsWith('/admin/connexion');
  if (!user && !isLogin && (path.startsWith('/admin') || path.startsWith('/api/admin'))) {
    if (path.startsWith('/api/')) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
    const url = request.nextUrl.clone();
    url.pathname = '/admin/connexion';
    url.search = '';
    return NextResponse.redirect(url);
  }
  response.headers.set('Cache-Control', 'private, no-store');
  response.headers.set('X-Robots-Tag', 'noindex, nofollow');
  return response;
}

export const config = { matcher: ['/admin/:path*', '/api/admin/:path*'] };
