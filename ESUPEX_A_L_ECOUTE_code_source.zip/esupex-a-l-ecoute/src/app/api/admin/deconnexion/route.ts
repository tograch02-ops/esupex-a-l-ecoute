import { NextResponse } from 'next/server';
import { createSessionClient } from '@/lib/supabase/server';

export async function POST(req: Request) {
  await createSessionClient().auth.signOut();
  return NextResponse.redirect(new URL('/admin/connexion', req.url), { status: 303 });
}
