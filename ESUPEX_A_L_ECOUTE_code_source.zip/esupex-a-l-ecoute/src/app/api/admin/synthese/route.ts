import { NextResponse } from 'next/server';
import { getAdminOrNull } from '@/lib/admin';
import { chargerContexte } from '@/lib/contexte-admin';
import { extraireCommentaires } from '@/lib/themes';
import { allQuestions } from '@/lib/questionnaire';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const CONSIGNES = `Tu analyses des commentaires anonymes d'étudiants d'une école d'ingénierie (ESUPEX, Burkina Faso) pour la direction.
Règles impératives :
- Regroupe les commentaires en 4 à 10 thèmes récurrents, du plus fréquent au moins fréquent.
- Pour chaque thème : un titre court, un résumé factuel de 1 à 3 phrases, et la liste EXHAUSTIVE des références (champ "ref") des commentaires qui l'expriment.
- N'invente AUCUNE opinion, aucun chiffre, aucun fait absent des commentaires. Ne modifie pas le sens des propos.
- N'inclus aucun nom de personne dans les résumés.
- Réponds UNIQUEMENT avec un objet JSON de la forme {"themes":[{"titre":"...","resume":"...","refs":["R1-xxx"]}]}.`;

export async function POST(req: Request) {
  const admin = await getAdminOrNull();
  if (!admin) return NextResponse.json({ error: 'Accès refusé' }, { status: 403 });
  const cle = process.env.ANTHROPIC_API_KEY;
  if (!cle) return NextResponse.json({ error: 'Synthèse IA non configurée.' }, { status: 501 });

  const sp = Object.fromEntries(new URL(req.url).searchParams.entries());
  const ctx = await chargerContexte(admin.supabase, sp);
  if (!ctx.campagne) return NextResponse.json({ error: 'Aucune campagne' }, { status: 404 });
  if (ctx.lignes.length < ctx.seuil) return NextResponse.json({ error: 'Effectif inférieur au seuil de confidentialité.' }, { status: 403 });

  const questionId = allQuestions(ctx.questionnaire).some((q) => q.id === sp.question) ? sp.question : undefined;
  const commentaires = extraireCommentaires(ctx.lignes, ctx.questionnaire, questionId).slice(0, 1500);
  if (!commentaires.length) return NextResponse.json({ themes: [] });

  const corps = commentaires.map((c) => ({ ref: c.ref, question: c.question, texte: c.texte }));
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': cle, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
      max_tokens: 4000,
      system: CONSIGNES,
      messages: [{ role: 'user', content: `Commentaires (JSON) :\n${JSON.stringify(corps)}` }],
    }),
  });
  if (!r.ok) return NextResponse.json({ error: `Service IA indisponible (${r.status}).` }, { status: 502 });
  const data = await r.json();
  const texte: string = (data.content ?? []).filter((b: { type: string }) => b.type === 'text').map((b: { text: string }) => b.text).join('');
  const json = texte.slice(texte.indexOf('{'), texte.lastIndexOf('}') + 1);
  try {
    const parsed = JSON.parse(json) as { themes: { titre: string; resume: string; refs: string[] }[] };
    // Contrôle : on ne garde que les références qui existent réellement.
    const connues = new Set(commentaires.map((c) => c.ref));
    const themes = (parsed.themes ?? [])
      .map((t) => ({ titre: String(t.titre), resume: String(t.resume), refs: (t.refs ?? []).filter((x) => connues.has(x)) }))
      .filter((t) => t.refs.length > 0);
    return NextResponse.json({ themes });
  } catch {
    return NextResponse.json({ error: 'Réponse de l’IA illisible, réessayez.' }, { status: 502 });
  }
}
