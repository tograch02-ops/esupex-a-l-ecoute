import { NextResponse } from 'next/server';
import ExcelJS from 'exceljs';
import { getAdminOrNull } from '@/lib/admin';
import { chargerContexte } from '@/lib/contexte-admin';
import { tabulaire, versCsv } from '@/lib/export';
import { calculerStatistiques } from '@/lib/stats';
import { DIMENSION_LIBELLES, allQuestions } from '@/lib/questionnaire';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const admin = await getAdminOrNull();
  if (!admin) return NextResponse.json({ error: 'Accès refusé' }, { status: 403 });

  const url = new URL(req.url);
  const sp = Object.fromEntries(url.searchParams.entries());
  const ctx = await chargerContexte(admin.supabase, sp);
  if (!ctx.campagne) return NextResponse.json({ error: 'Aucune campagne' }, { status: 404 });

  const { colonnes, donnees } = tabulaire(ctx.questionnaire, ctx.lignes);
  const base = `ESUPEX_reponses_${ctx.campagne.titre.replace(/[^a-zA-Z0-9]+/g, '_')}`;
  const entetes = (type: string, ext: string) => ({
    'Content-Type': type,
    'Content-Disposition': `attachment; filename="${base}.${ext}"`,
    'Cache-Control': 'no-store',
  });

  if (url.searchParams.get('format') === 'csv')
    return new NextResponse(versCsv(colonnes, donnees), { headers: entetes('text/csv; charset=utf-8', 'csv') });

  // --- Classeur Excel : réponses brutes + synthèse + dictionnaire des variables
  const stats = calculerStatistiques(ctx.lignes, ctx.questionnaire, {
    seuil: ctx.seuil,
    effectifs: ctx.effectifs,
    filtres: ctx.filtres,
    ordreFilieres: ctx.ordre.filieres,
    ordreNiveaux: ctx.ordre.niveaux,
    ordreAnnees: ctx.ordre.annees,
  });
  const wb = new ExcelJS.Workbook();
  wb.creator = "ESUPEX À L'ÉCOUTE";
  const entete = (ws: ExcelJS.Worksheet) => {
    ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF123D70' } };
    ws.views = [{ state: 'frozen', ySplit: 1 }];
  };

  const wsR = wb.addWorksheet('Réponses');
  wsR.columns = colonnes.map((c) => ({ header: c.titre, key: c.cle, width: c.cle.startsWith('_') ? 16 : 22 }));
  donnees.forEach((d) => wsR.addRow(d));
  entete(wsR);
  wsR.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: colonnes.length } };

  const wsS = wb.addWorksheet('Synthèse par élément');
  wsS.columns = [
    { header: 'Rubrique', key: 'dim', width: 34 },
    { header: 'Élément', key: 'label', width: 55 },
    { header: 'Moyenne /5', key: 'moy', width: 12 },
    { header: '% satisfaits', key: 'ps', width: 12 },
    { header: '% insatisfaits', key: 'pi', width: 13 },
    { header: 'Note 1', key: 'd1', width: 8 },
    { header: 'Note 2', key: 'd2', width: 8 },
    { header: 'Note 3', key: 'd3', width: 8 },
    { header: 'Note 4', key: 'd4', width: 8 },
    { header: 'Note 5', key: 'd5', width: 8 },
    { header: 'N', key: 'n', width: 7 },
    { header: 'Non concernés', key: 'na', width: 13 },
  ];
  stats.items.forEach((it) =>
    wsS.addRow({
      dim: DIMENSION_LIBELLES[it.dimension],
      label: it.label,
      moy: it.moyenne,
      ps: it.pctSatisfaits,
      pi: it.pctInsatisfaits,
      d1: it.distribution[0],
      d2: it.distribution[1],
      d3: it.distribution[2],
      d4: it.distribution[3],
      d5: it.distribution[4],
      n: it.n,
      na: it.nNA,
    }),
  );
  entete(wsS);

  const wsC = wb.addWorksheet('Comparaisons');
  wsC.columns = [
    { header: 'Axe', key: 'axe', width: 14 },
    { header: 'Groupe', key: 'g', width: 44 },
    { header: 'N', key: 'n', width: 7 },
    { header: 'Satisfaction générale /5', key: 's', width: 14 },
    { header: '% satisfaits', key: 'ps', width: 12 },
    { header: 'Pédagogie /5', key: 'p', width: 12 },
    { header: 'Administration /5', key: 'a', width: 14 },
    { header: 'Infrastructures /5', key: 'i', width: 14 },
    { header: 'Note /10', key: 'note', width: 10 },
  ];
  (['filiere', 'niveau', 'annee'] as const).forEach((axe) =>
    stats.comparaisons[axe].forEach((l) =>
      wsC.addRow({
        axe: { filiere: 'Filière', niveau: 'Niveau', annee: 'Année' }[axe],
        g: l.groupe,
        n: l.n,
        s: l.masque ? 'masqué' : l.satisfactionGlobale,
        ps: l.masque ? 'masqué' : l.pctSatisfaits,
        p: l.masque ? 'masqué' : l.pedagogie,
        a: l.masque ? 'masqué' : l.administration,
        i: l.masque ? 'masqué' : l.infrastructures,
        note: l.masque ? 'masqué' : l.noteGlobale,
      }),
    ),
  );
  entete(wsC);

  const wsD = wb.addWorksheet('Dictionnaire');
  wsD.columns = [
    { header: 'Code', key: 'id', width: 26 },
    { header: 'Question', key: 'label', width: 80 },
    { header: 'Type', key: 'type', width: 14 },
    { header: 'Valeurs', key: 'val', width: 60 },
  ];
  allQuestions(ctx.questionnaire).forEach((qu) =>
    wsD.addRow({
      id: qu.id,
      label: qu.label,
      type: qu.type,
      val:
        qu.type === 'likert'
          ? `1 à 5 (${ctx.questionnaire.likertLabels.join(' / ')})${qu.allowNA ? ' ; NC = non concerné' : ''}`
          : qu.type === 'scale10'
            ? '0 à 10'
            : qu.type === 'text'
              ? 'texte libre'
              : qu.options.join(' ; '),
    }),
  );
  entete(wsD);

  const buf = await wb.xlsx.writeBuffer();
  return new NextResponse(buf as ArrayBuffer, {
    headers: entetes('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'xlsx'),
  });
}
