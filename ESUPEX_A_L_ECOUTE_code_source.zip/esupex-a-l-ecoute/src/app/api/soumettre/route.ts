import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAnonClient } from '@/lib/supabase/server';
import { getOpenCampaign } from '@/lib/data';
import { sanitizeAnswers } from '@/lib/questionnaire';

export const dynamic = 'force-dynamic';

const corpsSchema = z.object({
  campagneId: z.string().uuid(),
  filiere: z.string().min(1).max(150),
  niveau: z.string().min(1).max(60),
  anneeAcademique: z.string().min(1).max(30),
  reponses: z.unknown(),
  site_web: z.string().optional(),
});

const MESSAGES: Record<string, string> = {
  CAMPAGNE_FERMEE: 'Cette consultation est clôturée.',
  FILIERE_INVALIDE: 'Filière inconnue.',
  NIVEAU_INVALIDE: 'Niveau inconnu.',
  ANNEE_INVALIDE: 'Année académique inconnue.',
};

/**
 * Réception d'un questionnaire.
 * ANONYMAT : cette route ne lit ni l'adresse IP, ni les en-têtes, ni les
 * cookies, et ne journalise rien. Elle transmet seulement les réponses
 * validées à la fonction submit_response() de la base.
 */
export async function POST(req: Request) {
  const texte = await req.text();
  if (texte.length > 80_000) return NextResponse.json({ error: 'Réponses trop volumineuses.' }, { status: 413 });

  let corps: z.infer<typeof corpsSchema>;
  try {
    corps = corpsSchema.parse(JSON.parse(texte));
  } catch {
    return NextResponse.json({ error: 'Requête invalide.' }, { status: 400 });
  }

  // Champ piège rempli = robot : on répond « succès » sans rien enregistrer.
  if (corps.site_web) return NextResponse.json({ ok: true });

  const sb = createAnonClient();
  const campagne = await getOpenCampaign(sb);
  if (!campagne || campagne.id !== corps.campagneId)
    return NextResponse.json({ error: MESSAGES.CAMPAGNE_FERMEE }, { status: 409 });

  const propres = sanitizeAnswers(campagne.questionnaire, corps.reponses);
  if (!propres.ok) return NextResponse.json({ error: propres.error }, { status: 422 });

  const { error } = await sb.rpc('submit_response', {
    p_campagne_id: corps.campagneId,
    p_filiere: corps.filiere,
    p_niveau: corps.niveau,
    p_annee_academique: corps.anneeAcademique,
    p_reponses: propres.answers,
  });
  if (error) {
    const code = Object.keys(MESSAGES).find((k) => error.message.includes(k));
    return NextResponse.json(
      { error: code ? MESSAGES[code] : 'Enregistrement impossible pour le moment. Réessaie plus tard.' },
      { status: code ? 422 : 500 },
    );
  }
  return NextResponse.json({ ok: true });
}
