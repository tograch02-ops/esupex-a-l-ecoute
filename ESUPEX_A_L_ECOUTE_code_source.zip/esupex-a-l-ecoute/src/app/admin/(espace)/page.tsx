import Link from 'next/link';
import { requireAdmin } from '@/lib/admin';
import { chargerContexte, type SP } from '@/lib/contexte-admin';
import { getAllResponses } from '@/lib/data';
import { calculerStatistiques, syntheseCampagne } from '@/lib/stats';
import { analyserThemes, extraireCommentaires } from '@/lib/themes';
import { questionnaireSchema } from '@/lib/questionnaire';
import { Filtres } from '@/components/admin/Filtres';
import TableauDeBord from '@/components/admin/TableauDeBord';

export default async function PageTableauDeBord({ searchParams }: { searchParams: SP }) {
  const { supabase } = await requireAdmin();
  const ctx = await chargerContexte(supabase, searchParams);

  if (!ctx.campagne)
    return (
      <div className="carte mx-auto max-w-xl text-center">
        <h1 className="text-xl font-bold text-marque-900">Bienvenue dans l&apos;observatoire</h1>
        <p className="mt-2 text-sm text-slate-600">
          Aucune campagne n&apos;a encore été créée. Commencez par créer une campagne de recensement, puis ouvrez-la pour
          activer le lien public des étudiants.
        </p>
        <Link href="/admin/campagnes" className="btn-primaire mt-5">
          Créer une campagne
        </Link>
      </div>
    );

  const { campagne, questionnaire, lignes, seuil, effectifs, ordre, filtres } = ctx;
  const stats = calculerStatistiques(lignes, questionnaire, {
    seuil,
    effectifs,
    filtres,
    ordreFilieres: ordre.filieres,
    ordreNiveaux: ordre.niveaux,
    ordreAnnees: ordre.annees,
  });

  // Améliorations les plus demandées : thèmes des réponses à la question « trois améliorations prioritaires ».
  const ameliorations =
    stats.masque || !questionnaire.roles.ameliorations
      ? []
      : analyserThemes(extraireCommentaires(lignes, questionnaire, questionnaire.roles.ameliorations)).themes
          .slice(0, 6)
          .map((t) => ({ libelle: t.libelle, n: t.n }));

  // Évolution entre campagnes (sans filtre, chaque campagne avec son propre questionnaire).
  let evolution: { titre: string; statut: string; n: number; satisfactionGlobale: number | null; pedagogie: number | null; administration: number | null; infrastructures: number | null; noteGlobale: number | null }[] = [];
  if (ctx.campagnes.length > 1) {
    const toutes = await getAllResponses(supabase);
    evolution = [...ctx.campagnes]
      .reverse()
      .filter((c) => c.statut !== 'brouillon')
      .map((c) => {
        const q = questionnaireSchema.safeParse(c.questionnaire);
        const ls = toutes.filter((r) => r.campagne_id === c.id);
        const s = q.success ? syntheseCampagne(ls, q.data, seuil) : null;
        return {
          titre: c.titre,
          statut: c.statut,
          n: ls.length,
          satisfactionGlobale: s?.satisfactionGlobale ?? null,
          pedagogie: s?.pedagogie ?? null,
          administration: s?.administration ?? null,
          infrastructures: s?.infrastructures ?? null,
          noteGlobale: s?.noteGlobale ?? null,
        };
      });
  }

  const filtresTexte = [filtres.filiere, filtres.niveau, filtres.annee].filter(Boolean).join(' · ') || 'Ensemble des étudiants';
  const qs = new URLSearchParams({ campagne: campagne.id, ...Object.fromEntries(Object.entries(filtres).filter(([, v]) => v) as [string, string][]) }).toString();

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-marque-900">Observatoire de la satisfaction estudiantine</h1>
          <p className="text-sm text-slate-500">
            {campagne.titre} · {filtresTexte}
          </p>
        </div>
      </div>
      <Filtres
        campagnes={ctx.campagnes.map((c) => ({ id: c.id, titre: c.titre, statut: c.statut }))}
        campagneId={campagne.id}
        filieres={ordre.filieres}
        niveaux={ordre.niveaux}
        annees={ordre.annees}
      />
      <TableauDeBord
        stats={stats}
        campagneTitre={campagne.titre}
        filtresTexte={filtresTexte}
        ameliorations={ameliorations}
        evolution={evolution}
        exportQuery={qs}
        likertLabels={questionnaire.likertLabels}
      />
    </div>
  );
}
