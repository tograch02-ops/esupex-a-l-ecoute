'use client';
import { useFormState, useFormStatus } from 'react-dom';
import { enregistrerQuestionnaire, modifierCampagne } from '../actions';

function Bouton({ texte }: { texte: string }) {
  const { pending } = useFormStatus();
  return <button className="btn-primaire btn-petit" disabled={pending}>{pending ? 'Enregistrement…' : texte}</button>;
}

function Message({ etat }: { etat: { erreur?: string; ok?: string } | null }) {
  if (!etat) return null;
  return <p className={`text-sm ${etat.erreur ? 'text-red-600' : 'text-emerald-700'}`}>{etat.erreur ?? etat.ok}</p>;
}

export function FormulaireInfos({ id, titre, description, annee, annees }: { id: string; titre: string; description: string; annee: string; annees: string[] }) {
  const [etat, action] = useFormState(modifierCampagne, null);
  return (
    <form action={action} className="carte space-y-3">
      <h2 className="font-semibold">Informations</h2>
      <input type="hidden" name="id" value={id} />
      <div>
        <label className="etiquette">Titre</label>
        <input name="titre" className="champ" defaultValue={titre} />
      </div>
      <div>
        <label className="etiquette">Année académique (présélectionnée pour les étudiants)</label>
        <select name="annee" className="champ" defaultValue={annee}>
          <option value="">— Non précisée —</option>
          {annees.map((a) => (
            <option key={a}>{a}</option>
          ))}
        </select>
      </div>
      <div>
        <label className="etiquette">Description (interne)</label>
        <textarea name="description" className="champ" rows={3} defaultValue={description} />
      </div>
      <Message etat={etat} />
      <Bouton texte="Enregistrer" />
    </form>
  );
}

export function EditeurQuestionnaire({ id, json, verrouille }: { id: string; json: string; verrouille: boolean }) {
  const [etat, action] = useFormState(enregistrerQuestionnaire, null);
  return (
    <details className="carte">
      <summary className="cursor-pointer font-semibold">Modifier le questionnaire (format JSON, avancé)</summary>
      {verrouille ? (
        <p className="mt-3 rounded-lg bg-amber-50 p-3 text-sm text-amber-800">
          Cette campagne a reçu des réponses : son questionnaire est verrouillé pour garantir la cohérence des résultats. Pour
          un nouveau questionnaire, créez une nouvelle campagne « copie de » celle-ci, puis modifiez la copie.
        </p>
      ) : (
        <form action={action} className="mt-3 space-y-3">
          <p className="text-xs text-slate-500">
            Vous pouvez modifier les libellés, ajouter ou retirer des questions et des options. Types disponibles : likert (1–5, option
            allowNA), scale10 (0–10), text, single, multi. Chaque identifiant (id) doit être unique et écrit en minuscules. Le
            contenu est vérifié avant enregistrement ; voir le guide d&apos;utilisation pour des exemples.
          </p>
          <input type="hidden" name="id" value={id} />
          <textarea name="questionnaire" defaultValue={json} spellCheck={false} className="champ h-[480px] font-mono text-xs leading-relaxed" />
          <Message etat={etat} />
          <Bouton texte="Valider et enregistrer le questionnaire" />
        </form>
      )}
    </details>
  );
}
