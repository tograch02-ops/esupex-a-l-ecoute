import Link from 'next/link';
import { notFound } from 'next/navigation';
import { headers } from 'next/headers';
import { requireAdmin } from '@/lib/admin';
import { getReferentiels } from '@/lib/data';
import { questionnaireSchema, DIMENSION_LIBELLES } from '@/lib/questionnaire';
import { changerStatut, reinitialiserQuestionnaire, supprimerCampagne, supprimerReponses } from '../actions';
import { EditeurQuestionnaire, FormulaireInfos } from './Formulaires';

const TYPES: Record<string, string> = { likert: 'Échelle 1–5', scale10: 'Note 0–10', text: 'Texte libre', multi: 'Choix multiples', single: 'Choix unique' };

export default async function PageCampagne({ params }: { params: { id: string } }) {
  const { supabase } = await requireAdmin();
  const { data: c } = await supabase.from('campagnes').select('*').eq('id', params.id).maybeSingle();
  if (!c) notFound();
  const { count } = await supabase.from('reponses').select('id', { count: 'exact', head: true }).eq('campagne_id', c.id);
  const nb = count ?? 0;
  const ref = await getReferentiels(supabase);
  const q = questionnaireSchema.safeParse(c.questionnaire);
  const h = headers();
  const origine = `${h.get('x-forwarded-proto') ?? 'https'}://${h.get('host')}`;

  return (
    <div className="space-y-6">
      <Link href="/admin/campagnes" className="text-sm text-marque-600 hover:underline">
        ← Toutes les campagnes
      </Link>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-marque-900">{c.titre}</h1>
          <p className="text-sm text-slate-500">
            Statut : <strong>{{ ouverte: 'ouverte', cloturee: 'clôturée', brouillon: 'brouillon' }[c.statut as string]}</strong> · {nb} réponse(s)
          </p>
        </div>
        <div className="flex gap-2">
          {c.statut !== 'ouverte' ? (
            <form action={changerStatut}>
              <input type="hidden" name="id" value={c.id} />
              <input type="hidden" name="statut" value="ouverte" />
              <button className="btn-primaire">Ouvrir l&apos;enquête</button>
            </form>
          ) : (
            <form action={changerStatut}>
              <input type="hidden" name="id" value={c.id} />
              <input type="hidden" name="statut" value="cloturee" />
              <button className="btn-secondaire">Clôturer l&apos;enquête</button>
            </form>
          )}
          <Link href={`/admin?campagne=${c.id}`} className="btn-secondaire">
            Voir les résultats
          </Link>
        </div>
      </div>

      {c.statut === 'ouverte' && (
        <div className="carte border-emerald-200 bg-emerald-50">
          <p className="text-sm font-semibold text-emerald-900">Lien public à diffuser aux étudiants</p>
          <p className="mt-1 select-all break-all font-mono text-sm text-emerald-800">{origine}/</p>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <FormulaireInfos id={c.id} titre={c.titre} description={c.description ?? ''} annee={c.annee_academique ?? ''} annees={ref.annees.map((a) => a.libelle)} />
        <div className="carte">
          <h2 className="font-semibold">Aperçu du questionnaire</h2>
          {!q.success ? (
            <p className="mt-2 text-sm text-red-600">Questionnaire invalide.</p>
          ) : (
            <ol className="mt-3 space-y-3 text-sm">
              <li>
                <p className="font-medium text-marque-800">1. Profil académique</p>
                <p className="text-xs text-slate-500">Filière, niveau, année académique (référentiels)</p>
              </li>
              {q.data.sections.map((s, k) => (
                <li key={s.id}>
                  <p className="font-medium text-marque-800">
                    {k + 2}. {s.title} <span className="text-xs font-normal text-slate-400">({DIMENSION_LIBELLES[s.dimension]})</span>
                  </p>
                  <ul className="ml-4 mt-1 list-disc text-xs text-slate-600">
                    {s.questions.map((qu) => (
                      <li key={qu.id}>
                        {qu.label} <span className="text-slate-400">— {TYPES[qu.type]}{qu.required ? ', obligatoire' : ''}</span>
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ol>
          )}
        </div>
      </div>

      <EditeurQuestionnaire id={c.id} json={JSON.stringify(c.questionnaire, null, 2)} verrouille={nb > 0} />
      {nb === 0 && (
        <form action={reinitialiserQuestionnaire}>
          <input type="hidden" name="id" value={c.id} />
          <button className="text-xs text-slate-500 underline">Rétablir le questionnaire standard ESUPEX</button>
        </form>
      )}

      <div className="carte border-red-200">
        <h2 className="font-semibold text-red-700">Zone sensible</h2>
        <p className="mt-1 text-xs text-slate-500">Actions irréversibles. Tapez SUPPRIMER pour confirmer. Utile notamment pour effacer les réponses de test avant le lancement officiel.</p>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <form action={supprimerReponses} className="flex gap-2">
            <input type="hidden" name="id" value={c.id} />
            <input name="confirmation" className="champ" placeholder="SUPPRIMER" />
            <button className="btn-danger btn-petit whitespace-nowrap">Effacer les {nb} réponses</button>
          </form>
          <form action={supprimerCampagne} className="flex gap-2">
            <input type="hidden" name="id" value={c.id} />
            <input name="confirmation" className="champ" placeholder="SUPPRIMER" />
            <button className="btn-danger btn-petit whitespace-nowrap">Supprimer la campagne</button>
          </form>
        </div>
      </div>
    </div>
  );
}
