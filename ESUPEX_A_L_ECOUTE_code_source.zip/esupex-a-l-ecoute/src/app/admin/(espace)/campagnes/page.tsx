import Link from 'next/link';
import { requireAdmin } from '@/lib/admin';
import { getCampaigns, getReferentiels } from '@/lib/data';
import { changerStatut } from './actions';
import FormulaireCreation from './FormulaireCreation';

const BADGE: Record<string, string> = {
  ouverte: 'bg-emerald-100 text-emerald-800',
  brouillon: 'bg-slate-100 text-slate-700',
  cloturee: 'bg-amber-100 text-amber-800',
};
const LIB: Record<string, string> = { ouverte: '● Ouverte', brouillon: '○ Brouillon', cloturee: '■ Clôturée' };

export default async function PageCampagnes() {
  const { supabase } = await requireAdmin();
  const [campagnes, ref] = await Promise.all([getCampaigns(supabase), getReferentiels(supabase)]);
  const comptes = await Promise.all(
    campagnes.map(async (c) => {
      const { count } = await supabase.from('reponses').select('id', { count: 'exact', head: true }).eq('campagne_id', c.id);
      return count ?? 0;
    }),
  );

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-marque-900">Campagnes de recensement</h1>
          <p className="text-sm text-slate-500">
            Une seule campagne peut être ouverte à la fois : c&apos;est elle qui s&apos;affiche sur le lien public des étudiants.
          </p>
        </div>
        {campagnes.length === 0 && <p className="carte text-sm text-slate-500">Aucune campagne. Créez la première avec le formulaire.</p>}
        {campagnes.map((c, k) => (
          <div key={c.id} className="carte flex flex-wrap items-center gap-4">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <Link href={`/admin/campagnes/${c.id}`} className="font-semibold text-marque-800 hover:underline">
                  {c.titre}
                </Link>
                <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${BADGE[c.statut]}`}>{LIB[c.statut]}</span>
              </div>
              <p className="mt-1 text-xs text-slate-500">
                {c.annee_academique ?? 'Année non précisée'} · {comptes[k]} réponse(s) · créée le{' '}
                {new Date(c.created_at).toLocaleDateString('fr-FR')}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {c.statut !== 'ouverte' && (
                <form action={changerStatut}>
                  <input type="hidden" name="id" value={c.id} />
                  <input type="hidden" name="statut" value="ouverte" />
                  <button className="btn-primaire btn-petit">{c.statut === 'cloturee' ? 'Rouvrir' : 'Ouvrir l’enquête'}</button>
                </form>
              )}
              {c.statut === 'ouverte' && (
                <form action={changerStatut}>
                  <input type="hidden" name="id" value={c.id} />
                  <input type="hidden" name="statut" value="cloturee" />
                  <button className="btn-secondaire btn-petit">Clôturer</button>
                </form>
              )}
              <Link href={`/admin/campagnes/${c.id}`} className="btn-secondaire btn-petit">
                Gérer
              </Link>
            </div>
          </div>
        ))}
      </div>
      <FormulaireCreation annees={ref.annees.map((a) => a.libelle)} campagnes={campagnes.map((c) => ({ id: c.id, titre: c.titre }))} />
    </div>
  );
}
