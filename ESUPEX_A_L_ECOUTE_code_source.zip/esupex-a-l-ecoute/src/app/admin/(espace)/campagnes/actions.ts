'use server';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { requireAdmin } from '@/lib/admin';
import { DEFAULT_QUESTIONNAIRE, questionnaireSchema } from '@/lib/questionnaire';

export type Etat = { erreur?: string; ok?: string } | null;

export async function creerCampagne(_: Etat, fd: FormData): Promise<Etat> {
  const { supabase } = await requireAdmin();
  const titre = String(fd.get('titre') ?? '').trim();
  const description = String(fd.get('description') ?? '').trim() || null;
  const annee = String(fd.get('annee') ?? '').trim() || null;
  const modele = String(fd.get('modele') ?? 'defaut');
  if (titre.length < 3) return { erreur: 'Le titre est obligatoire.' };

  let questionnaire = DEFAULT_QUESTIONNAIRE;
  if (modele !== 'defaut') {
    const { data } = await supabase.from('campagnes').select('questionnaire').eq('id', modele).maybeSingle();
    const p = questionnaireSchema.safeParse(data?.questionnaire);
    if (p.success) questionnaire = p.data;
  }
  const { data, error } = await supabase
    .from('campagnes')
    .insert({ titre, description, annee_academique: annee, questionnaire, statut: 'brouillon' })
    .select('id')
    .single();
  if (error) return { erreur: error.message };
  revalidatePath('/admin/campagnes');
  redirect(`/admin/campagnes/${data.id}`);
}

export async function changerStatut(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = String(fd.get('id'));
  const statut = String(fd.get('statut'));
  if (!['ouverte', 'cloturee', 'brouillon'].includes(statut)) return;
  if (statut === 'ouverte') {
    // Une seule campagne ouverte : les autres sont clôturées automatiquement.
    await supabase.from('campagnes').update({ statut: 'cloturee', date_cloture: new Date().toISOString() }).eq('statut', 'ouverte').neq('id', id);
  }
  const maj: Record<string, unknown> = { statut };
  if (statut === 'ouverte') maj.date_ouverture = new Date().toISOString();
  if (statut === 'cloturee') maj.date_cloture = new Date().toISOString();
  await supabase.from('campagnes').update(maj).eq('id', id);
  revalidatePath('/admin/campagnes');
  revalidatePath(`/admin/campagnes/${id}`);
}

export async function modifierCampagne(_: Etat, fd: FormData): Promise<Etat> {
  const { supabase } = await requireAdmin();
  const id = String(fd.get('id'));
  const titre = String(fd.get('titre') ?? '').trim();
  const description = String(fd.get('description') ?? '').trim() || null;
  const annee = String(fd.get('annee') ?? '').trim() || null;
  if (titre.length < 3) return { erreur: 'Le titre est obligatoire.' };
  const { error } = await supabase.from('campagnes').update({ titre, description, annee_academique: annee }).eq('id', id);
  if (error) return { erreur: error.message };
  revalidatePath(`/admin/campagnes/${id}`);
  return { ok: 'Informations enregistrées.' };
}

export async function enregistrerQuestionnaire(_: Etat, fd: FormData): Promise<Etat> {
  const { supabase } = await requireAdmin();
  const id = String(fd.get('id'));
  const { count } = await supabase.from('reponses').select('id', { count: 'exact', head: true }).eq('campagne_id', id);
  if ((count ?? 0) > 0)
    return { erreur: 'Cette campagne a déjà reçu des réponses : son questionnaire ne peut plus être modifié (les résultats deviendraient incohérents). Créez une nouvelle campagne à partir de celle-ci.' };
  let brut: unknown;
  try {
    brut = JSON.parse(String(fd.get('questionnaire') ?? ''));
  } catch (e) {
    return { erreur: `JSON invalide : ${(e as Error).message}` };
  }
  const p = questionnaireSchema.safeParse(brut);
  if (!p.success) return { erreur: p.error.issues.map((i) => `${i.path.join('.')} : ${i.message}`).slice(0, 6).join(' | ') };
  const { error } = await supabase.from('campagnes').update({ questionnaire: p.data }).eq('id', id);
  if (error) return { erreur: error.message };
  revalidatePath(`/admin/campagnes/${id}`);
  return { ok: 'Questionnaire enregistré.' };
}

export async function reinitialiserQuestionnaire(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = String(fd.get('id'));
  const { count } = await supabase.from('reponses').select('id', { count: 'exact', head: true }).eq('campagne_id', id);
  if ((count ?? 0) > 0) return;
  await supabase.from('campagnes').update({ questionnaire: DEFAULT_QUESTIONNAIRE }).eq('id', id);
  revalidatePath(`/admin/campagnes/${id}`);
}

export async function supprimerReponses(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = String(fd.get('id'));
  if (String(fd.get('confirmation')) !== 'SUPPRIMER') return;
  await supabase.from('reponses').delete().eq('campagne_id', id);
  revalidatePath(`/admin/campagnes/${id}`);
  revalidatePath('/admin');
}

export async function supprimerCampagne(fd: FormData) {
  const { supabase } = await requireAdmin();
  const id = String(fd.get('id'));
  if (String(fd.get('confirmation')) !== 'SUPPRIMER') return;
  await supabase.from('campagnes').delete().eq('id', id);
  revalidatePath('/admin/campagnes');
  redirect('/admin/campagnes');
}
