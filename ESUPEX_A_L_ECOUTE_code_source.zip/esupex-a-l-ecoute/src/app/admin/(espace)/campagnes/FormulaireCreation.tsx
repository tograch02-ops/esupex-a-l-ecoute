'use client';
import { useFormState, useFormStatus } from 'react-dom';
import { creerCampagne } from './actions';

function Bouton() {
  const { pending } = useFormStatus();
  return (
    <button className="btn-primaire w-full" disabled={pending}>
      {pending ? 'Création…' : 'Créer la campagne'}
    </button>
  );
}

export default function FormulaireCreation({ annees, campagnes }: { annees: string[]; campagnes: { id: string; titre: string }[] }) {
  const [etat, action] = useFormState(creerCampagne, null);
  return (
    <form action={action} className="carte h-fit space-y-4">
      <h2 className="font-semibold text-slate-900">Nouvelle campagne</h2>
      <div>
        <label className="etiquette">Titre</label>
        <input name="titre" className="champ" placeholder="Ex. : Campagne 2026-2027 – Semestre 1" required />
      </div>
      <div>
        <label className="etiquette">Année académique</label>
        <select name="annee" className="champ">
          <option value="">— Non précisée —</option>
          {annees.map((a) => (
            <option key={a}>{a}</option>
          ))}
        </select>
      </div>
      <div>
        <label className="etiquette">Description (interne)</label>
        <textarea name="description" className="champ" rows={2} />
      </div>
      <div>
        <label className="etiquette">Questionnaire de départ</label>
        <select name="modele" className="champ">
          <option value="defaut">Questionnaire standard ESUPEX (7 rubriques)</option>
          {campagnes.map((c) => (
            <option key={c.id} value={c.id}>
              Copie de : {c.titre}
            </option>
          ))}
        </select>
      </div>
      {etat?.erreur && <p className="text-sm text-red-600">{etat.erreur}</p>}
      <Bouton />
      <p className="text-xs text-slate-500">La campagne est créée en brouillon : vous pourrez relire et adapter le questionnaire avant de l&apos;ouvrir.</p>
    </form>
  );
}
