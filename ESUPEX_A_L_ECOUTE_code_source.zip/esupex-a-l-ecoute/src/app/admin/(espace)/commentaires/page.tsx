import { requireAdmin } from '@/lib/admin';
import { chargerContexte, type SP } from '@/lib/contexte-admin';
import { analyserThemes, extraireCommentaires } from '@/lib/themes';
import { allQuestions } from '@/lib/questionnaire';
import { Filtres } from '@/components/admin/Filtres';
import AnalyseCommentaires from '@/components/admin/AnalyseCommentaires';

export default async function PageCommentaires({ searchParams }: { searchParams: SP & { question?: string } }) {
  const { supabase } = await requireAdmin();
  const ctx = await chargerContexte(supabase, searchParams);
  if (!ctx.campagne) return <p className="carte">Aucune campagne.</p>;

  const questionsTexte = allQuestions(ctx.questionnaire)
    .filter((q) => q.type === 'text')
    .map((q) => ({ id: q.id, label: q.label }));
  const questionId = questionsTexte.some((q) => q.id === searchParams.question) ? searchParams.question : undefined;
  const masque = ctx.lignes.length < ctx.seuil;
  const commentaires = masque ? [] : extraireCommentaires(ctx.lignes, ctx.questionnaire, questionId);
  const resultat = analyserThemes(commentaires);
  const qs = new URLSearchParams(
    Object.entries({ campagne: ctx.campagne.id, ...ctx.filtres, question: questionId }).filter(([, v]) => v) as [string, string][],
  ).toString();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-marque-900">Analyse des commentaires</h1>
        <p className="text-sm text-slate-500">
          Regroupement automatique des réponses ouvertes par thèmes. Chaque thème renvoie aux commentaires originaux,
          non modifiés.
        </p>
      </div>
      <Filtres
        campagnes={ctx.campagnes.map((c) => ({ id: c.id, titre: c.titre, statut: c.statut }))}
        campagneId={ctx.campagne.id}
        filieres={ctx.ordre.filieres}
        niveaux={ctx.ordre.niveaux}
        annees={ctx.ordre.annees}
      />
      {masque ? (
        <div className="carte border-accent-500/50 bg-accent-100/40 text-sm text-slate-700">
          Cette sélection compte {ctx.lignes.length} réponse(s), moins que le seuil de confidentialité ({ctx.seuil}) :
          les commentaires ne sont pas affichés afin de ne pas permettre l&apos;identification de leurs auteurs.
        </div>
      ) : (
        <AnalyseCommentaires
          resultat={resultat}
          questions={questionsTexte}
          questionId={questionId ?? ''}
          syntheseQuery={qs}
          iaDisponible={Boolean(process.env.ANTHROPIC_API_KEY)}
        />
      )}
    </div>
  );
}
