import Image from 'next/image';
import { requireAdmin } from '@/lib/admin';
import { NavAdmin } from '@/components/admin/NavAdmin';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Administration – ESUPEX À L’ÉCOUTE' };

export default async function LayoutAdmin({ children }: { children: React.ReactNode }) {
  const { user } = await requireAdmin();
  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-marque-900 text-white print:hidden">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-3">
            <span className="rounded bg-white p-1">
              <Image src="/logo-esupex.svg" alt="ESUPEX" width={90} height={27} />
            </span>
            <div>
              <p className="text-sm font-bold tracking-wide">ESUPEX À L&apos;ÉCOUTE</p>
              <p className="text-[11px] text-marque-200">Observatoire de la satisfaction estudiantine</p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="hidden text-marque-200 sm:inline">{user.email}</span>
            <form action="/api/admin/deconnexion" method="post">
              <button className="rounded border border-marque-200/40 px-3 py-1.5 hover:bg-white/10">Déconnexion</button>
            </form>
          </div>
        </div>
        <NavAdmin />
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6">{children}</main>
    </div>
  );
}
