import { requireAdmin } from '@/lib/admin';
import { getEffectifs, getReferentiels, getSeuil, type Referentiel } from '@/lib/data';
import { ajouterReferentiel, basculerReferentiel, deplacerReferentiel, enregistrerEffectifs, enregistrerSeuil } from './actions';

export default async function PageParametres({ searchParams }: { searchParams: { annee?: string } }) {
  const { supabase } = await requireAdmin();
  const [ref, effectifs, seuil] = await Promise.all([getReferentiels(supabase, false), getEffectifs(supabase), getSeuil(supabase)]);
  const actifs = (l: Referentiel[]) => l.filter((x) => x.actif).map((x) => x.libelle);
  const annees = ref.annees.map((a) => a.libelle);
  const annee = searchParams.annee && annees.includes(searchParams.annee) ? searchParams.annee : annees[annees.length - 1];
  const valeur = (f: string, n: string) => effectifs.find((e) => e.annee_academique === annee && e.filiere === f && e.niveau === n)?.effectif ?? '';

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-marque-900">Référentiels et paramètres</h1>
        <p className="text-sm text-slate-500">
          Modifiez ici les filières, niveaux et années proposés aux étudiants, sans intervenir dans le code. Un élément désactivé
          n&apos;est plus proposé, mais les réponses passées sont conservées.
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <ListeReferentiel titre="Filières" table="filieres" elements={ref.filieres} />
        <ListeReferentiel titre="Niveaux d'études" table="niveaux" elements={ref.niveaux} />
        <ListeReferentiel titre="Années académiques" table="annees_academiques" elements={ref.annees} />
      </div>

      <section className="carte">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="font-semibold">Effectifs de référence</h2>
            <p className="text-xs text-slate-500">Nombre d&apos;étudiants inscrits, utilisé pour calculer le taux de participation. Laisser vide si inconnu.</p>
          </div>
          <form className="flex items-end gap-2">
            <label className="text-xs font-medium text-slate-500">
              Année
              <select name="annee" defaultValue={annee} className="champ mt-1 py-2">
                {annees.map((a) => (
                  <option key={a}>{a}</option>
                ))}
              </select>
            </label>
            <button className="btn-secondaire btn-petit">Afficher</button>
          </form>
        </div>
        {annee && (
          <form action={enregistrerEffectifs} className="mt-4">
            <input type="hidden" name="annee" value={annee} />
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-xs uppercase text-slate-500">
                    <th className="py-2 pr-3">Filière</th>
                    {actifs(ref.niveaux).map((n) => (
                      <th key={n} className="px-2">{n}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {actifs(ref.filieres).map((f, i) => (
                    <tr key={f} className="border-b border-slate-100">
                      <td className="py-2 pr-3">{f}</td>
                      {actifs(ref.niveaux).map((n, j) => (
                        <td key={n} className="px-2 py-1">
                          {/* Les libellés (accentués) passent dans les valeurs, jamais dans les noms de champs. */}
                          <input type="hidden" name={`f_${i}_${j}`} value={f} />
                          <input type="hidden" name={`n_${i}_${j}`} value={n} />
                          <input name={`eff_${i}_${j}`} aria-label={`${f} – ${n}`} type="number" min={0} defaultValue={valeur(f, n)} className="champ w-24 py-1.5" />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <button className="btn-primaire btn-petit mt-4">Enregistrer les effectifs {annee}</button>
          </form>
        )}
      </section>

      <section className="carte max-w-xl">
        <h2 className="font-semibold">Seuil de confidentialité</h2>
        <p className="mt-1 text-xs text-slate-500">
          Les résultats et commentaires d&apos;un groupe comptant moins de réponses que ce seuil ne sont jamais affichés, afin
          qu&apos;aucun étudiant ne puisse être reconnu. Valeur recommandée : 5.
        </p>
        <form action={enregistrerSeuil} className="mt-3 flex items-center gap-2">
          <input name="seuil" type="number" min={1} max={50} defaultValue={seuil} className="champ w-24" />
          <button className="btn-primaire btn-petit">Enregistrer</button>
        </form>
      </section>
    </div>
  );
}

function ListeReferentiel({ titre, table, elements }: { titre: string; table: string; elements: Referentiel[] }) {
  return (
    <section className="carte">
      <h2 className="font-semibold">{titre}</h2>
      <ul className="mt-3 divide-y divide-slate-100">
        {elements.map((e) => (
          <li key={e.id} className="flex items-center gap-2 py-2">
            <span className={`flex-1 text-sm ${e.actif ? 'text-slate-800' : 'text-slate-400 line-through'}`}>{e.libelle}</span>
            {(['haut', 'bas'] as const).map((s) => (
              <form key={s} action={deplacerReferentiel}>
                <input type="hidden" name="table" value={table} />
                <input type="hidden" name="id" value={e.id} />
                <input type="hidden" name="sens" value={s} />
                <button className="rounded px-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label={s === 'haut' ? 'Monter' : 'Descendre'}>
                  {s === 'haut' ? '↑' : '↓'}
                </button>
              </form>
            ))}
            <form action={basculerReferentiel}>
              <input type="hidden" name="table" value={table} />
              <input type="hidden" name="id" value={e.id} />
              <input type="hidden" name="actif" value={String(!e.actif)} />
              <button className="text-xs text-marque-600 hover:underline">{e.actif ? 'Désactiver' : 'Réactiver'}</button>
            </form>
          </li>
        ))}
      </ul>
      <form action={ajouterReferentiel} className="mt-3 flex gap-2">
        <input type="hidden" name="table" value={table} />
        <input name="libelle" className="champ py-2" placeholder="Ajouter…" required minLength={2} />
        <button className="btn-secondaire btn-petit">Ajouter</button>
      </form>
    </section>
  );
}
