'use server';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/admin';

const TABLES = ['filieres', 'niveaux', 'annees_academiques'] as const;
type Table = (typeof TABLES)[number];
const table = (v: FormDataEntryValue | null): Table | null => (TABLES.includes(v as Table) ? (v as Table) : null);

export async function ajouterReferentiel(fd: FormData) {
  const { supabase } = await requireAdmin();
  const t = table(fd.get('table'));
  const libelle = String(fd.get('libelle') ?? '').trim();
  if (!t || libelle.length < 2) return;
  const { data } = await supabase.from(t).select('ordre').order('ordre', { ascending: false }).limit(1);
  await supabase.from(t).insert({ libelle, ordre: (data?.[0]?.ordre ?? 0) + 1 });
  revalidatePath('/admin/parametres');
}

export async function basculerReferentiel(fd: FormData) {
  const { supabase } = await requireAdmin();
  const t = table(fd.get('table'));
  if (!t) return;
  await supabase.from(t).update({ actif: fd.get('actif') === 'true' }).eq('id', Number(fd.get('id')));
  revalidatePath('/admin/parametres');
}

export async function deplacerReferentiel(fd: FormData) {
  const { supabase } = await requireAdmin();
  const t = table(fd.get('table'));
  if (!t) return;
  const { data } = await supabase.from(t).select('id, ordre').order('ordre').order('libelle');
  if (!data) return;
  const i = data.findIndex((r) => r.id === Number(fd.get('id')));
  const j = fd.get('sens') === 'haut' ? i - 1 : i + 1;
  if (i < 0 || j < 0 || j >= data.length) return;
  [data[i], data[j]] = [data[j], data[i]];
  await Promise.all(data.map((r, k) => supabase.from(t).update({ ordre: k + 1 }).eq('id', r.id)));
  revalidatePath('/admin/parametres');
}

export async function enregistrerEffectifs(fd: FormData) {
  const { supabase } = await requireAdmin();
  const annee = String(fd.get('annee') ?? '');
  if (!annee) return;
  const lignes: { annee_academique: string; filiere: string; niveau: string; effectif: number }[] = [];
  const aSupprimer: { filiere: string; niveau: string }[] = [];
  for (const [k, v] of fd.entries()) {
    if (!k.startsWith('eff_')) continue;
    const suffixe = k.slice(4);
    const filiere = String(fd.get(`f_${suffixe}`) ?? '');
    const niveau = String(fd.get(`n_${suffixe}`) ?? '');
    if (!filiere || !niveau) continue;
    const s = String(v).trim();
    if (s === '') aSupprimer.push({ filiere, niveau });
    else if (/^\d+$/.test(s)) lignes.push({ annee_academique: annee, filiere, niveau, effectif: Number(s) });
  }
  if (lignes.length) await supabase.from('effectifs').upsert(lignes, { onConflict: 'annee_academique,filiere,niveau' });
  for (const d of aSupprimer)
    await supabase.from('effectifs').delete().eq('annee_academique', annee).eq('filiere', d.filiere).eq('niveau', d.niveau);
  revalidatePath('/admin/parametres');
}

export async function enregistrerSeuil(fd: FormData) {
  const { supabase } = await requireAdmin();
  const seuil = Number(fd.get('seuil'));
  if (!Number.isInteger(seuil) || seuil < 1 || seuil > 50) return;
  await supabase.from('parametres').update({ seuil_confidentialite: seuil, updated_at: new Date().toISOString() }).eq('id', 1);
  revalidatePath('/admin/parametres');
  revalidatePath('/admin');
}
