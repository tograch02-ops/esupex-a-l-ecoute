import Image from 'next/image';
import FormulaireConnexion from './FormulaireConnexion';

export const metadata = { title: 'Connexion – Administration ESUPEX À L’ÉCOUTE' };

export default function Connexion({ searchParams }: { searchParams: { erreur?: string } }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-marque-900 px-4">
      <div className="w-full max-w-sm rounded-2xl bg-white p-8 shadow-xl">
        <Image src="/logo-esupex.svg" alt="ESUPEX" width={120} height={36} />
        <h1 className="mt-6 text-xl font-bold text-marque-900">Espace administration</h1>
        <p className="mt-1 text-sm text-slate-500">Observatoire de la satisfaction estudiantine</p>
        {searchParams.erreur === 'non-autorise' && (
          <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">
            Ce compte n&apos;est pas autorisé à accéder au tableau de bord. Contactez l&apos;administrateur principal.
          </p>
        )}
        <FormulaireConnexion />
      </div>
    </main>
  );
}
