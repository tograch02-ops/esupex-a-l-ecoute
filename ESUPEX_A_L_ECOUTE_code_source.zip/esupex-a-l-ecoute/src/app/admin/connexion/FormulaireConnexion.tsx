'use client';
import { useState } from 'react';
import { createBrowserSupabase } from '@/lib/supabase/browser';

export default function FormulaireConnexion() {
  const [email, setEmail] = useState('');
  const [motDePasse, setMotDePasse] = useState('');
  const [erreur, setErreur] = useState<string | null>(null);
  const [chargement, setChargement] = useState(false);

  async function connecter(e: React.FormEvent) {
    e.preventDefault();
    setChargement(true);
    setErreur(null);
    const sb = createBrowserSupabase();
    const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password: motDePasse });
    if (error) {
      setErreur('Identifiants incorrects.');
      setChargement(false);
      return;
    }
    window.location.href = '/admin';
  }

  return (
    <form onSubmit={connecter} className="mt-6 space-y-4">
      <div>
        <label className="etiquette" htmlFor="email">Adresse e-mail</label>
        <input id="email" type="email" required autoComplete="username" className="champ" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div>
        <label className="etiquette" htmlFor="mdp">Mot de passe</label>
        <input id="mdp" type="password" required autoComplete="current-password" className="champ" value={motDePasse} onChange={(e) => setMotDePasse(e.target.value)} />
      </div>
      {erreur && <p className="text-sm font-medium text-red-600">{erreur}</p>}
      <button type="submit" className="btn-primaire w-full" disabled={chargement}>
        {chargement ? 'Connexion…' : 'Se connecter'}
      </button>
    </form>
  );
}
