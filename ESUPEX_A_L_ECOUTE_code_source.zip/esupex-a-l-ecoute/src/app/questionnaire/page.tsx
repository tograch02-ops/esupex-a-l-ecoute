import { redirect } from 'next/navigation';
import { EnTete } from '@/components/EnTete';
import Questionnaire from '@/components/Questionnaire';
import { createAnonClient } from '@/lib/supabase/server';
import { getOpenCampaign, getReferentiels } from '@/lib/data';

export const dynamic = 'force-dynamic';

export default async function PageQuestionnaire() {
  const sb = createAnonClient();
  const campagne = await getOpenCampaign(sb);
  if (!campagne) redirect('/');
  const ref = await getReferentiels(sb);
  const annees = ref.annees.map((a) => a.libelle);
  const anneeParDefaut =
    campagne.annee_academique && annees.includes(campagne.annee_academique) ? campagne.annee_academique : null;

  return (
    <>
      <EnTete />
      <main className="mx-auto max-w-3xl px-4">
        <Questionnaire
          campagneId={campagne.id}
          campagneTitre={campagne.titre}
          questionnaire={campagne.questionnaire}
          filieres={ref.filieres.map((f) => f.libelle)}
          niveaux={ref.niveaux.map((n) => n.libelle)}
          annees={annees}
          anneeParDefaut={anneeParDefaut}
        />
      </main>
    </>
  );
}
