import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ESUPEX À L’ÉCOUTE – Observatoire de la satisfaction estudiantine',
  description: 'Consultation anonyme des étudiants de l’ESUPEX. Ton avis compte. Ensemble, améliorons notre école.',
  robots: { index: false, follow: false },
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#123d70' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="min-h-screen font-sans">{children}</body>
    </html>
  );
}
