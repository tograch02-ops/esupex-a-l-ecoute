import Link from 'next/link';
import { EnTete, PiedDePage } from '@/components/EnTete';
import { createAnonClient } from '@/lib/supabase/server';
import { getOpenCampaign } from '@/lib/data';

export const dynamic = 'force-dynamic';

export default async function Accueil() {
  let campagne = null;
  try {
    campagne = await getOpenCampaign(createAnonClient());
  } catch (e) {
    console.error('[accueil]', e);
    campagne = null;
  }

  return (
    <>
      <EnTete />
      <main className="mx-auto max-w-3xl px-4">
        <section className="py-10 sm:py-16">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-accent-600">
            Observatoire de la satisfaction estudiantine
          </p>
          <h1 className="text-4xl font-extrabold tracking-tight text-marque-900 sm:text-5xl">ESUPEX À L&apos;ÉCOUTE</h1>
          <p className="mt-3 text-lg font-medium text-marque-600">Ton avis compte pour améliorer ton école</p>

          <div className="mt-8 space-y-4 text-[15px] leading-relaxed text-slate-700">
            <p>
              Dans le cadre de sa démarche d&apos;amélioration continue, l&apos;ESUPEX souhaite recueillir les opinions,
              les préoccupations et les suggestions de ses étudiants.
            </p>
            <p>
              Cette consultation est <strong>entièrement anonyme</strong>. Tes réponses seront exploitées exclusivement à
              des fins d&apos;analyse statistique et d&apos;amélioration des services de l&apos;établissement.
            </p>
            <p>
              Exprime-toi librement. Chaque contribution compte pour construire une ESUPEX plus performante, plus
              attentive et davantage tournée vers la réussite de ses étudiants.
            </p>
          </div>

          <div className="mt-10">
            {campagne ? (
              <>
                <Link href="/questionnaire" className="btn-primaire w-full py-4 text-base sm:w-auto sm:px-10">
                  DONNER MON AVIS
                </Link>
                <p className="mt-3 text-sm text-slate-500">
                  {campagne.titre} · environ 5 à 8 minutes
                </p>
              </>
            ) : (
              <div className="carte border-accent-500/40 bg-accent-100/40">
                <p className="font-semibold text-slate-800">Aucune consultation n&apos;est ouverte pour le moment.</p>
                <p className="mt-1 text-sm text-slate-600">
                  La prochaine campagne sera annoncée par l&apos;administration de l&apos;ESUPEX.
                </p>
              </div>
            )}
          </div>
        </section>

        <section className="grid gap-4 pb-6 sm:grid-cols-3">
          {[
            ['Anonyme', 'Ni nom, ni téléphone, ni e-mail, ni adresse IP enregistrés.'],
            ['Rapide', 'Sept rubriques courtes, sur smartphone ou ordinateur.'],
            ['Utile', 'Les résultats orientent les actions prioritaires de la direction.'],
          ].map(([t, d]) => (
            <div key={t} className="carte">
              <p className="font-semibold text-marque-700">{t}</p>
              <p className="mt-1 text-sm text-slate-600">{d}</p>
            </div>
          ))}
        </section>
      </main>
      <PiedDePage />
    </>
  );
}
