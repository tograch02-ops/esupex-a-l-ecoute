import Link from 'next/link';
import { EnTete, PiedDePage } from '@/components/EnTete';

export default function Merci() {
  return (
    <>
      <EnTete />
      <main className="mx-auto max-w-3xl px-4 py-16 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-3xl text-emerald-700">
          ✓
        </div>
        <h1 className="mt-6 text-3xl font-bold text-marque-900">Merci pour ta participation !</h1>
        <p className="mx-auto mt-4 max-w-xl text-slate-600">
          Ton avis a bien été enregistré, de manière anonyme. Il sera analysé avec ceux de l&apos;ensemble des étudiants
          afin d&apos;aider la direction de l&apos;ESUPEX à définir ses actions d&apos;amélioration prioritaires.
        </p>
        <p className="mt-6 font-semibold text-marque-700">Ensemble, améliorons notre école.</p>
        <Link href="/" className="btn-secondaire mt-10">
          Retour à l&apos;accueil
        </Link>
      </main>
      <PiedDePage />
    </>
  );
}
