import Link from 'next/link';
export default function NotFound() {
  return (
    <main className="mx-auto max-w-md px-4 py-24 text-center">
      <h1 className="text-2xl font-bold text-marque-900">Page introuvable</h1>
      <Link href="/" className="btn-secondaire mt-6">Retour à l&apos;accueil</Link>
    </main>
  );
}
