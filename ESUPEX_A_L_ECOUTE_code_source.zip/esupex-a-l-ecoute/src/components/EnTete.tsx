import Image from 'next/image';
import Link from 'next/link';

export function EnTete() {
  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 py-3">
        <Link href="/" className="flex items-center gap-3">
          <Image src="/logo-esupex.svg" alt="ESUPEX" width={120} height={36} priority />
        </Link>
        <span className="text-right text-xs font-semibold uppercase tracking-wider text-marque-700">
          ESUPEX à l&apos;écoute
        </span>
      </div>
    </header>
  );
}

export function PiedDePage() {
  return (
    <footer className="mx-auto max-w-3xl px-4 py-8 text-center text-xs text-slate-500">
      Ton avis compte. Ensemble, améliorons notre école.
      <br />
      Consultation anonyme · aucune donnée d&apos;identification collectée · aucun traceur publicitaire
    </footer>
  );
}
