'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const LIENS = [
  ['/admin', 'Tableau de bord'],
  ['/admin/commentaires', 'Commentaires'],
  ['/admin/campagnes', 'Campagnes'],
  ['/admin/parametres', 'Référentiels et paramètres'],
] as const;

export function NavAdmin() {
  const path = usePathname();
  return (
    <nav className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4">
      {LIENS.map(([href, lib]) => {
        const actif = href === '/admin' ? path === '/admin' : path.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            className={`whitespace-nowrap rounded-t-lg px-4 py-2.5 text-sm font-medium ${
              actif ? 'bg-slate-100 text-marque-900' : 'text-marque-100 hover:bg-white/10'
            }`}
          >
            {lib}
          </Link>
        );
      })}
    </nav>
  );
}
