'use client';
import { useState } from 'react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import type { Commentaire, ResultatThemes } from '@/lib/themes';

type SyntheseIA = { themes: { titre: string; resume: string; refs: string[] }[] };

export default function AnalyseCommentaires({
  resultat,
  questions,
  questionId,
  syntheseQuery,
  iaDisponible,
}: {
  resultat: ResultatThemes;
  questions: { id: string; label: string }[];
  questionId: string;
  syntheseQuery: string;
  iaDisponible: boolean;
}) {
  const router = useRouter();
  const path = usePathname();
  const sp = useSearchParams();
  const [ouvert, setOuvert] = useState<string | null>(null);
  const [recherche, setRecherche] = useState('');
  const [ia, setIa] = useState<SyntheseIA | null>(null);
  const [iaEtat, setIaEtat] = useState<'repos' | 'encours' | 'erreur'>('repos');
  const [iaErreur, setIaErreur] = useState('');

  const parRef = new Map<string, Commentaire>();
  resultat.themes.forEach((t) => t.commentaires.forEach((c) => parRef.set(c.ref, c)));
  resultat.nonClasses.forEach((c) => parRef.set(c.ref, c));
  const tous = [...parRef.values()];
  const filtres = recherche.trim()
    ? tous.filter((c) => c.texte.toLowerCase().includes(recherche.trim().toLowerCase()))
    : [];

  function choisirQuestion(id: string) {
    const p = new URLSearchParams(sp.toString());
    if (id) p.set('question', id);
    else p.delete('question');
    router.push(`${path}?${p.toString()}`);
  }

  async function lancerIA() {
    setIaEtat('encours');
    setIaErreur('');
    try {
      const r = await fetch(`/api/admin/synthese?${syntheseQuery}`, { method: 'POST' });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Erreur');
      setIa(d);
      setIaEtat('repos');
    } catch (e) {
      setIaErreur(e instanceof Error ? e.message : 'Erreur');
      setIaEtat('erreur');
    }
  }

  return (
    <div className="space-y-5">
      <div className="carte flex flex-wrap items-end gap-3">
        <label className="flex min-w-[260px] flex-[2] flex-col text-xs font-medium text-slate-500">
          Question ouverte
          <select className="champ mt-1 py-2" value={questionId} onChange={(e) => choisirQuestion(e.target.value)}>
            <option value="">Toutes les questions ouvertes</option>
            {questions.map((q) => (
              <option key={q.id} value={q.id}>
                {q.label}
              </option>
            ))}
          </select>
        </label>
        <label className="flex min-w-[200px] flex-1 flex-col text-xs font-medium text-slate-500">
          Rechercher un mot
          <input className="champ mt-1 py-2" placeholder="ex. : wifi, toilettes…" value={recherche} onChange={(e) => setRecherche(e.target.value)} />
        </label>
      </div>

      {recherche.trim() && (
        <div className="carte">
          <h2 className="font-semibold">
            {filtres.length} commentaire(s) contenant « {recherche.trim()} »
          </h2>
          <ListeCommentaires commentaires={filtres} />
        </div>
      )}

      <div className="grid gap-5 lg:grid-cols-[1fr_380px]">
        <div className="carte">
          <h2 className="font-semibold text-slate-900">Thèmes récurrents</h2>
          <p className="mt-0.5 text-xs text-slate-500">
            {resultat.total} commentaire(s) analysé(s) · un commentaire peut relever de plusieurs thèmes · classement par
            fréquence
          </p>
          {resultat.total === 0 ? (
            <p className="py-8 text-center text-sm text-slate-400">Aucun commentaire pour cette sélection.</p>
          ) : (
            <ul className="mt-4 divide-y divide-slate-100">
              {resultat.themes.map((t) => (
                <li key={t.id}>
                  <button className="flex w-full items-center gap-3 py-3 text-left" onClick={() => setOuvert(ouvert === t.id ? null : t.id)}>
                    <span className="flex-1 text-sm font-medium text-slate-800">{t.libelle}</span>
                    <span className="w-28">
                      <span className="block h-2 rounded-full bg-slate-100">
                        <span className="block h-2 rounded-full bg-[#2a78d6]" style={{ width: `${(t.n / resultat.themes[0].n) * 100}%` }} />
                      </span>
                    </span>
                    <span className="w-10 text-right text-sm font-semibold tabular-nums">{t.n}</span>
                    <span className="text-slate-400">{ouvert === t.id ? '▾' : '▸'}</span>
                  </button>
                  {ouvert === t.id && <ListeCommentaires commentaires={t.commentaires} />}
                </li>
              ))}
              {resultat.nonClasses.length > 0 && (
                <li>
                  <button className="flex w-full items-center gap-3 py-3 text-left" onClick={() => setOuvert(ouvert === '_nc' ? null : '_nc')}>
                    <span className="flex-1 text-sm italic text-slate-600">Autres commentaires (non classés)</span>
                    <span className="w-10 text-right text-sm font-semibold tabular-nums">{resultat.nonClasses.length}</span>
                    <span className="text-slate-400">{ouvert === '_nc' ? '▾' : '▸'}</span>
                  </button>
                  {ouvert === '_nc' && <ListeCommentaires commentaires={resultat.nonClasses} />}
                </li>
              )}
            </ul>
          )}
        </div>

        <div className="carte h-fit">
          <h2 className="font-semibold text-slate-900">Synthèse assistée par IA</h2>
          <p className="mt-1 text-xs text-slate-500">
            L&apos;IA regroupe les commentaires et en résume les idées principales. Chaque thème cite les références des
            commentaires d&apos;origine : cliquez pour les vérifier. L&apos;IA ne doit jamais inventer d&apos;opinion.
          </p>
          {!iaDisponible ? (
            <p className="mt-4 rounded-lg bg-slate-50 p-3 text-xs text-slate-600">
              Fonction non activée. Pour l&apos;activer, renseignez la variable ANTHROPIC_API_KEY dans Vercel (voir le guide de
              déploiement). L&apos;analyse par thèmes ci-contre fonctionne sans IA.
            </p>
          ) : (
            <>
              <button className="btn-primaire btn-petit mt-4 w-full" disabled={iaEtat === 'encours' || resultat.total === 0} onClick={lancerIA}>
                {iaEtat === 'encours' ? 'Analyse en cours… (jusqu’à 1 min)' : 'Générer la synthèse'}
              </button>
              {iaEtat === 'erreur' && <p className="mt-2 text-xs text-red-600">{iaErreur}</p>}
              {ia && (
                <div className="mt-4 space-y-4">
                  {ia.themes.map((t, k) => (
                    <div key={k} className="rounded-lg border border-slate-200 p-3">
                      <p className="text-sm font-semibold text-slate-900">{t.titre}</p>
                      <p className="mt-1 text-sm text-slate-700">{t.resume}</p>
                      <details className="mt-2">
                        <summary className="cursor-pointer text-xs font-medium text-marque-600">
                          Voir les {t.refs.length} commentaire(s) source
                        </summary>
                        <ListeCommentaires commentaires={t.refs.map((r) => parRef.get(r)).filter((c): c is Commentaire => Boolean(c))} />
                      </details>
                    </div>
                  ))}
                  <p className="text-[11px] text-slate-400">Synthèse générée automatiquement — à vérifier à partir des commentaires sources.</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function ListeCommentaires({ commentaires }: { commentaires: Commentaire[] }) {
  return (
    <ul className="mb-3 mt-2 max-h-[420px] space-y-2 overflow-y-auto pr-1">
      {commentaires.map((c) => (
        <li key={c.ref} className="rounded-lg bg-slate-50 p-3">
          <p className="whitespace-pre-line text-sm text-slate-800">« {c.texte} »</p>
          <p className="mt-1 text-[11px] text-slate-400">
            {c.ref} · {c.question}
          </p>
        </li>
      ))}
    </ul>
  );
}
