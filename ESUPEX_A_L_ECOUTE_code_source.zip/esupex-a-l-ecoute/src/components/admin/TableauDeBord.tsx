'use client';

import { useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { Comptage, ScoresGroupe, StatItem, Statistiques } from '@/lib/stats';
import { DIMENSION_LIBELLES } from '@/lib/questionnaire';

// Couleurs de données : une teinte pour les grandeurs ; une paire divergente
// (rouge ↔ bleu, milieu gris neutre) pour l'échelle de satisfaction 1 à 5.
const SERIE = '#2a78d6';
const DIVERGENT = ['#c2452d', '#e8a08f', '#b9b8b3', '#8fb6e6', '#2a78d6'];

export type Evolution = { titre: string; statut: string; n: number; satisfactionGlobale: number | null; pedagogie: number | null; administration: number | null; infrastructures: number | null; noteGlobale: number | null };

type Props = {
  stats: Statistiques;
  campagneTitre: string;
  filtresTexte: string;
  ameliorations: { libelle: string; n: number }[];
  evolution: Evolution[];
  exportQuery: string;
  likertLabels: string[];
};

const f = (x: number | null | undefined, d = 2) => (x === null || x === undefined ? '—' : x.toLocaleString('fr-FR', { maximumFractionDigits: d, minimumFractionDigits: d === 2 ? 2 : 0 }));
const fp = (x: number | null | undefined) => (x === null || x === undefined ? '—' : `${x.toLocaleString('fr-FR', { maximumFractionDigits: 1 })} %`);

export default function TableauDeBord({ stats, campagneTitre, filtresTexte, ameliorations, evolution, exportQuery, likertLabels }: Props) {
  const [pdfEnCours, setPdfEnCours] = useState(false);
  const i = stats.indicateurs;

  async function exporterPdf() {
    setPdfEnCours(true);
    try {
      const { genererRapportPdf } = await import('@/lib/rapport-pdf');
      await genererRapportPdf({ stats, campagneTitre, filtresTexte, ameliorations, evolution, likertLabels });
    } finally {
      setPdfEnCours(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Exports */}
      <div className="flex flex-wrap gap-2 print:hidden">
        <a className="btn-secondaire btn-petit" href={`/api/admin/export?format=xlsx&${exportQuery}`}>
          ⬇ Export Excel
        </a>
        <a className="btn-secondaire btn-petit" href={`/api/admin/export?format=csv&${exportQuery}`}>
          ⬇ Export CSV
        </a>
        <button className="btn-primaire btn-petit" onClick={exporterPdf} disabled={pdfEnCours || stats.masque}>
          {pdfEnCours ? 'Génération…' : '⬇ Rapport PDF'}
        </button>
      </div>

      {/* A. Indicateurs généraux + B. Satisfaction */}
      <section className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-6">
        <Tuile titre="Participants" valeur={stats.total.toLocaleString('fr-FR')} detail={stats.participation.taux !== null ? `Taux de participation : ${fp(stats.participation.taux)}` : 'Effectifs de référence non renseignés'} />
        <Tuile titre="Satisfaction générale" valeur={f(i.satisfactionGlobale)} unite="/ 5" />
        <Tuile titre="Étudiants satisfaits" valeur={fp(i.pctSatisfaits)} detail="notes 4 et 5" />
        <Tuile titre="Étudiants insatisfaits" valeur={fp(i.pctInsatisfaits)} detail="notes 1 et 2" />
        <Tuile titre="Note globale" valeur={f(i.noteGlobale, 1)} unite="/ 10" />
        <Tuile titre="Moyennement satisfaits" valeur={fp(i.pctMoyennementSatisfaits)} detail="note 3" />
      </section>

      {stats.masque ? (
        <div className="carte border-accent-500/50 bg-accent-100/40">
          <p className="font-semibold text-slate-800">Résultats masqués pour protéger l&apos;anonymat</p>
          <p className="mt-1 text-sm text-slate-600">
            Cette sélection compte {stats.total} réponse(s), soit moins que le seuil de confidentialité ({stats.seuil}). Élargissez les filtres
            ou attendez davantage de participations.
          </p>
        </div>
      ) : (
        <>
          <section className="grid gap-3 md:grid-cols-4">
            {(['generale', 'pedagogie', 'administration', 'infrastructures'] as const).map((d) => (
              <Jauge key={d} titre={DIMENSION_LIBELLES[d]} valeur={i[d]} />
            ))}
          </section>

          {/* D. Priorités */}
          <section className="grid gap-4 lg:grid-cols-2">
            <Carte titre="Domaines d'intervention prioritaire" sousTitre="Les 5 éléments les moins bien évalués : actions à engager en priorité">
              <ListePriorites items={stats.priorites.moinsBienEvalues} sens="bas" />
            </Carte>
            <Carte titre="Points forts" sousTitre="Les 5 éléments les mieux évalués">
              <ListePriorites items={stats.priorites.mieuxEvalues} sens="haut" />
            </Carte>
          </section>

          <section className="grid gap-4 lg:grid-cols-2">
            <Carte titre="Principales difficultés signalées" sousTitre="% des répondants (plusieurs réponses possibles)">
              <BarresHorizontales donnees={stats.difficultes.categories} pourcent />
            </Carte>
            <Carte titre="Améliorations les plus demandées" sousTitre="Thèmes détectés dans « trois améliorations prioritaires » (nombre de mentions)">
              {ameliorations.length ? (
                <BarresHorizontales donnees={ameliorations.map((a) => ({ libelle: a.libelle, n: a.n, pct: 0 }))} />
              ) : (
                <Vide texte="Aucune proposition analysable pour le moment." />
              )}
            </Carte>
          </section>

          <section className="grid gap-4 lg:grid-cols-3">
            <Carte titre="Difficulté la plus pénalisante">
              <BarresHorizontales donnees={stats.difficultes.principale} pourcent />
            </Carte>
            <Carte titre="Ancienneté de la difficulté">
              <BarresHorizontales donnees={stats.difficultes.duree} pourcent />
            </Carte>
            <Carte titre="Impact sur le parcours académique">
              <BarresHorizontales donnees={stats.difficultes.perturbation} pourcent />
            </Carte>
          </section>

          {/* Détail par item */}
          <Carte titre="Détail des appréciations par élément" sousTitre="Moyenne sur 5 et répartition des réponses (« non concerné » exclu)">
            <LegendeLikert labels={likertLabels} />
            <TableItems items={stats.items} />
          </Carte>

          {/* C. Comparaisons */}
          <Carte titre="Comparaison entre filières" sousTitre={`Scores moyens sur 5 · groupes de moins de ${stats.seuil} réponses masqués`}>
            <TableComparaison lignes={stats.comparaisons.filiere} />
          </Carte>
          <section className="grid gap-4 lg:grid-cols-2">
            <Carte titre="Comparaison entre niveaux">
              <TableComparaison lignes={stats.comparaisons.niveau} compact />
            </Carte>
            <Carte titre="Comparaison entre années académiques">
              <TableComparaison lignes={stats.comparaisons.annee} compact />
            </Carte>
          </section>

          <Carte titre="Répartition de la note globale (0 à 10)">
            <div className="h-56">
              <ResponsiveContainer>
                <BarChart data={i.distributionNote.map((n, k) => ({ note: String(k), n }))} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="#e7e5e4" />
                  <XAxis dataKey="note" tickLine={false} axisLine={{ stroke: '#d6d3d1' }} fontSize={12} />
                  <YAxis allowDecimals={false} tickLine={false} axisLine={false} fontSize={12} />
                  <Tooltip cursor={{ fill: '#f1f5f9' }} formatter={(v: number) => [`${v} étudiant(s)`, 'Effectif']} labelFormatter={(l) => `Note ${l} / 10`} />
                  <Bar dataKey="n" fill={SERIE} radius={[4, 4, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Carte>
        </>
      )}

      {/* A. Répartition des participants */}
      <section className="grid gap-4 lg:grid-cols-3">
        <Carte titre="Participants par filière">
          <TableParticipation parFiliere={stats.participation.parFiliere} />
        </Carte>
        <Carte titre="Participants par niveau">
          <BarresHorizontales donnees={stats.repartition.niveau} effectif />
        </Carte>
        <Carte titre="Participants par année académique">
          <BarresHorizontales donnees={stats.repartition.annee} effectif />
        </Carte>
      </section>

      {evolution.length > 1 && (
        <Carte titre="Évolution entre campagnes" sousTitre="Baromètre : indicateurs comparables d'une campagne à l'autre">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-xs uppercase text-slate-500">
                  <th className="py-2 pr-3">Campagne</th>
                  <th className="px-2 text-right">Réponses</th>
                  <th className="px-2 text-right">Satisf. générale</th>
                  <th className="px-2 text-right">Pédagogie</th>
                  <th className="px-2 text-right">Administration</th>
                  <th className="px-2 text-right">Infrastructures</th>
                  <th className="px-2 text-right">Note /10</th>
                </tr>
              </thead>
              <tbody>
                {evolution.map((e) => (
                  <tr key={e.titre} className="border-b last:border-0">
                    <td className="py-2 pr-3 font-medium">{e.titre}</td>
                    <td className="px-2 text-right tabular-nums">{e.n}</td>
                    {[e.satisfactionGlobale, e.pedagogie, e.administration, e.infrastructures].map((v, k) => (
                      <td key={k} className="px-2 text-right tabular-nums">{f(v)}</td>
                    ))}
                    <td className="px-2 text-right tabular-nums">{f(e.noteGlobale, 1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Carte>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------

function Tuile({ titre, valeur, unite, detail }: { titre: string; valeur: string; unite?: string; detail?: string }) {
  return (
    <div className="carte p-4">
      <p className="text-xs font-medium text-slate-500">{titre}</p>
      <p className="mt-1 text-2xl font-bold tabular-nums text-slate-900">
        {valeur}
        {unite && valeur !== '—' && <span className="ml-1 text-sm font-medium text-slate-500">{unite}</span>}
      </p>
      {detail && <p className="mt-0.5 text-[11px] text-slate-500">{detail}</p>}
    </div>
  );
}

function Jauge({ titre, valeur }: { titre: string; valeur: number | null }) {
  const pctLargeur = valeur === null ? 0 : ((valeur - 1) / 4) * 100;
  return (
    <div className="carte p-4">
      <p className="text-xs font-medium text-slate-500">{titre}</p>
      <p className="mt-1 text-xl font-bold tabular-nums text-slate-900">
        {f(valeur)} <span className="text-sm font-medium text-slate-500">/ 5</span>
      </p>
      <div className="mt-2 h-2 rounded-full bg-slate-100">
        <div className="h-2 rounded-full" style={{ width: `${pctLargeur}%`, background: SERIE }} />
      </div>
    </div>
  );
}

function Carte({ titre, sousTitre, children }: { titre: string; sousTitre?: string; children: React.ReactNode }) {
  return (
    <section className="carte">
      <h2 className="font-semibold text-slate-900">{titre}</h2>
      {sousTitre && <p className="mt-0.5 text-xs text-slate-500">{sousTitre}</p>}
      <div className="mt-4">{children}</div>
    </section>
  );
}

function Vide({ texte }: { texte: string }) {
  return <p className="py-6 text-center text-sm text-slate-400">{texte}</p>;
}

function ListePriorites({ items, sens }: { items: StatItem[]; sens: 'haut' | 'bas' }) {
  if (!items.length) return <Vide texte="Pas encore assez de réponses." />;
  return (
    <ol className="space-y-2">
      {items.map((it, k) => (
        <li key={it.id} className="flex items-center gap-3 rounded-lg bg-slate-50 px-3 py-2">
          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white text-xs font-bold text-slate-600 ring-1 ring-slate-200">{k + 1}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-slate-800" title={it.label}>{it.label}</p>
            <p className="text-[11px] text-slate-500">{DIMENSION_LIBELLES[it.dimension]}</p>
          </div>
          <div className="text-right">
            <p className="text-sm font-bold tabular-nums text-slate-900">{f(it.moyenne)}</p>
            <p className="text-[11px] tabular-nums text-slate-500">
              {sens === 'bas' ? `${fp(it.pctInsatisfaits)} insatisfaits` : `${fp(it.pctSatisfaits)} satisfaits`}
            </p>
          </div>
        </li>
      ))}
    </ol>
  );
}

function BarresHorizontales({ donnees, pourcent, effectif }: { donnees: Comptage[]; pourcent?: boolean; effectif?: boolean }) {
  if (!donnees.length) return <Vide texte="Aucune donnée." />;
  const max = Math.max(...donnees.map((d) => (pourcent ? d.pct : d.n)), 1);
  return (
    <ul className="space-y-2.5">
      {donnees.map((d) => {
        const v = pourcent ? d.pct : d.n;
        return (
          <li key={d.libelle} className="group" title={`${d.libelle} : ${d.n} (${fp(d.pct)})`}>
            <div className="flex justify-between gap-3 text-xs">
              <span className="text-slate-700">{d.libelle}</span>
              <span className="shrink-0 font-semibold tabular-nums text-slate-900">
                {pourcent ? fp(d.pct) : d.n}
                {effectif && <span className="ml-1 font-normal text-slate-500">({fp(d.pct)})</span>}
                {pourcent && <span className="ml-1 font-normal text-slate-500">({d.n})</span>}
              </span>
            </div>
            <div className="mt-1 h-2 rounded-full bg-slate-100">
              <div className="h-2 rounded-full transition-opacity group-hover:opacity-80" style={{ width: `${(v / max) * 100}%`, background: SERIE }} />
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function LegendeLikert({ labels }: { labels: string[] }) {
  return (
    <div className="mb-3 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-600">
      {labels.map((l, k) => (
        <span key={l} className="inline-flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: DIVERGENT[k] }} />
          {k + 1} – {l}
        </span>
      ))}
    </div>
  );
}

function TableItems({ items }: { items: StatItem[] }) {
  const dims = [...new Set(items.map((i) => i.dimension))];
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[640px] text-sm">
        <thead>
          <tr className="border-b text-left text-xs uppercase text-slate-500">
            <th className="py-2 pr-3">Élément évalué</th>
            <th className="px-2 text-right">Moy.</th>
            <th className="w-[38%] px-2">Répartition</th>
            <th className="px-2 text-right">Satisf.</th>
            <th className="px-2 text-right">N</th>
            <th className="px-2 text-right">N.C.</th>
          </tr>
        </thead>
        <tbody>
          {dims.map((d) => (
            <FragmentDim key={d} titre={DIMENSION_LIBELLES[d]} items={items.filter((i) => i.dimension === d)} />
          ))}
        </tbody>
      </table>
    </div>
  );
}

function FragmentDim({ titre, items }: { titre: string; items: StatItem[] }) {
  return (
    <>
      <tr>
        <td colSpan={6} className="pb-1 pt-4 text-xs font-semibold uppercase tracking-wide text-marque-700">{titre}</td>
      </tr>
      {items.map((it) => (
        <tr key={it.id} className="border-b border-slate-100">
          <td className="py-2 pr-3 text-slate-700">{it.label}</td>
          <td className="px-2 text-right font-semibold tabular-nums">{f(it.moyenne)}</td>
          <td className="px-2">
            <div className="flex h-3 gap-[2px] overflow-hidden rounded">
              {it.distribution.map((n, k) =>
                n > 0 ? (
                  <div
                    key={k}
                    style={{ flexGrow: n, background: DIVERGENT[k] }}
                    title={`Note ${k + 1} : ${n} réponse(s) (${fp(it.n ? Math.round((1000 * n) / it.n) / 10 : 0)})`}
                  />
                ) : null,
              )}
            </div>
          </td>
          <td className="px-2 text-right tabular-nums">{fp(it.pctSatisfaits)}</td>
          <td className="px-2 text-right tabular-nums text-slate-500">{it.n}</td>
          <td className="px-2 text-right tabular-nums text-slate-400">{it.nNA || ''}</td>
        </tr>
      ))}
    </>
  );
}

function Cellule({ v, d = 2 }: { v: number | null; d?: number }) {
  // Fond séquentiel discret (une seule teinte) : plus la note est haute, plus le fond est soutenu.
  const t = v === null ? 0 : d === 2 ? (v - 1) / 4 : v / 10;
  return (
    <td className="px-2 py-2 text-right tabular-nums" style={{ background: v === null ? undefined : `rgba(42,120,214,${0.06 + 0.3 * t})` }}>
      {f(v, d === 2 ? 2 : 1)}
    </td>
  );
}

function TableComparaison({ lignes, compact }: { lignes: ScoresGroupe[]; compact?: boolean }) {
  if (!lignes.length) return <Vide texte="Aucune donnée." />;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b text-left text-xs uppercase text-slate-500">
            <th className="py-2 pr-3">Groupe</th>
            <th className="px-2 text-right">N</th>
            <th className="px-2 text-right">Satisf. générale</th>
            {!compact && <th className="px-2 text-right">% satisfaits</th>}
            <th className="px-2 text-right">Pédagogie</th>
            <th className="px-2 text-right">Admin.</th>
            <th className="px-2 text-right">Infra.</th>
            {!compact && <th className="px-2 text-right">Note /10</th>}
          </tr>
        </thead>
        <tbody>
          {lignes.map((l) => (
            <tr key={l.groupe} className="border-b border-slate-100">
              <td className="py-2 pr-3 font-medium text-slate-700">{l.groupe}</td>
              <td className="px-2 text-right tabular-nums text-slate-500">{l.n}</td>
              {l.masque ? (
                <td colSpan={compact ? 4 : 6} className="px-2 text-center text-xs italic text-slate-400">
                  Effectif insuffisant – masqué pour préserver l&apos;anonymat
                </td>
              ) : (
                <>
                  <Cellule v={l.satisfactionGlobale} />
                  {!compact && <td className="px-2 text-right tabular-nums">{fp(l.pctSatisfaits)}</td>}
                  <Cellule v={l.pedagogie} />
                  <Cellule v={l.administration} />
                  <Cellule v={l.infrastructures} />
                  {!compact && <Cellule v={l.noteGlobale} d={1} />}
                </>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TableParticipation({ parFiliere }: { parFiliere: Statistiques['participation']['parFiliere'] }) {
  if (!parFiliere.length) return <Vide texte="Aucune participation." />;
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b text-left text-xs uppercase text-slate-500">
          <th className="py-2 pr-2">Filière</th>
          <th className="px-2 text-right">Rép.</th>
          <th className="px-2 text-right">Effectif</th>
          <th className="pl-2 text-right">Taux</th>
        </tr>
      </thead>
      <tbody>
        {parFiliere.map((p) => (
          <tr key={p.filiere} className="border-b border-slate-100">
            <td className="py-2 pr-2 text-slate-700">{p.filiere}</td>
            <td className="px-2 text-right tabular-nums">{p.n}</td>
            <td className="px-2 text-right tabular-nums text-slate-500">{p.effectif ?? '—'}</td>
            <td className="pl-2 text-right tabular-nums">{fp(p.taux)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
