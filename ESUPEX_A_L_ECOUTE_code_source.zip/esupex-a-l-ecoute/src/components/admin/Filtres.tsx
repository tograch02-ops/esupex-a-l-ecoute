'use client';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';

type Props = {
  campagnes: { id: string; titre: string; statut: string }[];
  campagneId: string;
  filieres: string[];
  niveaux: string[];
  annees: string[];
};

const STATUTS: Record<string, string> = { ouverte: 'ouverte', cloturee: 'clôturée', brouillon: 'brouillon' };

/** Barre de filtres unique, au-dessus des graphiques ; l'état est porté par l'URL. */
export function Filtres({ campagnes, campagneId, filieres, niveaux, annees }: Props) {
  const router = useRouter();
  const path = usePathname();
  const sp = useSearchParams();

  function maj(cle: string, valeur: string) {
    const p = new URLSearchParams(sp.toString());
    if (valeur) p.set(cle, valeur);
    else p.delete(cle);
    router.push(`${path}?${p.toString()}`);
  }

  const Select = ({ cle, label, options, valeur, tous }: { cle: string; label: string; options: [string, string][]; valeur: string; tous?: string }) => (
    <label className="flex min-w-[160px] flex-1 flex-col text-xs font-medium text-slate-500">
      {label}
      <select className="champ mt-1 py-2" value={valeur} onChange={(e) => maj(cle, e.target.value)}>
        {tous && <option value="">{tous}</option>}
        {options.map(([v, l]) => (
          <option key={v} value={v}>
            {l}
          </option>
        ))}
      </select>
    </label>
  );

  const actifs = ['filiere', 'niveau', 'annee'].some((k) => sp.get(k));
  return (
    <div className="carte flex flex-wrap items-end gap-3 print:hidden">
      <Select
        cle="campagne"
        label="Campagne"
        valeur={campagneId}
        options={campagnes.map((c) => [c.id, `${c.titre} (${STATUTS[c.statut] ?? c.statut})`])}
      />
      <Select cle="filiere" label="Filière" valeur={sp.get('filiere') ?? ''} tous="Toutes les filières" options={filieres.map((f) => [f, f])} />
      <Select cle="niveau" label="Niveau" valeur={sp.get('niveau') ?? ''} tous="Tous les niveaux" options={niveaux.map((f) => [f, f])} />
      <Select cle="annee" label="Année académique" valeur={sp.get('annee') ?? ''} tous="Toutes les années" options={annees.map((f) => [f, f])} />
      {actifs && (
        <button
          className="btn-secondaire py-2"
          onClick={() => router.push(`${path}?campagne=${campagneId}`)}
        >
          Réinitialiser
        </button>
      )}
    </div>
  );
}
