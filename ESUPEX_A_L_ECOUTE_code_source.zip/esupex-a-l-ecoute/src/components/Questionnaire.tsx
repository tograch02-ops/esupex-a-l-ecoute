'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  isVisible,
  validateSection,
  type Answers,
  type AnswerValue,
  type Question,
  type Questionnaire as QuestionnaireDef,
  type Section,
} from '@/lib/questionnaire';

type Props = {
  campagneId: string;
  campagneTitre: string;
  questionnaire: QuestionnaireDef;
  filieres: string[];
  niveaux: string[];
  annees: string[];
  anneeParDefaut: string | null;
};

type Profil = { filiere: string; niveau: string; annee: string };

const cleBrouillon = (id: string) => `esupex-brouillon-${id}`;
const cleParticipation = (id: string) => `esupex-participation-${id}`;

function lireStockage(store: 'local' | 'session', key: string): string | null {
  try {
    return (store === 'local' ? window.localStorage : window.sessionStorage).getItem(key);
  } catch {
    return null;
  }
}
function ecrireStockage(store: 'local' | 'session', key: string, value: string | null) {
  try {
    const s = store === 'local' ? window.localStorage : window.sessionStorage;
    if (value === null) s.removeItem(key);
    else s.setItem(key, value);
  } catch {
    /* stockage indisponible : sans conséquence */
  }
}

export default function Questionnaire(props: Props) {
  const { questionnaire: q, campagneId } = props;
  const router = useRouter();
  const sections = q.sections;
  // Étapes : 0 = profil, 1..n = sections, n+1 = récapitulatif / confirmation
  const totalEtapes = sections.length + 2;
  const [etape, setEtape] = useState(0);
  const [profil, setProfil] = useState<Profil>({ filiere: '', niveau: '', annee: props.anneeParDefaut ?? '' });
  const [answers, setAnswers] = useState<Answers>({});
  const [erreurs, setErreurs] = useState<Record<string, string>>({});
  const [envoi, setEnvoi] = useState(false);
  const [erreurEnvoi, setErreurEnvoi] = useState<string | null>(null);
  const [dejaParticipe, setDejaParticipe] = useState(false);
  const [pret, setPret] = useState(false);
  const honeypot = useRef<HTMLInputElement>(null);
  const haut = useRef<HTMLDivElement>(null);

  // Restauration du brouillon (stocké uniquement sur cet appareil, effacé à la fermeture de l'onglet).
  useEffect(() => {
    if (lireStockage('local', cleParticipation(campagneId))) setDejaParticipe(true);
    const brouillon = lireStockage('session', cleBrouillon(campagneId));
    if (brouillon) {
      try {
        const b = JSON.parse(brouillon);
        if (b.profil) setProfil(b.profil);
        if (b.answers) setAnswers(b.answers);
        if (typeof b.etape === 'number') setEtape(Math.min(b.etape, totalEtapes - 1));
      } catch {
        /* brouillon illisible : ignoré */
      }
    }
    setPret(true);
  }, [campagneId, totalEtapes]);

  useEffect(() => {
    if (!pret) return;
    ecrireStockage('session', cleBrouillon(campagneId), JSON.stringify({ profil, answers, etape }));
  }, [pret, profil, answers, etape, campagneId]);

  const progression = Math.round((etape / (totalEtapes - 1)) * 100);

  function setAnswer(id: string, v: AnswerValue) {
    setAnswers((a) => ({ ...a, [id]: v }));
    setErreurs((e) => {
      if (!e[id]) return e;
      const { [id]: _, ...rest } = e;
      return rest;
    });
  }

  function allerA(n: number) {
    setEtape(n);
    setErreurs({});
    haut.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function suivant() {
    if (etape === 0) {
      const e: Record<string, string> = {};
      if (!profil.filiere) e.filiere = 'Choisis ta filière.';
      if (!profil.niveau) e.niveau = 'Choisis ton niveau.';
      if (!profil.annee) e.annee = 'Choisis l’année académique.';
      if (Object.keys(e).length) return setErreurs(e);
    } else if (etape <= sections.length) {
      const e = validateSection(sections[etape - 1], answers);
      if (Object.keys(e).length) {
        setErreurs(e);
        const first = Object.keys(e)[0];
        document.getElementById(`q-${first}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
    }
    allerA(etape + 1);
  }

  async function soumettre() {
    setEnvoi(true);
    setErreurEnvoi(null);
    try {
      const res = await fetch('/api/soumettre', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          campagneId,
          filiere: profil.filiere,
          niveau: profil.niveau,
          anneeAcademique: profil.annee,
          reponses: answers,
          site_web: honeypot.current?.value ?? '',
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Une erreur est survenue. Réessaie dans quelques instants.');
      ecrireStockage('session', cleBrouillon(campagneId), null);
      ecrireStockage('local', cleParticipation(campagneId), '1');
      router.replace('/merci');
    } catch (e) {
      setErreurEnvoi(e instanceof Error ? e.message : 'Erreur inattendue.');
      setEnvoi(false);
    }
  }

  if (!pret) return <div className="py-20 text-center text-sm text-slate-500">Chargement…</div>;

  if (dejaParticipe)
    return (
      <div className="carte mt-8">
        <h2 className="text-lg font-semibold text-marque-900">Une participation a déjà été envoyée depuis cet appareil</h2>
        <p className="mt-2 text-sm text-slate-600">
          Merci ! Pour garantir la fiabilité des résultats, chaque étudiant est invité à ne répondre qu&apos;une seule fois
          par campagne. Si tu utilises l&apos;appareil d&apos;une autre personne et que tu n&apos;as pas encore répondu,
          tu peux continuer.
        </p>
        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <button className="btn-primaire" onClick={() => setDejaParticipe(false)}>
            Je n&apos;ai pas encore répondu, continuer
          </button>
          <a className="btn-secondaire" href="/">
            Retour à l&apos;accueil
          </a>
        </div>
      </div>
    );

  const sectionCourante: Section | null = etape >= 1 && etape <= sections.length ? sections[etape - 1] : null;

  return (
    <div ref={haut} className="scroll-mt-4 pb-28">
      {/* Barre de progression */}
      <div className="sticky top-0 z-10 -mx-4 border-b border-slate-200 bg-slate-50/95 px-4 py-3 backdrop-blur">
        <div className="flex items-center justify-between text-xs font-medium text-slate-600">
          <span>
            Étape {etape + 1} sur {totalEtapes}
          </span>
          <span>{progression} %</span>
        </div>
        <div
          className="mt-2 h-2 overflow-hidden rounded-full bg-slate-200"
          role="progressbar"
          aria-valuenow={progression}
          aria-valuemin={0}
          aria-valuemax={100}
        >
          <div className="h-full rounded-full bg-marque-500 transition-all duration-300" style={{ width: `${progression}%` }} />
        </div>
      </div>

      {/* Champ piège anti-robots, invisible pour les humains */}
      <input ref={honeypot} type="text" name="site_web" tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />

      {etape === 0 && (
        <EtapeProfil profil={profil} setProfil={setProfil} erreurs={erreurs} {...props} />
      )}

      {sectionCourante && (
        <div className="mt-6">
          <p className="text-xs font-semibold uppercase tracking-wider text-accent-600">Rubrique {etape + 1}</p>
          <h2 className="mt-1 text-2xl font-bold text-marque-900">{sectionCourante.title}</h2>
          {sectionCourante.intro && <p className="mt-2 text-sm text-slate-600">{sectionCourante.intro}</p>}
          <div className="mt-6 space-y-4">
            {sectionCourante.questions
              .filter((qu) => isVisible(qu, answers))
              .map((qu) => (
                <ChampQuestion
                  key={qu.id}
                  question={qu}
                  value={answers[qu.id]}
                  autre={answers[`${qu.id}_autre`]}
                  onChange={(v) => setAnswer(qu.id, v)}
                  onAutre={(v) => setAnswer(`${qu.id}_autre`, v)}
                  erreur={erreurs[qu.id]}
                  likertLabels={q.likertLabels}
                  naLabel={q.naLabel}
                />
              ))}
          </div>
        </div>
      )}

      {etape === totalEtapes - 1 && (
        <Recapitulatif
          q={q}
          profil={profil}
          answers={answers}
          onModifier={(n) => allerA(n)}
          erreurEnvoi={erreurEnvoi}
        />
      )}

      {/* Navigation */}
      <div className="fixed inset-x-0 bottom-0 z-10 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-3xl gap-3 px-4 py-3">
          {etape > 0 && (
            <button className="btn-secondaire flex-1 sm:flex-none" onClick={() => allerA(etape - 1)} disabled={envoi}>
              ← Précédent
            </button>
          )}
          {etape < totalEtapes - 1 ? (
            <button className="btn-primaire flex-1" onClick={suivant}>
              {etape === totalEtapes - 2 ? 'Vérifier mes réponses' : 'Suivant →'}
            </button>
          ) : (
            <button className="btn-primaire flex-1" onClick={soumettre} disabled={envoi}>
              {envoi ? 'Envoi en cours…' : 'Confirmer et envoyer mon avis'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function EtapeProfil({
  profil,
  setProfil,
  erreurs,
  filieres,
  niveaux,
  annees,
}: Props & { profil: Profil; setProfil: (p: Profil) => void; erreurs: Record<string, string> }) {
  return (
    <div className="mt-6">
      <p className="text-xs font-semibold uppercase tracking-wider text-accent-600">Rubrique 1</p>
      <h2 className="mt-1 text-2xl font-bold text-marque-900">Profil académique</h2>
      <p className="mt-2 text-sm text-slate-600">
        Ces informations servent uniquement aux analyses statistiques. Elles ne permettent pas de t&apos;identifier :
        les résultats des groupes trop petits ne sont jamais affichés.
      </p>
      <div className="mt-6 space-y-4">
        <ChoixListe
          id="filiere"
          label="Dans quelle filière es-tu inscrit(e) ?"
          options={filieres}
          value={profil.filiere}
          onChange={(v) => setProfil({ ...profil, filiere: v })}
          erreur={erreurs.filiere}
        />
        <ChoixListe
          id="niveau"
          label="Quel est ton niveau d'étude ?"
          options={niveaux}
          value={profil.niveau}
          onChange={(v) => setProfil({ ...profil, niveau: v })}
          erreur={erreurs.niveau}
          enLigne
        />
        <ChoixListe
          id="annee"
          label="À quelle année académique se rapporte ton appréciation ?"
          options={annees}
          value={profil.annee}
          onChange={(v) => setProfil({ ...profil, annee: v })}
          erreur={erreurs.annee}
          enLigne
        />
      </div>
    </div>
  );
}

function Bloc({ id, label, help, erreur, required, children }: { id: string; label: string; help?: string; erreur?: string; required?: boolean; children: React.ReactNode }) {
  return (
    <fieldset id={`q-${id}`} className={`carte scroll-mt-24 ${erreur ? 'border-red-300 ring-1 ring-red-200' : ''}`}>
      <legend className="sr-only">{label}</legend>
      <p className="font-medium text-slate-800">
        {label}
        {required && <span className="ml-1 text-red-500" aria-label="obligatoire">*</span>}
      </p>
      {help && <p className="mt-0.5 text-xs text-slate-500">{help}</p>}
      <div className="mt-3">{children}</div>
      {erreur && (
        <p className="mt-2 text-sm font-medium text-red-600" role="alert">
          {erreur}
        </p>
      )}
    </fieldset>
  );
}

function ChoixListe({ id, label, options, value, onChange, erreur, enLigne }: { id: string; label: string; options: string[]; value: string; onChange: (v: string) => void; erreur?: string; enLigne?: boolean }) {
  return (
    <Bloc id={id} label={label} erreur={erreur} required>
      <div className={enLigne ? 'grid grid-cols-1 gap-2 sm:grid-cols-3' : 'grid gap-2'}>
        {options.map((o) => (
          <label
            key={o}
            className={`flex cursor-pointer items-center gap-3 rounded-lg border px-3 py-3 text-sm transition ${
              value === o ? 'border-marque-500 bg-marque-50 font-semibold text-marque-900' : 'border-slate-200 hover:border-slate-300'
            }`}
          >
            <input type="radio" name={id} className="accent-marque-600" checked={value === o} onChange={() => onChange(o)} />
            {o}
          </label>
        ))}
      </div>
    </Bloc>
  );
}

const COULEURS_LIKERT = [
  'peer-checked:bg-red-600 peer-checked:border-red-600',
  'peer-checked:bg-orange-500 peer-checked:border-orange-500',
  'peer-checked:bg-amber-500 peer-checked:border-amber-500',
  'peer-checked:bg-lime-600 peer-checked:border-lime-600',
  'peer-checked:bg-emerald-600 peer-checked:border-emerald-600',
];

function ChampQuestion({
  question: qu,
  value,
  autre,
  onChange,
  onAutre,
  erreur,
  likertLabels,
  naLabel,
}: {
  question: Question;
  value: AnswerValue | undefined;
  autre: AnswerValue | undefined;
  onChange: (v: AnswerValue) => void;
  onAutre: (v: string) => void;
  erreur?: string;
  likertLabels: string[];
  naLabel: string;
}) {
  if (qu.type === 'likert')
    return (
      <Bloc id={qu.id} label={qu.label} help={qu.help} erreur={erreur} required={qu.required}>
        <div className="grid grid-cols-5 gap-1.5">
          {likertLabels.map((lab, i) => (
            <label key={i} className="cursor-pointer" title={lab}>
              <input
                type="radio"
                name={qu.id}
                className="peer sr-only"
                checked={value === i + 1}
                onChange={() => onChange(i + 1)}
              />
              <span
                className={`flex h-11 items-center justify-center rounded-lg border border-slate-300 text-base font-bold text-slate-600 transition peer-checked:text-white peer-focus-visible:ring-2 peer-focus-visible:ring-marque-500 ${COULEURS_LIKERT[i]}`}
              >
                {i + 1}
              </span>
              <span className="mt-1 block text-center text-[10px] leading-tight text-slate-500 sm:text-[11px]">{lab}</span>
            </label>
          ))}
        </div>
        {qu.allowNA && (
          <label className="mt-3 inline-flex cursor-pointer items-center gap-2 text-sm text-slate-600">
            <input type="radio" name={qu.id} className="accent-marque-600" checked={value === 'NA'} onChange={() => onChange('NA')} />
            {naLabel}
          </label>
        )}
      </Bloc>
    );

  if (qu.type === 'scale10')
    return (
      <Bloc id={qu.id} label={qu.label} help={qu.help} erreur={erreur} required={qu.required}>
        <div className="grid grid-cols-6 gap-1.5 sm:grid-cols-11">
          {Array.from({ length: 11 }, (_, i) => (
            <label key={i} className="cursor-pointer">
              <input type="radio" name={qu.id} className="peer sr-only" checked={value === i} onChange={() => onChange(i)} />
              <span className="flex h-11 items-center justify-center rounded-lg border border-slate-300 font-bold text-slate-600 transition peer-checked:border-marque-600 peer-checked:bg-marque-600 peer-checked:text-white peer-focus-visible:ring-2 peer-focus-visible:ring-marque-500">
                {i}
              </span>
            </label>
          ))}
        </div>
        <div className="mt-1 flex justify-between text-[11px] text-slate-500">
          <span>0 = très mauvais</span>
          <span>10 = excellent</span>
        </div>
      </Bloc>
    );

  if (qu.type === 'text') {
    const v = typeof value === 'string' ? value : '';
    const max = qu.maxLength ?? 1500;
    return (
      <Bloc id={qu.id} label={qu.label} help={qu.help ?? 'Facultatif'} erreur={erreur} required={qu.required}>
        <textarea
          className="champ min-h-[110px]"
          maxLength={max}
          placeholder={qu.placeholder}
          value={v}
          onChange={(e) => onChange(e.target.value)}
        />
        <p className="mt-1 text-right text-[11px] text-slate-400">
          {v.length} / {max}
        </p>
      </Bloc>
    );
  }

  if (qu.type === 'single')
    return (
      <Bloc id={qu.id} label={qu.label} help={qu.help} erreur={erreur} required={qu.required}>
        <div className="grid gap-2">
          {qu.options.map((o) => (
            <label
              key={o}
              className={`flex cursor-pointer items-center gap-3 rounded-lg border px-3 py-2.5 text-sm transition ${
                value === o ? 'border-marque-500 bg-marque-50 font-medium text-marque-900' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <input type="radio" name={qu.id} className="accent-marque-600" checked={value === o} onChange={() => onChange(o)} />
              {o}
            </label>
          ))}
        </div>
      </Bloc>
    );

  // multi
  const sel = Array.isArray(value) ? value : [];
  function basculer(o: string) {
    if (qu.type !== 'multi') return;
    let next: string[];
    if (sel.includes(o)) next = sel.filter((x) => x !== o);
    else if (qu.exclusive && o === qu.exclusive) next = [o];
    else next = [...sel.filter((x) => x !== qu.exclusive), o];
    onChange(next);
  }
  return (
    <Bloc id={qu.id} label={qu.label} help={qu.help} erreur={erreur} required={qu.required}>
      <div className="grid gap-2">
        {qu.options.map((o) => (
          <label
            key={o}
            className={`flex cursor-pointer items-center gap-3 rounded-lg border px-3 py-2.5 text-sm transition ${
              sel.includes(o) ? 'border-marque-500 bg-marque-50 font-medium text-marque-900' : 'border-slate-200 hover:border-slate-300'
            } ${o === qu.exclusive ? 'mt-1 border-dashed' : ''}`}
          >
            <input type="checkbox" className="h-4 w-4 accent-marque-600" checked={sel.includes(o)} onChange={() => basculer(o)} />
            {o}
          </label>
        ))}
        {qu.otherOption && sel.includes(qu.otherOption) && (
          <input
            className="champ"
            placeholder="Précise la difficulté…"
            maxLength={300}
            value={typeof autre === 'string' ? autre : ''}
            onChange={(e) => onAutre(e.target.value)}
          />
        )}
      </div>
    </Bloc>
  );
}

function Recapitulatif({
  q,
  profil,
  answers,
  onModifier,
  erreurEnvoi,
}: {
  q: QuestionnaireDef;
  profil: Profil;
  answers: Answers;
  onModifier: (etape: number) => void;
  erreurEnvoi: string | null;
}) {
  const fmt = (qu: Question, v: AnswerValue | undefined): string => {
    if (v === undefined || v === null || v === '' || (Array.isArray(v) && !v.length)) return '—';
    if (v === 'NA') return q.naLabel;
    if (qu.type === 'likert' && typeof v === 'number') return `${v} – ${q.likertLabels[v - 1]}`;
    if (qu.type === 'scale10') return `${v} / 10`;
    if (Array.isArray(v)) return v.join(' · ');
    return String(v);
  };
  const nbRepondues = useMemo(
    () => Object.values(answers).filter((v) => v !== '' && v !== null && !(Array.isArray(v) && !v.length)).length,
    [answers],
  );
  return (
    <div className="mt-6">
      <h2 className="text-2xl font-bold text-marque-900">Vérifie tes réponses</h2>
      <p className="mt-2 text-sm text-slate-600">
        Tu as répondu à {nbRepondues} questions. Une fois envoyées, tes réponses ne pourront plus être modifiées : elles
        ne sont rattachées à aucune identité.
      </p>
      <div className="mt-5 space-y-3">
        <details className="carte" open>
          <summary className="cursor-pointer font-semibold text-marque-800">Profil académique</summary>
          <p className="mt-2 text-sm text-slate-700">
            {profil.filiere} · {profil.niveau} · {profil.annee}
          </p>
          <button className="mt-2 text-sm font-medium text-marque-600 underline" onClick={() => onModifier(0)}>
            Modifier
          </button>
        </details>
        {q.sections.map((s, i) => (
          <details key={s.id} className="carte">
            <summary className="cursor-pointer font-semibold text-marque-800">{s.title}</summary>
            <dl className="mt-3 space-y-2 text-sm">
              {s.questions
                .filter((qu) => isVisible(qu, answers))
                .map((qu) => (
                  <div key={qu.id}>
                    <dt className="text-slate-500">{qu.label}</dt>
                    <dd className="whitespace-pre-line font-medium text-slate-800">{fmt(qu, answers[qu.id])}</dd>
                  </div>
                ))}
            </dl>
            <button className="mt-3 text-sm font-medium text-marque-600 underline" onClick={() => onModifier(i + 1)}>
              Modifier cette rubrique
            </button>
          </details>
        ))}
      </div>
      {erreurEnvoi && (
        <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm font-medium text-red-700" role="alert">
          {erreurEnvoi}
        </p>
      )}
    </div>
  );
}
